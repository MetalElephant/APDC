package pt.unl.fct.loginapp.data.forum.model;

import java.io.Serializable;

public class ForumInfo implements Serializable {

    public String owner, name, topic, crtTime;

    public ForumInfo(String owner, String name, String topic, String crtTime){
        this.owner = owner;
        this.name = name;
        this.topic = topic;
        this.crtTime = crtTime;
    }

    public String getOwner() {
        return owner;
    }

    public String getName() {
        return name;
    }

    public String getTopic() {
        return topic;
    }

    public String getCrtTime() {
        return crtTime;
    }

    @Override
    public String toString() {
        return "Fórum "+ name+System.getProperty("line.separator")
                +"Tópico: "+topic;
    }
}

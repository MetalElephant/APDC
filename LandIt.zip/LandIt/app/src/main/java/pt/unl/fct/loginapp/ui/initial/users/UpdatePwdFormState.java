package pt.unl.fct.loginapp.ui.initial.users;

import androidx.annotation.Nullable;

public class UpdatePwdFormState {

    @Nullable
    private Integer prevPwdError;
    @Nullable
    private Integer newPwdError;
    @Nullable
    private Integer newPwdConfirmationError;

    private boolean isDataValid;

    UpdatePwdFormState(@Nullable Integer prevPwdError, @Nullable Integer newPwdError,
                       @Nullable Integer newPwdConfirmationError) {
        this.prevPwdError = prevPwdError;
        this.newPwdConfirmationError = newPwdConfirmationError;
        this.newPwdError = newPwdError;
        this.isDataValid = false;
    }

    UpdatePwdFormState(boolean isDataValid) {
        this.prevPwdError = null;
        this.newPwdError = null;
        this.newPwdConfirmationError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getPrevPwdError(){return prevPwdError;}

    @Nullable
    public Integer getNewPwdError() {
        return newPwdError;
    }

    @Nullable
    public Integer getPwdConfirmationError() { return newPwdConfirmationError; }

    public boolean isDataValid() {
        return isDataValid;
    }
}

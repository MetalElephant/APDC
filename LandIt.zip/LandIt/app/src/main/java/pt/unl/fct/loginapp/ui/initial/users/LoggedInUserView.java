package pt.unl.fct.loginapp.ui.initial.users;

/**
 * Class exposing authenticated user details to the UI.
 */
class LoggedInUserView {
    private String username;

    private String role;
    //... other data fields that may be accessible to the UI

    LoggedInUserView(String username, String role) {
        this.username = username; this.role = role;
    }

    String getUsername() { return username; }

    String getRole(){return role;}
}


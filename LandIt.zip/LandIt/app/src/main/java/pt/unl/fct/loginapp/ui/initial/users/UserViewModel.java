package pt.unl.fct.loginapp.ui.initial.users;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import android.util.Patterns;

import java.util.List;
import java.util.regex.Pattern;

import pt.unl.fct.loginapp.data.users.ProfileRepositoryCallback;
import pt.unl.fct.loginapp.data.users.UpdatePasswordRepositoryCallback;
import pt.unl.fct.loginapp.data.users.UserRepository;
import pt.unl.fct.loginapp.data.users.LoginRepositoryCallback;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.users.LogoutRepositoryCallback;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;
import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.RegisterRepositoryCallback;
import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import pt.unl.fct.loginapp.data.users.model.updatePwd.UpdatedPwdUser;
import pt.unl.fct.loginapp.ui.homepage.LoggedOutUserView;
import pt.unl.fct.loginapp.ui.homepage.LogoutResult;
import pt.unl.fct.loginapp.ui.homepage.ui.profile.ProfileResult;
import pt.unl.fct.loginapp.ui.homepage.ui.profile.UserInfoListView;
import pt.unl.fct.loginapp.ui.homepage.ui.profile.UserInfoView;

public class UserViewModel extends ViewModel {

    private MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>();
    private MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();

    private MutableLiveData<RegisterFormState> registerFormState = new MutableLiveData<>();
    private MutableLiveData<UserResult> registerResult = new MutableLiveData<>();

    private MutableLiveData<LogoutResult> logoutResult = new MutableLiveData<>();

    private MutableLiveData<UpdatePwdFormState> updatePwdFormState = new MutableLiveData<>();
    private MutableLiveData<UpdatePwdResult> updatePwdResult = new MutableLiveData<>();

    private MutableLiveData<ProfileResult> profileResult = new MutableLiveData<>();

    private MutableLiveData<UpdateUserFormState> updateUserFormState = new MutableLiveData<>();
    private MutableLiveData<UserResult> updateResult = new MutableLiveData<>();


    public MutableLiveData<RegisterFormState> getRegisterFormState() {
        return registerFormState;
    }

    private UserRepository userRepository;

    UserViewModel(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    //region login---------------------------------------------------------------------------//
    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalidUsername, null));
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.invalidPassword));
        } else {
            loginFormState.setValue(new LoginFormState(true));
        }
    }

    public void login(String username, String password) {
        // can be launched in a separate asynchronous job
        userRepository.login(username, password, new LoginRepositoryCallback<LoggedInUser>() {
            @Override
            public void onComplete(Result<LoggedInUser> result) {
                if (result instanceof Result.Success) {
                    LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
                    loginResult.postValue(new LoginResult(new LoggedInUserView(data.getUsername(), data.getRole())));
                } else if(result.isCode("409")) {
                    loginResult.postValue(new LoginResult(R.string.loginForbidden));
                }else if(result.isCode("404")){
                    loginResult.postValue(new LoginResult(R.string.loginForbidden));
                } else {
                    loginResult.postValue(new LoginResult(R.string.loginFailed));
                }
            }
        });
    }

    //endregion-----------------------------------------------------------------------------------//

    //region register---------------------------------------------------------------------------//

    public LiveData<UserResult> getUserResult() {
        return registerResult;
    }
    //To validate data put in the boxes
    public void registerDataChanged(String username, String password, String confirmation,
                                    String email, String name) {
        if (!isUserNameValid(username)) {
            registerFormState.setValue(new RegisterFormState(R.string.invalidUsername, null, null, null, null));
        } else if (!isPasswordValid(password)) {
            registerFormState.setValue(new RegisterFormState(null, R.string.invalidPassword, null, null, null));
        } else if (!isConfirmationValid(confirmation, password)) {
            registerFormState.setValue(new RegisterFormState(null, null, R.string.invalidConfirmation, null, null));
        } else if (!isEmailValid(email)) {
            registerFormState.setValue(new RegisterFormState(null, null, null, R.string.invalidEmail, null));
        } else if (!isNameValid(name)) {
            registerFormState.setValue(new RegisterFormState(null, null, null, null, R.string.invalidName));
        } else {
            registerFormState.setValue(new RegisterFormState(true)); //i cant solve this error!!!!!
        }
    }

    public void register(String username, String password, String confirmation,
                         String email, String name, String role,
                         String district, String county, String municipality,
                         String street, String homePhone, String mobilePhone,
                         String nif, String code,byte[]photo) {
        // can be launched in a separate asynchronous job
        userRepository.register(username, password, confirmation, email, name, role, district, county,
                municipality, street, homePhone, mobilePhone, nif, code, photo, new RegisterRepositoryCallback<RegisteredUser>() {

            @Override
            public void onComplete(Result<RegisteredUser> result) {
                if (result instanceof Result.Success) {
                    RegisteredUser data = ((Result.Success<RegisteredUser>) result).getData();
                    registerResult.postValue(new UserResult(new RegisteredUserView()));
                } else if (result.isCode("404")) { //should never reach this
                    registerResult.postValue(new UserResult(R.string.registerBadRequest));
                } else if (result.isCode("409")) {
                    registerResult.postValue(new UserResult(R.string.registerConflict));
                }else{
                        registerResult.postValue(new UserResult(R.string.registerFailed));
                    }
                }
        });

    }


    //endregion-----------------------------------------------------------------------------------//


    //region logout-------------------------------------------------------------------------------//

    public LiveData<LogoutResult> getLogoutResult() {
        return logoutResult;
    }

    public void logout(String username) {
        // can be launched in a separate asynchronous job
        userRepository.logout(username, new LogoutRepositoryCallback<LoggedOutUser>() {
            @Override
            public void onComplete(Result<LoggedOutUser> result) {
                if (result instanceof Result.Success) {
                    //LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
                    logoutResult.postValue(new LogoutResult(new LoggedOutUserView()));
                } else {
                    logoutResult.postValue(new LogoutResult(R.string.logoutFailed));
                }
            }
        });
    }
    //endregion-----------------------------------------------------------------------------------//

    // region modifyPwd---------------------------------------------------------------------------//
    public LiveData <UpdatePwdFormState> getUpdatePwdFormState() { return updatePwdFormState;}

    public LiveData<UpdatePwdResult> getUpdatePwdResult(){ return updatePwdResult;}

    public void updatePwdDataChanged(String prevPwd, String newPwd, String newPwdConfirmation){
        if(!isPasswordValid(prevPwd)) {
            updatePwdFormState.setValue(new UpdatePwdFormState(R.string.invalidPassword,
                    null, null));
        }else if(!isPasswordValid(newPwd)){
            updatePwdFormState.setValue(new UpdatePwdFormState(null,
                    R.string.invalidPassword, null));
        }else if(prevPwd.equals(newPwd)){
            updatePwdFormState.setValue(new UpdatePwdFormState(null,
                    R.string.samePwdError, null));
        }
        else if(!isConfirmationValid(newPwdConfirmation, newPwd)){
            updatePwdFormState.setValue(new UpdatePwdFormState(null,
                    null, R.string.invalidConfirmation));
        }else{
            updatePwdFormState.setValue(new UpdatePwdFormState(true));
        }

    }

    public void updatePwd(String username, String prevPwd, String newPwd, String pwdConfirmation) {
        userRepository.updatePwd(username, prevPwd, newPwd, pwdConfirmation,
                (UpdatePasswordRepositoryCallback<UpdatedPwdUser>) result -> {
                        if (result instanceof Result.Success) {
                            updatePwdResult.postValue(new UpdatePwdResult(new UpdatePwdView()));
                        } else if (result.isCode("400")) {
                            updatePwdResult.postValue(new UpdatePwdResult(R.string.wrongPassword));
                        } else if (result.isCode("409")) { //should never happen
                            updatePwdResult.postValue(new UpdatePwdResult(R.string.samePwdError));
                        } else {
                            updatePwdResult.postValue(new UpdatePwdResult(R.string.defaultError));
                        }


                });
    }


    //endregion----------------------------------------------------------------------------------//

    //region getInfo
    public MutableLiveData<ProfileResult> getUserInfoResult() {return profileResult;}

    public void getUserInfo(String username) {
        userRepository.getUserInfo(username, (ProfileRepositoryCallback<UserInfo>) result -> {
            if(result instanceof Result.Success){
                UserInfo data = ((Result.Success<UserInfo>) result).getData();

                profileResult.postValue(new ProfileResult(new UserInfoView(data)));
            }else{
                profileResult.postValue(new ProfileResult(R.string.defaultError));
            }

        });
    }

    //endregion

    //region updateUser

    public LiveData<UpdateUserFormState> getUpdateUserFormState() {
        return updateUserFormState;
    }

    public LiveData<UserResult> getUpdateResult() {
        return updateResult;
    }

    //To validate data put in the boxes
    public void updateUserDataChanged(String name, String email) {
         if (!isEmailValid(email)) {
            updateUserFormState.setValue(new UpdateUserFormState(null, R.string.invalidEmail));
        } else if (!isNameValid(name)) {
            updateUserFormState.setValue(new UpdateUserFormState(R.string.invalidName,null));
        } else {
            updateUserFormState.setValue(new UpdateUserFormState(true));
        }
    }

    public void updateUser(String username, String usernameToUpdate, String name,
                           String email, String district, String county,
                           String municipality, String street,String homePhone,
                           String mobilePhone, String nif) {
        // can be launched in a separate asynchronous job
        userRepository.updateUser(username,
                usernameToUpdate, name, email, district, county,municipality, street,
                homePhone, mobilePhone, nif, new RegisterRepositoryCallback<RegisteredUser>() {

                    @Override
                    public void onComplete(Result<RegisteredUser> result) {
                        if (result instanceof Result.Success) {
                            updateResult.postValue(new UserResult(new RegisteredUserView()));
                        } else if (result.isCode("400")) { //should never reach this
                            updateResult.postValue(new UserResult(R.string.updateError403));
                        } else if (result.isCode("409")) {
                            updateResult.postValue(new UserResult(R.string.error409));
                        }else{
                            updateResult.postValue(new UserResult(R.string.defaultError));
                        }
                    }
                });

    }

    //endregion

    //region showUsers
    public void showUsers(){
        userRepository.listUsers(new RegisterRepositoryCallback<List<UserInfo>>() {
            @Override
            public void onComplete(Result<List<UserInfo>> result) {
                if (result instanceof Result.Success) {
                    List<UserInfo> data = ((Result.Success<List<UserInfo>>) result).getData();
                    registerResult.postValue(new UserResult(new UserInfoListView( data )));
                }else{
                    registerResult.postValue(new UserResult(R.string.defaultError));
                }
            }
        });
    }

    //endregion

    //region removeUser

    public void removeUser(String username, String name){
        // can be launched in a separate asynchronous job
        userRepository.removeUser(username,name, new RegisterRepositoryCallback<RegisteredUser>() {

            @Override
            public void onComplete(Result<RegisteredUser> result) {
                if (result instanceof Result.Success) {
                    registerResult.postValue(new UserResult(new RegisteredUserView()));
                } else if (result.isCode("403")) { //should never reach this
                    registerResult.postValue(new UserResult(R.string.removeError403));
                } else if (result.isCode("409")) {
                    registerResult.postValue(new UserResult(R.string.error409));
                }else{
                    registerResult.postValue(new UserResult(R.string.defaultError));
                }
            }
        });
    }



    //endregion

    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches(); //verifies if is email
        } else {
            return !username.trim().isEmpty();
        }
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        if(password!= null && password.trim().length()>=5) {
            Pattern lowerCase = Pattern.compile(".*[a-z].*");
            Pattern upperCase = Pattern.compile(".*[A-Z].*");
            Pattern numbers = Pattern.compile("[0-9]");
            Pattern specChars = Pattern.compile ("[!@#$%&*()_+=|<>?{}\\[\\]~-]");

            if( lowerCase.matcher(password).find() && numbers.matcher(password).find()
                    && specChars.matcher(password).find() && upperCase.matcher(password).find())
                return true;
        }
        return false;
    }


    private boolean isConfirmationValid(String confirmation, String password) {
        return confirmation != null && password!=null& confirmation.equals(password) &&
                confirmation.trim().length() >= 5;
    }

    private boolean isEmailValid(String email) {
        if (email == null) {
            return false;
        }
        if (!email.contains("@")) {
            return false;
        }

        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isNameValid(String name) {
        if(name == null) {
            return false;
        }
        else {
            return !name.trim().isEmpty();
        }
    }



}
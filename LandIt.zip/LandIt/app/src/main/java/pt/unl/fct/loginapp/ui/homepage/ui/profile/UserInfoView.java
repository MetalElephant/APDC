package pt.unl.fct.loginapp.ui.homepage.ui.profile;

import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;

public class UserInfoView {

    public UserInfo userInfo;

    public UserInfoView(UserInfo userInfo){this.userInfo = userInfo;}

    public UserInfo getUserInfo() {
        return userInfo;
    }
}

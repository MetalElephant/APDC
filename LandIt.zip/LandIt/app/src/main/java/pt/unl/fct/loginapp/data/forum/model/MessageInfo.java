package pt.unl.fct.loginapp.data.forum.model;

public class MessageInfo {
    public String owner, message, crtTime;
    public long order;
    private static final String SPACE = " ";

    public MessageInfo(String owner, String message, String crtTime, long order){
        this.owner = owner;
        this.message = message;
        this.crtTime = crtTime;
        this.order = order;
    }

    public String getOwner() {
        return owner;
    }

    public String getMessage() {
        return message;
    }

    public String getCrtTime() {
        return crtTime;
    }

    private String getCrtTimeClear(){
        String[] crtParameters = crtTime.split(SPACE);
        String month = crtParameters[1];
        String pMonth = processMonth(month);
        return crtParameters[2] +SPACE+pMonth+ SPACE + crtParameters[3];
    }

    private String processMonth(String month) {
        switch (month){
            case "Feb":
                return "Fev";
            case "Apr":
                return "Abr";
            case "May":
                return "Maio";
            case "Aug":
                return "Agos";
            case "Sep":
                return "Set";
            case "Oct":
                return "Out";
            case "Dec":
                return "Dez";
        }
        return month;
    }

    public long getOrder() {
        return order;
    }

    @Override
    public String toString() {
        return owner +" disse em " + getCrtTimeClear()+System.getProperty("line.separator")
                +message;
    }
}

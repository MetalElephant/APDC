package pt.unl.fct.loginapp.ui.homepage.ui.forums;

import java.util.List;

import pt.unl.fct.loginapp.data.forum.model.ForumInfo;


public class ForumResultListView {
    public List<ForumInfo> forums;

    public ForumResultListView(List<ForumInfo> allForums){
        this.forums = allForums;
    }

    public List<ForumInfo> getForums() {
        return forums;
    }
}

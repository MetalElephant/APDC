package pt.unl.fct.loginapp.data.users.model.login;

/**
 * Data class that captures user information for logged in users retrieved from LoginRepository
 */
public class LoggedInUser {

    public String username;
    public String role;
    public String tokenID;
    public long validFrom;
    public long validTo;

    public LoggedInUser(String username, String role, String tokenId, Long creationDate, Long expirationDate) {
        this.username = username;
        this.role = role;
        this.tokenID = tokenId;
        this.validFrom = creationDate;
        this.validTo = expirationDate;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() { return role; }

    public String getTokenId() { return tokenID; }

    public Long getCreationDate() { return validFrom; }

    public Long getExpirationDate() { return validTo; }
}
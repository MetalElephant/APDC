package pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.FragmentParcelsBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class ParcelsFragment extends Fragment {

    private FragmentParcelsBinding binding;
    private ParcelViewModel parcelViewModel;
    private ArrayAdapter<String> arrayAdapter;
    private static final String VERIFIED = "Estado: Verificada";
    private static final String NONVERIFIED = "Estado: Não verificada";
    private static final String NAME = "Nome: ";
    private static final String LOCAL = "Localização: ";
    private static final String LINESEPARATOR = "line.separator";
    private Button sendRequestBtn;
    private LinearLayout loadingLayout;
    private Spinner parcelCountySpinner;
    private Spinner parcelDistrictSpinner;
    private Spinner parcelMunicipalitySpinner;
    private AuxMethods aux = new AuxMethods();
    String usernameSelf;
    String role;
    List<String> elems;
    List<String> toDisplay;
    ListView list;
    private boolean shouldRefresh = false;

    private List<ParcelInfo> allParcels;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ParcelsViewModel parcelsViewModel =
                new ViewModelProvider(this).get(ParcelsViewModel.class);

        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);


        binding = FragmentParcelsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //region bindins & initializations
        usernameSelf = aux.loadUsername(getContext());
        role = aux.loadRole(getContext());

        list = (ListView) binding.parcelsListView;
        loadingLayout = binding.loadLayout;
        LinearLayout modOrSULayout = binding.modSearchLayout;
        TextView noParcelsTxt = binding.textNoParcels;
        sendRequestBtn = binding.searchRegionBtn;
        ToggleButton toggle = binding.toggleParcels;

        //region spinners
        parcelCountySpinner = (Spinner) binding.parcelCountyInputSpinner;
        parcelCountySpinner.setEnabled(false);
        aux.setSpinnerAdapterType(parcelCountySpinner, R.string.selectCounty, "", getContext());
        parcelDistrictSpinner = (Spinner) binding.parcelDistrictInputSpinner;
        aux.setSpinnerAdapterType(parcelDistrictSpinner,R.string.selectDistrict, "", getContext());
        parcelMunicipalitySpinner = (Spinner) binding.parcelFreguesiaInputSpinner;
        parcelMunicipalitySpinner.setEnabled(false);
        aux.setSpinnerAdapterType(parcelMunicipalitySpinner,R.string.selectMunicipality, "",getContext());
        //endregion

        elems = new ArrayList<>();
        toDisplay = new ArrayList<>();
        allParcels = new ArrayList<>();

        //endregion

        //region spinner listeners
        parcelDistrictSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(parcelDistrictSpinner.getSelectedItem() != null) {

                    //enable button if something other than default value is selected
                    if(!parcelDistrictSpinner.getSelectedItem().toString().
                            equalsIgnoreCase(getString(R.string.selectDistrict))){
                        sendRequestBtn.setEnabled(true);
                    }else{
                        sendRequestBtn.setEnabled(false);
                    }
                    String district = parcelDistrictSpinner.getSelectedItem().toString();
                    //sets the city/county spinner, only showing cities from the district chosen
                    aux.setSpinnerAdapterType(parcelCountySpinner, R.string.selectCounty, district, getContext());
                    parcelCountySpinner.setEnabled(true);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        parcelCountySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(parcelCountySpinner.getSelectedItem() != null){
                    String county = parcelCountySpinner.getSelectedItem().toString();
                    aux.setSpinnerAdapterType(parcelMunicipalitySpinner, R.string.selectMunicipality, county, getContext());
                    parcelMunicipalitySpinner.setEnabled(true);

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //endregion

        //region search parcels
        SearchView searchView = binding.searchParcelsView;
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                doSearchResults(s);


                return false;
            }
        });

        //toggle handling
        toggle.setOnCheckedChangeListener((compoundButton, isChecked) -> doToggleResults(isChecked));

        //endregion

        //region load Parcels

        /*if moderator or SU, they can handle ALL parcels, so,for simplicity, let them
        choose the region of the parcels they might want to see*/
        if(Roles.isModOrSU(role)){
            loadingLayout.setVisibility(View.GONE);
            modOrSULayout.setVisibility(View.VISIBLE);
            searchView.setVisibility(View.GONE);
            noParcelsTxt.setVisibility(View.GONE);
            toggle.setVisibility(View.GONE);

            //only visible if moderator or SU
            sendRequestBtn.setOnClickListener(view -> {

                showParcelsByRegion();

            });


        }else if(Roles.isRep(role)) {
            parcelViewModel.showRepParcels(usernameSelf);
            noParcelsTxt.setVisibility(View.GONE);
            modOrSULayout.setVisibility(View.GONE);


        }else{
            parcelViewModel.showParcels(usernameSelf);
            modOrSULayout.setVisibility(View.GONE);


        }



        parcelViewModel.getParcelResult().observe(getViewLifecycleOwner(), new Observer<ParcelResult>() {
            @Override
            public void onChanged(@Nullable ParcelResult parcelResult) {
                loadingLayout.setVisibility(View.GONE);

                if (parcelResult == null) {
                    return;
                }
                if (parcelResult.getError() != null) {
                }
                if (parcelResult.getSuccessP() != null) {

                    if(elems.isEmpty())
                        loadUserParcels(parcelResult);

                    //set the listView with elements loaded
                    if(elems.isEmpty() && toDisplay.isEmpty()){
                        noParcelsTxt.setVisibility(View.VISIBLE);
                    }
                    else {

                        setListView();

                    }

                }
            }
        });

        //endregion



        return root;
    }

    private void showParcelsByRegion() {
        loadingLayout.setVisibility(View.VISIBLE);
        String district = "";
        String county = "";
        String municipality = "";
        if(parcelDistrictSpinner.getSelectedItem() != null)
            district = parcelDistrictSpinner.getSelectedItem().toString();
        if(parcelCountySpinner.getSelectedItem() != null)
            county = parcelCountySpinner.getSelectedItem().toString();
        if(parcelMunicipalitySpinner.getSelectedItem() != null)
            municipality = parcelMunicipalitySpinner.getSelectedItem().toString();


        if(!isEmpty(municipality)){
            parcelViewModel.showParcelsRegion(usernameSelf,municipality,3);//1 county, 2 district, 3 freguesia
        }
        else if(!isEmpty(county)){
            parcelViewModel.showParcelsRegion(usernameSelf,county,1);
        }else if(!isEmpty(district)){
            parcelViewModel.showParcelsRegion(usernameSelf,district, 2);
        }


    }

    private void doToggleResults(boolean isToggled){
        ArrayList<String> filteredParcels = new ArrayList<>();

        for (int i = 0; i< allParcels.size(); i++){
            ParcelInfo elem = allParcels.get(i);
            if(elem.isConfirmed() == isToggled) {
                filteredParcels.add(toDisplay.get(i));
            }

        }
        setSearchAdapter(filteredParcels);

    }

    private void doSearchResults(String s){
        ArrayList<String> filteredParcels = new ArrayList<>();

        for (int i = 0; i< allParcels.size(); i++){
            ParcelInfo elem = allParcels.get(i);
            if(elem.getParcelName().toLowerCase().contains(s.toLowerCase())
                    || elem.getLocation().toLowerCase().contains(s.toLowerCase())
                    || elem.isConfirmedString().contains(s.toLowerCase())) {
                filteredParcels.add(toDisplay.get(i));
            }

        }
        setSearchAdapter(filteredParcels);
    }

    private void setSearchAdapter(ArrayList<String> filteredParcels){
        arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, filteredParcels);
        list.setAdapter(arrayAdapter);

    }



    private boolean isEmpty(String region){
        return region.equalsIgnoreCase("");
    }

    private void setListView() {
        ListView list = initTable();

        list.setOnItemClickListener((adapterView, view, i, l) -> {

            //change activity
            Intent intent = new Intent(getContext(), ParcelInfoActivity.class);
            intent.putExtra(getString(R.string.parcel), elems.get(i));
            startActivity(intent);


        });
    }


    private void loadUserParcels(ParcelResult parcelResult) {
        ParcelInfoView infoView = parcelResult.getSuccessP();
        List<ParcelInfo> listP = infoView.getParcels();

            for (ParcelInfo parcel: listP) {
                elems.add(parcel.toString());
                String finalString = "";
                String stringToAdd = NAME + parcel.getParcelName()
                        + System.getProperty(LINESEPARATOR) + LOCAL
                        + parcel.getLocation();

                if(parcel.isConfirmed()){
                    finalString = stringToAdd + System.getProperty(LINESEPARATOR) + VERIFIED;
                }else{
                    finalString = stringToAdd + System.getProperty(LINESEPARATOR) + NONVERIFIED;
                }
                toDisplay.add(finalString);
                allParcels.add(parcel);
            }
        }

    private ListView initTable(){
        arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, toDisplay);

        list.setAdapter(arrayAdapter);

        arrayAdapter.notifyDataSetChanged();

        return list;
    }

    private ListView initFilteredTable(){
        ListView list = (ListView) binding.parcelsListView;
        arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, toDisplay);

        list.setAdapter(arrayAdapter);

        arrayAdapter.notifyDataSetChanged();

        return list;
    }


    @Override
    public void onResume() {
        super.onResume();
        if(shouldRefresh){
            if(parcelDistrictSpinner.getSelectedItem() == null)
                //we cant "show parcels by region" if there's no region selected, so we just refresh
                // the whole fragment in that case
                aux.refreshFragment(getActivity(),R.id.nav_parcels);
            else {
                allParcels.clear();
                elems.clear();
                toDisplay.clear();
                showParcelsByRegion();
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        shouldRefresh = true;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
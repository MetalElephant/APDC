package pt.unl.fct.loginapp.ui.initial.users;

import androidx.annotation.Nullable;

import pt.unl.fct.loginapp.ui.homepage.ui.profile.UserInfoListView;

public class UserResult {

    @Nullable
    private pt.unl.fct.loginapp.ui.initial.users.RegisteredUserView success;
    @Nullable
    private UserInfoListView successU;
    @Nullable
    private Integer error;

    UserResult(@Nullable Integer error) {
        this.error = error;
    }

    UserResult(@Nullable RegisteredUserView success) {
        this.success = success;
    }

    public UserResult(UserInfoListView success) {
        this.successU = success;
    }

    @Nullable
    public RegisteredUserView getSuccess() {
        return success;
    }

    @Nullable
    public UserInfoListView getSuccessU() {
        return successU;
    }

    @Nullable
    public Integer getError() {
        return error;
    }
}

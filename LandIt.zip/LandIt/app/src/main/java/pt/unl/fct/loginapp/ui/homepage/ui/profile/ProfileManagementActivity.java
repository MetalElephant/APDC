package pt.unl.fct.loginapp.ui.homepage.ui.profile;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.snackbar.Snackbar;

import java.io.InputStream;
import java.net.URL;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;
import pt.unl.fct.loginapp.databinding.ActivityProfileManagementBinding;
import pt.unl.fct.loginapp.databinding.ProfileFragmentBinding;
import pt.unl.fct.loginapp.ui.homepage.HomePageActivity;
import pt.unl.fct.loginapp.ui.initial.InitialActivity;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModel;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class ProfileManagementActivity extends AppCompatActivity {

    private ActivityProfileManagementBinding binding;
    private UserViewModel userViewModel;
    ShapeableImageView profilePic;
    RelativeLayout imageLayout;
    EditText nameEdit;
    TextView usernameText;
    TextView usernameText2;
    EditText emailEdit;
    EditText mobilePhoneEdit;
    EditText homePhoneEdit;
    EditText addressEdit;
    EditText nifEdit;
    TextView profileName;
    TextView profileRole;
    TextView profileUsername;
    TextView instructionsTxt;
    TextView regionTxt;
    RadioGroup visibilityGroup;
    ProgressBar loadingUpdate;
    Button deleteUserBtn;
    Button updateUserBtn;
    private String username;
    String usernameSelf;
    private String picUrl;
    private static final String UNDEFINED = "Não Definido";
    private AuxMethods aux = new AuxMethods();
    private UserInfo userInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityProfileManagementBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userViewModel = new ViewModelProvider(this, new UserViewModelFactory())
                .get(UserViewModel.class);



        //region bindings & role handling

        profilePic = binding.profilePic;
        nameEdit = binding.profileNameEdit;
        usernameText = binding.profileUsername;
        usernameText2 = binding.profileUsernameEdit;
        emailEdit = binding.profileEmail;
        mobilePhoneEdit = binding.profileMobilePhone;
        homePhoneEdit = binding.profileHomePhone;
        addressEdit = binding.profileAddress;
        regionTxt = binding.profileRegion;
        nifEdit = binding.profileNif;
        profileName = binding.profileName;
        profileUsername = binding.profileUsername;
        profileRole = binding.profileRole;
        loadingUpdate = binding.loadingUpdateInfo;
        loadingUpdate.setVisibility(View.GONE);
        imageLayout = binding.imgUser;
        imageLayout.setVisibility(View.GONE);
        LinearLayout infoLayout = binding.linearLayoutInfo;
        infoLayout.setVisibility(View.GONE);
        ProgressBar loadingInfo = binding.loadingInfo;
        TextView loadingInfoTxt = binding.loadingInfoTxt;
        TextView youAreTxt = binding.youAreTxt;
        youAreTxt.setVisibility(View.GONE);
        instructionsTxt = binding.profileInstructions;
        deleteUserBtn = binding.deleteUserBtn;
        updateUserBtn = binding.updateProfileInfoBtn;


        //get UserInfo that we sent from ManageUsersFragment
        UserInfo uInfo = (UserInfo) getIntent().getSerializableExtra(getString(R.string.user));
        username = uInfo.getUsername();
        usernameSelf = aux.loadUsername(getApplicationContext());
        profileUsername.setText(username);

        loadUserInfo(uInfo);
        infoLayout.setVisibility(View.VISIBLE);
        loadingInfo.setVisibility(View.GONE);
        loadingInfoTxt.setVisibility(View.GONE);

        //endregion


        //region updateInfo

        updateUserBtn.setOnClickListener(view -> {
            loadingUpdate.setVisibility(View.VISIBLE);

            String name = toText(nameEdit);
            String email = toText(emailEdit);
            String username1 = usernameSelf;
            String username2 = username;
            String mPhone = toText(mobilePhoneEdit);
            String hPhone = toText(homePhoneEdit);
            String address = toText(addressEdit);
            String nif = toText(nifEdit);
            userViewModel.updateUser(username1, username2, name, email,
                    uInfo.getDistrict(), uInfo.getCounty(), uInfo.getAutarchy(),address,
                    hPhone, mPhone, nif);


        });

        //observer
        userViewModel.getUpdateResult().observe(this, userResult -> {
            loadingUpdate.setVisibility(View.GONE);
            if (userResult == null) {
                return;
            }
            if (userResult.getError() != null) {
                aux.makeToast( R.string.defaultError,ProfileManagementActivity.this);
            }
            if (userResult.getSuccess() != null) {
                aux.makeToast(R.string.updateUserSuccess,ProfileManagementActivity.this);

            }
        });

        //changedFields
        userViewModel.getUpdateUserFormState().observe(this, updateUserFormState -> {

            if (updateUserFormState == null) {
                return;
            }

            updateUserBtn.setEnabled(updateUserFormState.isDataValid());

            if (updateUserFormState.getNameError() != null) {
                nameEdit.setError(getString(updateUserFormState.getNameError()));
            }
            if (updateUserFormState.getEmailError() != null) {
                emailEdit.setError(getString(updateUserFormState.getEmailError()));
            }

        });

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                userViewModel.updateUserDataChanged(toText(nameEdit), toText(emailEdit));
            }
        };
        nameEdit.addTextChangedListener(textWatcher);
        emailEdit.addTextChangedListener(textWatcher);

        //endregion

        //region removeuser
        deleteUserBtn.setOnClickListener(view -> {
            deleteAction();

        });

        //observer for remove
        userViewModel.getUserResult().observe(this, result -> {
            if (result == null) {
                return;
            }

            loadingUpdate.setVisibility(View.GONE);
            if (result.getSuccess() != null) {
                finish();
            }
        });


        //endregion

    }

    /**
     * Starts alert box and sends delete rest call if user confirms the decision by
     * inputting their username correctly
     */
    private void deleteAction() {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle(R.string.deleteAcc);
        alertDialog.setMessage(getString(R.string.deleteAccWarningMod,username));
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes),
                (dialogInterface, i) -> {
                        //call delete
                        loadingUpdate.setVisibility(View.VISIBLE);
                        userViewModel.removeUser(usernameSelf, username);

                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no),
                (dialogInterface, i) -> {
                });
        alertDialog.show();
    }

    private void loadUserInfo(UserInfo user) {

        usernameText.setText(username);
        usernameText2.setText(username);
        String name = user.getName();
        updateText(nameEdit, name);
        profileName.setText(name);
        String email = user.getEmail();
        updateText(emailEdit, email);
        String mobilePhone = user.getMobilephone();
        updateText(mobilePhoneEdit, mobilePhone);
        String homePhone = user.getLandphone();
        updateText(homePhoneEdit, homePhone);
        String address = user.getStreet();
        updateText(addressEdit, address);
        String addressRegion = user.getAddressRegion();
        regionTxt.setText(addressRegion);
        String nif = user.getNif();
        updateText(nifEdit, nif);

        String role = user.getRole();
        profileRole.setText(role);
        handleRole(role);

        picUrl = user.getPhoto();


        //if user doesnt have a picture, we just show the default user pic
        if (!picUrl.equalsIgnoreCase(UNDEFINED)) {
            getImageThread.start();
        }

    }

    /**
     * Will make delete and update button unavailable if
     * you're a moderator and the profile you're seeing is SU
     * @param role role of user whose profile you're seeing
     */
    private void handleRole(String role) {
        //if we are moderators, we cant delete superusers, even though we cant see them
        String myRole = aux.loadRole(getApplicationContext());
        if(Roles.isModOrSU(role)){
            deleteUserBtn.setVisibility(View.GONE);
            updateUserBtn.setVisibility(View.GONE);
            addressEdit.setClickable(false);
            emailEdit.setClickable(false);
            homePhoneEdit.setClickable(false);
            mobilePhoneEdit.setClickable(false);
            nameEdit.setClickable(false);
            nifEdit.setClickable(false);
            instructionsTxt.setVisibility(View.GONE);
        }
    }


    /**
     * load the image using a new thread, otherwise we get an exception thrown
     */
    Thread getImageThread = new Thread(new Runnable(){
        @Override
        public void run() {
            try {
                //get profile picture
                InputStream is = (InputStream) new URL(picUrl).getContent();
                Drawable d = Drawable.createFromStream(is, picUrl);

                profilePic.setImageDrawable(d);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    });


    private void updateText(EditText field, String newValue) {
        if (!newValue.equalsIgnoreCase(UNDEFINED))
            field.setText(newValue);
    }

    private String toText(EditText editText) {
        return editText.getText().toString();
    }

}
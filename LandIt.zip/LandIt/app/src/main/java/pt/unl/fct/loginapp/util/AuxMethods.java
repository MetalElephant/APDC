package pt.unl.fct.loginapp.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.StringRes;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.preference.PreferenceManager;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.ui.homepage.NothingSelectedSpinnerAdapter;
import pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo.ParcelInfoActivity;

public class AuxMethods {


    public static final String CHAR = "!!!";
    public static final String SEMICOLON = ";";
    public static final String COMMASPACE = ", ";


    public String loadLoggedInUserElem(String parameter, Context context) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String userParam = sharedPreferences.getString(parameter, "");
        return userParam;
    }


    public String loadUsername(Context context){
        return loadLoggedInUserElem(context.getString(R.string.username),context);
    }

    public String loadRole(Context context){
        return loadLoggedInUserElem(context.getString(R.string.role), context);
    }

    public String loadPoints(Context context){
        return loadLoggedInUserElem(context.getString(R.string.points), context);
    }

    public void makeToast(@StringRes Integer messageString, Context context) {
        Toast.makeText(context, messageString, Toast.LENGTH_SHORT).show();
    }

    public void changeActivity(Context currContext, Class<?> toGo){
        Intent intent = new Intent(currContext, toGo);
        currContext.startActivity(intent);
    }

    public AlertDialog initAlert(Context context, @StringRes Integer title, @StringRes Integer message){
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(context.getString(message));

        return alertDialog;
    }

    public boolean stringContainsStringsFromArray(String string, String[] elems) {
        for(int i =0; i < elems.length; i++) {
            if(string.contains(elems[i]))
                return true;
        }
        return false;
    }

    /**
     * Get centerPoint of polygon
     * @author Thinesh @ stackOverflow.com
     */
    public LatLng getPolygonCenterPoint(ArrayList<LatLng> polygonPointsList){
        LatLng centerLatLng = null;
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        for(int i = 0 ; i < polygonPointsList.size() ; i++)
        {
            builder.include(polygonPointsList.get(i));
        }
        LatLngBounds bounds = builder.build();
        centerLatLng =  bounds.getCenter();

        return centerLatLng;
    }

    public void loadPdfDocument(Context context, String documentUrl){
        AlertDialog alertDialog = new ProgressDialog(context);
        alertDialog.show();
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(documentUrl));
        context.startActivity(browserIntent);
        alertDialog.dismiss();
    }

    public void refreshFragment(Activity activity, int whereTo){
        NavController navController = Navigation.findNavController(activity,R.id.nav_host_fragment_content_main);
        navController.popBackStack();
        navController.navigate(whereTo);
    }





    //region Spinner functions

    // wasted wayyyyyy too much time on this
    public void loadSpinnerValues(Spinner spinner, ArrayAdapter adapter, int messageCode,
                                   int layout, Context context){

        //specify the layout to use when the choices appear
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        //set drop down menu for selecting the ground type
        spinner.setAdapter(adapter);
        spinner.setPrompt(context.getString(messageCode));
        spinner.setAdapter(
                //code to set the "hint" - thank stack overflow for this one
                new NothingSelectedSpinnerAdapter(
                        adapter,
                        layout,
                        context));

    }

    public void processAdapter(Spinner spinner, List<String> elems, CSVReader reader,
                                int messageCode, int layout, Context context){
        ArrayAdapter<String> adapterDistrict = new ArrayAdapter<String>(context,
                android.R.layout.simple_spinner_item, elems);

        loadSpinnerValues(spinner, adapterDistrict, messageCode, layout, context);
    }

    /**
     * Sets the spinner, which is a kind of drop down menu
     */
    public void setSpinnerAdapterType(Spinner spinner, int messageCode, String location, Context context) {

        InputStream inputStream = context.getResources().openRawResource(R.raw.distritos_freguesias_concelhos);
        CSVReader reader = new CSVReader(inputStream);

        switch (messageCode){
            case R.string.selectGroundType:
                ArrayAdapter<CharSequence> adapterGround = ArrayAdapter.createFromResource(context,
                        R.array.ground_types, android.R.layout.simple_spinner_item);

                loadSpinnerValues(spinner,adapterGround,messageCode,
                        R.layout.contact_spinner_row_nothing_selected, context);
                break;
            case R.string.selectDistrict:
                List<String> allDistricts = reader.allDistricts();

                processAdapter(spinner,allDistricts,reader,messageCode,
                        R.layout.contact_spinner_row_nothing_selected_district, context);

                break;
            case R.string.selectCounty:
                List<String> allCounties;

                if(location != "")
                    allCounties = reader.allCountiesFromDistrict(location);
                else{
                    allCounties = reader.allCounties();
                }

                processAdapter(spinner, allCounties, reader, messageCode,
                        R.layout.contact_spinner_row_nothing_selected_county, context);
                break;
            case R.string.selectMunicipality:
                List<String> allMunicipalities;
                if(location != ""){
                    allMunicipalities = reader.allMunicipalitiesFromCounty(location);
                }else{
                    allMunicipalities = reader.allMunicipalities();
                }

                processAdapter(spinner, allMunicipalities, reader, messageCode,
                        R.layout.contact_spinner_row_nothing_selected_municipality, context);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + messageCode);
        }

    }

    //endregion

}

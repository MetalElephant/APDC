package pt.unl.fct.loginapp.data.users.model.logout;

public class LogoutData {
    private String username;

    public LogoutData(String username) {
        this.username = username;
    }

    public String getUsername(){
        return username;
    }
}

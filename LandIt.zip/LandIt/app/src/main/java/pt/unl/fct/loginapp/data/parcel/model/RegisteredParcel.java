package pt.unl.fct.loginapp.data.parcel.model;

public class RegisteredParcel {

    public RegisteredParcel(){}

}

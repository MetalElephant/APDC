package pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo;

import static pt.unl.fct.loginapp.util.AuxMethods.COMMASPACE;
import static pt.unl.fct.loginapp.util.AuxMethods.SEMICOLON;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;

import java.util.ArrayList;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.ActivityParcelInfoBinding;
import pt.unl.fct.loginapp.ui.homepage.HomePageActivity;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class ParcelInfoActivity extends AppCompatActivity {

    private static final int MARKER_NUMBER_POSITION = 6;
    private ActivityParcelInfoBinding binding;
    private SupportMapFragment mapFragment;
    private ParcelViewModel parcelViewModel;
    TextView parcelOwnersText;
    EditText parcelNameEditText;
    TextView parcelRegionEditText;
    EditText parcelDescriptionEditText;
    EditText parcelGroundTypeEditText;
    EditText parcelCurrUsageEditText;
    EditText parcelPrevUsageEditText;
    EditText parcelAreaEditText;
    TextView parcelVerificationText;
    Button updateParcelInfoBtn;
    Button deleteParcelBtn;
    Button verifyParcelBtn;
    Button docBtn;
    ProgressBar loading;
    private GoogleMap parcelMap;
    private ArrayList<LatLng> parcelMarkers;
    private ArrayList<Polygon> parcelPolygons;
    private String parcelName;
    private String parcelOwner;
    private String documentUrl;
    ArrayList<Double> latitudes;
    ArrayList<Double> longitudes;
    private String[] allOwners;
    AuxMethods aux = new AuxMethods();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityParcelInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map2);

        parcelOwnersText = binding.parcelInfoOwners;
        parcelNameEditText = binding.parcelInfoName;
        parcelRegionEditText = binding.parcelInfoLocation;
        parcelDescriptionEditText = binding.parcelInfoDescription;
        parcelGroundTypeEditText = binding.parcelInfoGroundType;
        parcelCurrUsageEditText = binding.parcelInfoCurrUsage;
        parcelPrevUsageEditText = binding.parcelInfoPrevUsage;
        parcelAreaEditText = binding.parcelInfoArea;
        parcelVerificationText = binding.parcelIsConfirmed;
        loading = binding.loadingParcelUpdateInfo;
        updateParcelInfoBtn = binding.updateParcelInfoBtn;
        deleteParcelBtn = binding.deleteParcelBtn;
        verifyParcelBtn = binding.verifyParcelInfoBtn;
        docBtn = binding.seeDocumentButton;

        parcelMarkers = new ArrayList<>();
        parcelPolygons = new ArrayList<>();
        latitudes = new ArrayList<>();
        longitudes = new ArrayList<>();
        String username = aux.loadUsername(getApplicationContext());
        String role = aux.loadRole(getApplicationContext());

        loading.setVisibility(View.GONE);

        if(Roles.isRep(role)){
            deleteParcelBtn.setVisibility(View.GONE);
            updateParcelInfoBtn.setVisibility(View.GONE);
            verifyParcelBtn.setVisibility(View.VISIBLE);
        }

        //region updateParcel
        //update parcels values
        updateParcelInfoBtn.setOnClickListener(view -> {
            loading.setVisibility(View.VISIBLE);

            //String userWhoModifies = username;
            //String userOwner = username;
            String pName = toText(parcelNameEditText).trim();
            String description = toText(parcelDescriptionEditText);
            String groundType = toText(parcelGroundTypeEditText);
            String currUsage = toText(parcelCurrUsageEditText);
            String prevUsage = toText(parcelPrevUsageEditText);

            double[] allLats = convertToDoubleArray(latitudes);
            double[] allLongs = convertToDoubleArray(longitudes);

            if(allOwners[0].equals(""))
                allOwners = new String[]{};

            parcelViewModel.updateParcel(username, parcelOwner, allOwners, pName, description, groundType,
                    currUsage, prevUsage, allLats, allLongs);

        });

        //observer for update result
        parcelViewModel.getUpdateParcelResult().observe(this, parcelResult -> {

            if (parcelResult == null) {
                return;
            }

            loading.setVisibility(View.GONE);
            if (parcelResult.getError() != null) {
                aux.makeToast(R.string.defaultError, getApplicationContext());
            }
            if (parcelResult.getSuccess() != null) { //where we change the page being shown
                aux.makeToast(R.string.updateUserSuccess, getApplicationContext());
            }
        });

        //forms
        parcelViewModel.getParcelUpdateFormState().observe(this, parcelUpdateFormState -> {

            if(parcelUpdateFormState == null){
                return;
            }

            updateParcelInfoBtn.setEnabled(parcelUpdateFormState.isDataValid());

            if (parcelUpdateFormState.getParcelNameError() != null) {
                parcelNameEditText.setError(getString(parcelUpdateFormState.getParcelNameError()));
            }
            if(parcelUpdateFormState.getDescriptionError() != null){
                parcelDescriptionEditText.setError(getString(parcelUpdateFormState.getDescriptionError()));
            }
            if(parcelUpdateFormState.getCurrUsageError() != null){
                parcelCurrUsageEditText.setError(getString(parcelUpdateFormState.getCurrUsageError()));
            }
            if(parcelUpdateFormState.getPrevUsageError() != null){
                parcelPrevUsageEditText.setError(getString(parcelUpdateFormState.getPrevUsageError()));
            }
            if(parcelUpdateFormState.getGroundTypeError() != null){
                parcelGroundTypeEditText.setError(getString(parcelUpdateFormState.getGroundTypeError()));
            }

        });

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                parcelViewModel.updateDataChanged(toText(parcelNameEditText),
                        toText(parcelDescriptionEditText),
                        toText(parcelGroundTypeEditText),
                        toText(parcelCurrUsageEditText),
                        toText(parcelPrevUsageEditText));
            }
        };

        parcelNameEditText.addTextChangedListener(textWatcher);
        parcelDescriptionEditText.addTextChangedListener(textWatcher);
        parcelCurrUsageEditText.addTextChangedListener(textWatcher);
        parcelPrevUsageEditText.addTextChangedListener(textWatcher);
        parcelGroundTypeEditText.addTextChangedListener(textWatcher);

        //endregion

        //region delete Parcel
        deleteParcelBtn.setOnClickListener(view -> {

            AlertDialog alertDialog = aux.initAlert(ParcelInfoActivity.this,R.string.deleteParcel, R.string.deleteParcelWarning);

            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes),
                    (dialogInterface, i) -> {
                        loading.setVisibility(View.VISIBLE);
                        parcelViewModel.removeParcel(username,parcelOwner, parcelName);

                    });
            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no),
                    (dialogInterface, i) -> {
                    });
            alertDialog.show();

        });


        //delete parcel observer result
        parcelViewModel.getRemoveParcelResult().observe(this,parcelResult -> {
            if (parcelResult == null) {
                return;
            }

            loading.setVisibility(View.GONE);

            if (parcelResult.getError() != null) {
                aux.makeToast(R.string.defaultError, getApplicationContext());
            }
            if (parcelResult.getSuccess() != null) { //where we change the page being shown
                aux.makeToast(R.string.deleteParcelSuccess, getApplicationContext());

                finish();
            }
        });

        //endregion

        //region verify parcel
        verifyParcelBtn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), VerifyParcelActivity.class);
            intent.putExtra(getString(R.string.parcel),parcelName);
            intent.putExtra(getString(R.string.user), parcelOwner);
            intent.putExtra(getString(R.string.verification), documentUrl);
            startActivity(intent);
            finish();
        });

        //endregion

        //region map handling
        mapFragment.getMapAsync(googleMap -> {

            parcelMap = googleMap;

            loadParcelInfo();

            parcelMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
                @Override
                public void onMarkerDrag(@NonNull Marker marker) {

                }

                @Override
                public void onMarkerDragEnd(@NonNull Marker marker) {

                    LatLng newPosition = marker.getPosition();

                    /*get which marker, so we can replace its value in list of markers
                    and update array of latitudes and longitudes, bc ArrayList mantains order*/
                    String title = marker.getTitle();
                    int markerPos = Integer.parseInt(
                            title.substring(MARKER_NUMBER_POSITION).trim());
                    parcelMarkers.set(markerPos, newPosition);
                    latitudes.set(markerPos, newPosition.latitude);
                    longitudes.set(markerPos, newPosition.longitude);

                    updateArea();

                }

                @Override
                public void onMarkerDragStart(@NonNull Marker marker) {

                }
            });

            parcelMap.setOnMapClickListener(latLng -> {

                addMarker(latLng);
                latitudes.add(latLng.latitude);
                longitudes.add(latLng.longitude);
                updateArea();

            });

        });

        //endregion

        //region download confirmation document
        docBtn.setOnClickListener(view -> { ;
           aux.loadPdfDocument(ParcelInfoActivity.this,documentUrl);
        });

        //endregion

    }

    private double[] convertToDoubleArray(ArrayList<Double> list){
        double[] target = new double[list.size()];
        for (int i = 0; i < target.length; i++) {
            target[i] = list.get(i);
        }
        return target;
    }

    private void loadParcelInfo(){

        try {
            String received = getIntent().getStringExtra(getString(R.string.parcel));

            int i = 0;
            String[] allElems = received.split("!!!");
            parcelOwner = allElems[i++];
            parcelName = allElems[i++];
            parcelNameEditText.setText(parcelName);
            String county = allElems[i++];
            String district = allElems[i++];
            String municipality = allElems[i++];
            parcelRegionEditText.setText(district + COMMASPACE + county + COMMASPACE + municipality);
            String description = allElems[i++];
            parcelDescriptionEditText.setText(description);
            String groundType = allElems[i++];
            parcelGroundTypeEditText.setText(groundType);
            String currUsage = allElems[i++];
            parcelCurrUsageEditText.setText(currUsage);
            String prevUsage = allElems[i++];
            parcelPrevUsageEditText.setText(prevUsage);
            String area = allElems[i++];
            parcelAreaEditText.setText(area);
            documentUrl = allElems[i++];
            String isVerified = allElems[i++];;
            if(isVerified.equals(ParcelInfo.YES)){
                verifyParcelBtn.setVisibility(View.GONE);
                parcelVerificationText.setText(R.string.parcelVerified);
            }else{
                parcelVerificationText.setText(R.string.parcelNotVerified);
            }

            String markers = allElems[i++];
            processMarkers(markers);
            String owners = allElems[i++];;
            processOwners(owners, parcelOwner);

        }catch (Exception e) {
            e.printStackTrace();
        }
    }


    //A lot of conversions because Android studio gave me issues trying to pass entire arrays between
    // activities and fragment

    /**
     * Process and add markers and polygon for this parcel to map
     */
    private void processMarkers(String markers){
        String markersClean = markers.substring(1, markers.length()-1);
        String[] markersTemp = markersClean.split(COMMASPACE);

       for (int i = 0; i < markersTemp.length; i++) {
            String[] latLng = markersTemp[i].split(SEMICOLON);
            double lat = Double.valueOf(latLng[0]);
            double lon = Double.valueOf(latLng[1]);
            LatLng newMarker = new LatLng(lat,lon);
            addMarker(newMarker, i);

            //saving the values so we can later send in REST call if user updates the parcel
            latitudes.add(lat);
            longitudes.add(lon);
        }

        addArea();
        //zoom in on center point
        LatLng center = aux.getPolygonCenterPoint(parcelMarkers);
        parcelMap.animateCamera(CameraUpdateFactory.newLatLngZoom(center, 15));


    }

    private void processOwners(String owners, String owner){
        String allOwnersTemp = owners.substring(1, owners.length()-1);
        allOwners = allOwnersTemp.split(COMMASPACE);
        String parcelOwners = "";
        if(allOwnersTemp.length()!=0)
            parcelOwners = owner + COMMASPACE + allOwnersTemp;
        else{
            parcelOwners = owner;
        }
        parcelOwnersText.setText(parcelOwners);

    }

    private void addMarker(LatLng latLng, int pos){
        MarkerOptions markerOptions = new MarkerOptions();

        //set position of marker
        markerOptions.position(latLng);

        //add marker to map and allow to be dragged, for update purposes
        Marker m = parcelMap.addMarker(markerOptions);
        m.setDraggable(true);
        m.setTitle(getString(R.string.marker) + " "+ pos);

        parcelMarkers.add(latLng);

    }

    private void addMarker(LatLng latLng){
        addMarker(latLng, parcelMarkers.size());
    }

    private void addArea(){
        Polygon p = parcelMap.addPolygon(new PolygonOptions()
                .addAll(parcelMarkers)
                .strokeColor(Color.BLACK)
                .fillColor(Color.GRAY));
        parcelPolygons.add(p);



    }

    private void updateArea(){
        for (Polygon p: parcelPolygons) {
            p.remove();
        }
        parcelPolygons.clear();

        addArea();

    }

    private String toText(EditText editText){
        return editText.getText().toString();
    }


}
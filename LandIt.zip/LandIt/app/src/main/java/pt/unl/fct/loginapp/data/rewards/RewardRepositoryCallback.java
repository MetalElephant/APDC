package pt.unl.fct.loginapp.data.rewards;

import pt.unl.fct.loginapp.data.Result;

public interface RewardRepositoryCallback<T> {
    void onComplete(Result<T> result);
}

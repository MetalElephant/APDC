package pt.unl.fct.loginapp.data.users;

import pt.unl.fct.loginapp.data.RestAPI;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.model.login.LoginData;
import pt.unl.fct.loginapp.data.users.model.logout.LogoutData;
import pt.unl.fct.loginapp.data.users.model.register.RegisterData;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;

import java.io.IOException;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    private final RestAPI service;

    public LoginDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://land--it.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        this.service = retrofit.create(RestAPI.class);
    }

    //finally the logic of the login itself
    public Result<LoggedInUser> login(String username, String password) {

        try {
            // TODO: handle loggedInUser authentication
            // Call the REST services and do the post
            Call<LoggedInUser> loginService = service.doLogin(new LoginData(username,password)) ;
            Response<LoggedInUser> loginResponse = loginService.execute();

            String a = "hey";

            if( loginResponse.isSuccessful() ) {
                LoggedInUser user = loginResponse.body();
                return new Result.Success<>(user);
            } else {
                return new Result.Error(new Exception("Server result code: " + loginResponse.code() ));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<LoggedOutUser> logout(String username) {
            try {
                // Call the REST services and do the post
                Call<LoggedOutUser> logoutService = service.doLogout(new LogoutData(username)) ;
                Response<LoggedOutUser> logoutResponse = logoutService.execute();

                if( logoutResponse.isSuccessful() ) {
                    LoggedOutUser user = logoutResponse.body();
                    return new Result.Success<>(user);
                } else {
                    return new Result.Error(new Exception("Server result code: " + logoutResponse.code() ));
                }
            } catch (Exception e) {
                return new Result.Error(new IOException("Error logging out", e));
            }
    }

    public Result<RegisteredUser> register(String username, String password, String confirmation, String email, String name, String visibility, String homePhone, String mobilePhone, String address, String nif) {

        try {
            // Call the REST services and do the post
            Call<RegisteredUser> registerService = service.doRegister(new RegisterData(username,password,confirmation,email,name,visibility,homePhone,mobilePhone,address,nif)) ; //TODO
            Response<RegisteredUser> registerResponse = registerService.execute();
            if( registerResponse.isSuccessful() ) {
                RegisteredUser user = registerResponse.body();
                return new Result.Success<>(user);
            } else {
                return new Result.Error(new Exception("Server result code: " + registerResponse.code() ));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error registering" + e.toString(), e));
        }
    }


}
package pt.unl.fct.loginapp.ui.homepage;

import androidx.annotation.Nullable;


public class LogoutResult {

    @Nullable
    private LoggedOutUserView success;
    @Nullable
    private Integer error;

    public LogoutResult(@Nullable Integer error) {
        this.error = error;
    }

    public LogoutResult(@Nullable LoggedOutUserView success) {
        this.success = success;
    }

    @Nullable
    LoggedOutUserView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}

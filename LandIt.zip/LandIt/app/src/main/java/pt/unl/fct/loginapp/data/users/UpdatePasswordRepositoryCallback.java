package pt.unl.fct.loginapp.data.users;


import pt.unl.fct.loginapp.data.Result;

public interface UpdatePasswordRepositoryCallback<T> {
    void onComplete(Result<T> result);


}

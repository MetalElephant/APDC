package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import androidx.annotation.Nullable;

public class ParcelUpdateFormState {

    @Nullable
    private Integer parcelNameError;
    @Nullable
    private Integer descriptionError;
    @Nullable
    private Integer groundTypeError;
    @Nullable
    private Integer currUsageError;
    @Nullable
    private Integer prevUsageError;

    private boolean isDataValid;

    ParcelUpdateFormState(@Nullable Integer parcelNameError, @Nullable Integer descriptionError,
                          @Nullable Integer groundTypeError, @Nullable Integer currUsageError,
                          @Nullable Integer prevUsageError) {
        this.parcelNameError = parcelNameError;
        this.descriptionError = descriptionError;
        this.groundTypeError = groundTypeError;
        this.currUsageError = currUsageError;
        this.prevUsageError = prevUsageError;
        this.isDataValid = false;
    }

    ParcelUpdateFormState(boolean isDataValid) {
        this.parcelNameError = null;
        this.descriptionError = null;
        this.groundTypeError = null;
        this.currUsageError = null;
        this.prevUsageError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getParcelNameError() {
        return parcelNameError;
    }

    @Nullable
    public Integer getDescriptionError() {
        return descriptionError;
    }

    @Nullable
    public Integer getGroundTypeError() {
        return groundTypeError;
    }

    @Nullable
    public Integer getCurrUsageError() {
        return currUsageError;
    }

    @Nullable
    public Integer getPrevUsageError() {
        return prevUsageError;
    }

    public boolean isDataValid() {
        return isDataValid;
    }
}

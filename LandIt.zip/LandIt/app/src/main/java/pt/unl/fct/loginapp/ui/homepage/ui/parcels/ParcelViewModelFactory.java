package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import pt.unl.fct.loginapp.LandIt;
import pt.unl.fct.loginapp.data.parcel.ParcelDataSource;
import pt.unl.fct.loginapp.data.parcel.ParcelRepository;

public class ParcelViewModelFactory implements ViewModelProvider.Factory {
    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(ParcelViewModel.class)) {
            return (T) new ParcelViewModel(ParcelRepository.getInstance(new ParcelDataSource(), LandIt.getExecutorService()));
        } else {
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }
}

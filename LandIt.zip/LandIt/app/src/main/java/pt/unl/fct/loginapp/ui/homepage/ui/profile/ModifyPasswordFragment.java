package pt.unl.fct.loginapp.ui.homepage.ui.profile;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.google.android.material.snackbar.Snackbar;

import pt.unl.fct.loginapp.databinding.ModifyPasswordFragmentBinding;
import pt.unl.fct.loginapp.ui.initial.users.UpdatePwdFormState;
import pt.unl.fct.loginapp.ui.initial.users.UpdatePwdResult;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModel;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.R;


public class ModifyPasswordFragment extends Fragment {

    private ModifyPasswordFragmentBinding binding;
    private UserViewModel userViewModel;
    private AuxMethods aux = new AuxMethods();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        ModifyPasswordViewModel modifyPasswordViewModel =
                new ViewModelProvider(this).get(ModifyPasswordViewModel.class);

        userViewModel = new ViewModelProvider(this, new UserViewModelFactory())
                .get(UserViewModel.class);

        binding = ModifyPasswordFragmentBinding.inflate(inflater, container, false);

        View root = binding.getRoot();
        String username = aux.loadUsername(getContext());

        EditText prevPwdEdit = binding.prevPwdInput;
        EditText newPwdEdit = binding.newPwdInput;
        EditText newPwdConfirmationEdit = binding.newPwdConfirmation;
        ProgressBar loading = binding.loadingModifyPwd;
        loading.setVisibility(View.GONE);
        Button modifyPwdBtn = binding.modifyPwdBtn2;


        //region forms

        //deal with changes in the forms
        userViewModel.getUpdatePwdFormState().observe(getViewLifecycleOwner(), updatePwdFormState -> {
            if (updatePwdFormState == null) {
                return;
            }
            modifyPwdBtn.setEnabled(updatePwdFormState.isDataValid());

            if (updatePwdFormState.getPrevPwdError() != null) {
                prevPwdEdit.setError(getString(updatePwdFormState.getPrevPwdError()));
            }
            if (updatePwdFormState.getNewPwdError() != null) {
                newPwdEdit.setError(getString(updatePwdFormState.getNewPwdError()));
            }
            if (updatePwdFormState.getPwdConfirmationError() != null) {
                newPwdConfirmationEdit.setError(getString(updatePwdFormState.getPwdConfirmationError()));
            }
        });

        //region textwatcher
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                userViewModel.updatePwdDataChanged(prevPwdEdit.getText().toString(),
                        newPwdEdit.getText().toString(), newPwdConfirmationEdit.getText().toString());
            }
        };

        prevPwdEdit.addTextChangedListener(textWatcher);
        newPwdEdit.addTextChangedListener(textWatcher);
        newPwdConfirmationEdit.addTextChangedListener(textWatcher);
        //endregion

        //endregion

        //region modifyPassword
        modifyPwdBtn.setOnClickListener(view -> {
            loading.setVisibility(View.VISIBLE);

            userViewModel.updatePwd(username,prevPwdEdit.getText().toString(),
                    newPwdEdit.getText().toString(),
                    newPwdConfirmationEdit.getText().toString());

        });

        //result observer
        userViewModel.getUpdatePwdResult().observe(getViewLifecycleOwner(), updatePwdResult -> {

            if(updatePwdResult == null){
                return;
            }
            loading.setVisibility(View.GONE);

            if(updatePwdResult.getError() != null){
                aux.makeToast(updatePwdResult.getError(), getContext());
            }
            if(updatePwdResult.getSuccess() != null){
                Snackbar.make(root, R.string.updatePwdSuccess, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }

        });

        //endregion

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
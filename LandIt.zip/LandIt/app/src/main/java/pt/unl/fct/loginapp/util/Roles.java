package pt.unl.fct.loginapp.util;

import androidx.annotation.NonNull;

public enum Roles {
    PROPRIETARIO("PROPRIETARIO"),
    COMERCIANTE("COMERCIANTE"),
    MODERADOR("MODERADOR"),
    REPRESENTANTE("REPRESENTANTE"),
    SUPERUSER("SUPERUSER");

    private final String text;

    Roles(final String text) {
        this.text = text;
    }

    public static boolean isMod(@NonNull String user) {
        return user.equalsIgnoreCase(MODERADOR.text);

    }
    public static boolean isOwner(@NonNull String user){
        return user.equalsIgnoreCase(PROPRIETARIO.text);
    }
    public static boolean isMerchant(@NonNull String user){
        return user.equalsIgnoreCase(COMERCIANTE.text);
    }
    public static boolean isRep(@NonNull String user){
        return user.equalsIgnoreCase(REPRESENTANTE.text);
    }
    //public boolean isMod(@NonNull String user){        return user.equalsIgnoreCase(MODERADOR.text);    }
    public static boolean isSuperuser(@NonNull String user){
        return user.equalsIgnoreCase(SUPERUSER.text);
    }

    public static boolean isModOrSU(@NonNull String user) {
        return isMod(user) || isSuperuser(user);
    }

    public static boolean isModOrSUOrMerchant(@NonNull String user){
        return isModOrSU(user) || isMerchant(user);
    }


    @Override
    public String toString() {
        return text;
    }
}

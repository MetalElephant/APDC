package pt.unl.fct.loginapp.data.forum.model;

public class RemoveMessageData {
    public String username, forumOwner, forumName, msg, msgOwner;

    public RemoveMessageData(){}

    public RemoveMessageData(String username, String forumOwner, String forumName, String msg, String msgOwner){
        this.username = username;
        this.forumOwner = forumOwner;
        this.forumName = forumName;
        this.msg = msg;
        this.msgOwner = msgOwner;
    }
}

package pt.unl.fct.loginapp.data.users;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import pt.unl.fct.loginapp.data.RestAPI;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.RequestData;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.model.login.LoginData;
import pt.unl.fct.loginapp.data.users.model.logout.LogoutData;
import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;
import pt.unl.fct.loginapp.data.users.model.register.RegisterData;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import pt.unl.fct.loginapp.data.users.model.updateInfo.UserUpdateData;
import pt.unl.fct.loginapp.data.users.model.updatePwd.PasswordUpdateData;
import pt.unl.fct.loginapp.data.users.model.updatePwd.UpdatedPwdUser;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;

import java.io.IOException;
import java.util.List;

public class UserDataSource {

    Gson gson = new GsonBuilder().setLenient().create();
    private final RestAPI service;

    public UserDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://landit-app.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        this.service = retrofit.create(RestAPI.class);
    }

    public Result<LoggedInUser> login(String username, String password) {

        try {
            // Call the REST services and do the post
            Call<LoggedInUser> loginService = service.doLogin(new LoginData(username,password)) ;
            Response<LoggedInUser> loginResponse = loginService.execute();

            if( loginResponse.isSuccessful() ) {
                LoggedInUser user = loginResponse.body();
                return new Result.Success<>(user);
            } else {
                return new Result.Error(new Exception("Server result code: " + loginResponse.code() ));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<LoggedOutUser> logout(String username) {
            try {
                // Call the REST services and do the post
                Call<LoggedOutUser> logoutService = service.doLogout(new LogoutData(username)) ;
                Response<LoggedOutUser> logoutResponse = logoutService.execute();

                if( logoutResponse.isSuccessful() ) {
                    LoggedOutUser user = logoutResponse.body();
                    return new Result.Success<>(user);
                } else {
                    return new Result.Error(new Exception("Server result code: " + logoutResponse.code() ));
                }
            } catch (Exception e) {
                return new Result.Error(new IOException("Error logging out", e));
            }
    }

    public Result<RegisteredUser> register(String username, String password, String confirmation,
                                           String email, String name, String role,
                                           String district, String county, String municipality,
                                           String street, String homePhone, String mobilePhone,
                                           String nif, String code,byte[]photo) {

        try {
            // Call the REST services and do the post
            try {
                Call<RegisteredUser> registerService = service.doRegister(new RegisterData(
                        username, password, confirmation, email, name, role, district, county,
                        municipality, street, homePhone, mobilePhone, nif, code, photo));
                Response<RegisteredUser> registerResponse = registerService.execute();
                if (registerResponse.isSuccessful()) {
                    RegisteredUser user = registerResponse.body();
                    return new Result.Success<>(user);
                } else {
                    return new Result.Error(new Exception("Server result code: " + registerResponse.code()));
                }
            }catch (java.lang.NullPointerException e){
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error registering" + e.toString(), e));
        }
    }


    public Result<UpdatedPwdUser> updatePwd(String username, String prevPwd, String newPwd, String pwdConfirmation) {

        try {

            try {
                // Call the REST services and do the post
                Call<UpdatedPwdUser> updatePwdService = service
                        .doUpdatePwd(new PasswordUpdateData(username, prevPwd, newPwd, pwdConfirmation));
                Response<UpdatedPwdUser> updateResponse = updatePwdService.execute();

                if (updateResponse.isSuccessful()) {
                    UpdatedPwdUser user = updateResponse.body();
                    return new Result.Success<>(user);
                } else {
                    return new Result.Error(new Exception("Server result code: " + updateResponse.code()));
                }
            }catch (java.io.IOException e){
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging out", e));
        }

    }

    public Result<UserInfo> getUserInfo(String username) {

        try {
            // Call the REST services and do the post
            Call<UserInfo> userInfoService = service.getInfo(new RequestData(username));
            Response<UserInfo> response = userInfoService.execute();

            if( response.isSuccessful() ) {
                UserInfo userInfo = response.body();
                return new Result.Success<>(userInfo);
            } else {
                return new Result.Error(new Exception("Server result code: " + response.code() ));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging out", e));
        }
    }

    public Result<RegisteredUser> updateUser(String username, String usernameToUpdate, String name,
                                             String email, String district, String county,
                                             String municipality, String street,String homePhone,
                                             String mobilePhone, String nif) {
        try {
            try {
                Call<RegisteredUser> updateUserService = service.doUpdateUser(new UserUpdateData(username,
                        usernameToUpdate, name, email, district, county,municipality, street,
                        homePhone, mobilePhone, nif));
                Response<RegisteredUser> response = updateUserService.execute();

                if (response.isSuccessful()) {
                    RegisteredUser user = response.body();
                    return new Result.Success<>(user);
                } else {
                    return new Result.Error(new Exception("Server result code: " + response.code()));
                }
            }catch (java.io.IOException e) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error", e));
        }
    }


    public Result<List<UserInfo>> listUsers(){
        try{
            try{
                Call<List<UserInfo>> showUserService = service.listAllUsers();
                Response<List<UserInfo>> response = showUserService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<UserInfo> allUsers= response.body();
                    return new Result.Success<>(allUsers);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error showing parcels" + e.toString(), e));
        }
    }

    public Result<RegisteredUser> removeUser(String username, String name) {
        try {
            // Call the REST services and do the post
            try {
                Call<RegisteredUser> removeUserService = service.removeUser(new RequestData(username, name));
                Response<RegisteredUser> response = removeUserService.execute();

                if (response.isSuccessful()) {
                    RegisteredUser user = response.body();
                    return new Result.Success<>(user);
                } else {
                    return new Result.Error(new Exception("Server result code: " + response.code()));
                }
            } catch (java.io.IOException e) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging out", e));
        }

    }


}
package pt.unl.fct.loginapp.data.rewards.model;

public class RemoveObjectData {

    public String username, owner, objectName;

    public RemoveObjectData(){}

    public RemoveObjectData(String username, String owner, String objectName){
        this.username = username;
        this.owner = owner;
        this.objectName = objectName;
    }
}

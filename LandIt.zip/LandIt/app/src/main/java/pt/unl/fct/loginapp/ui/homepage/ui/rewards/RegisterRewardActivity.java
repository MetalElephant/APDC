package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.databinding.ActivityForumBinding;
import pt.unl.fct.loginapp.databinding.ActivityRegisterRewardBinding;
import pt.unl.fct.loginapp.util.AuxMethods;

public class RegisterRewardActivity extends AppCompatActivity {
    private ActivityRegisterRewardBinding binding;
    private RewardViewModel rewardViewModel;
    private AuxMethods aux = new AuxMethods();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRegisterRewardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        rewardViewModel =
                new ViewModelProvider(this, new RewardViewModelFactory())
                        .get(RewardViewModel.class);

        String username = aux.loadUsername(getApplicationContext());

        EditText rewardNameEditText = binding.rewardNameEditText;
        EditText rewardDescriptionEditText = binding.rewardDescriptionEditText;
        EditText rewardPriceEditText = binding.rewardPriceEditText;
        Button registerBtn = binding.registerRewardBtn;

        //region data changed
        rewardViewModel.getRegisterDataChanged().observe(this, registerRewardFormState -> {
            if (registerRewardFormState == null) {
                return;
            }
            registerBtn.setEnabled(registerRewardFormState.isDataValid());

            if (registerRewardFormState.getRewardNameError() != null) {
                rewardNameEditText.setError(getString(registerRewardFormState.getRewardNameError()));
            }
            if (registerRewardFormState.getDescriptionError() != null) {
                rewardDescriptionEditText.setError(getString(registerRewardFormState.getDescriptionError()));
            }
            if (registerRewardFormState.getPriceError() != null) {
                rewardPriceEditText.setError(getString(registerRewardFormState.getPriceError()));
            }
        });

        //region textwatcher
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                rewardViewModel.registerDataChanged(rewardNameEditText.getText().toString(),
                        rewardDescriptionEditText.getText().toString(), rewardPriceEditText.getText().toString());
            }
        };

        rewardNameEditText.addTextChangedListener(textWatcher);
        rewardDescriptionEditText.addTextChangedListener(textWatcher);
        rewardPriceEditText.addTextChangedListener(textWatcher);

        //endregion

        //endregion

        //region btn and observer
        registerBtn.setOnClickListener(view -> {

            rewardViewModel.register(rewardNameEditText.getText().toString(),
                    rewardDescriptionEditText.getText().toString(), username,
                    rewardPriceEditText.getText().toString());
        });

        rewardViewModel.getRewardResult().observe(this, rewardResult -> {
            if(rewardResult == null)
                return;

            if(rewardResult.getError() != null) {
                aux.makeToast(rewardResult.getError(),getApplicationContext());

            }

            if(rewardResult.getSuccess() != null){
                aux.makeToast(R.string.registerRewardSuccess, getApplicationContext());
                finish();

            }

        });


        //endregion



    }
}
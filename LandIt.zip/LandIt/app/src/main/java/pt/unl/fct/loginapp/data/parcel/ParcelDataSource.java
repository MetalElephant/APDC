package pt.unl.fct.loginapp.data.parcel;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.util.List;

import pt.unl.fct.loginapp.data.RestAPI;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.model.ParcelData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.RegisteredParcel;
import pt.unl.fct.loginapp.data.parcel.model.RequestData;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.RegisteredParcelView;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ParcelDataSource {

   private final RestAPI service;
    Gson gson = new GsonBuilder().setLenient().create();

    public ParcelDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://land--it.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        this.service = retrofit.create(RestAPI.class);
    }

    public Result<RegisteredParcel> registerParcel(String owner, String[] owners, String name, String county, String district, String freguesia, String description,
                                                   String groundType, String currUsage,String prevUsage, String area,
                                                   double[] allLats, double[] allLongs) {
        try {

            try{
            // Call the REST services and do the post
            Call<RegisteredParcel> registerService = service.doRegisterParcel(
                    new ParcelData(owner, owners, name, county, district, freguesia, description, groundType,currUsage,
                            prevUsage, area, allLats, allLongs)) ;

            Response<RegisteredParcel> registeredParcelResponse = registerService.execute();
            gson.toJson(registeredParcelResponse);
            if( registeredParcelResponse.isSuccessful() ) {
                RegisteredParcel parcel = registeredParcelResponse.body();
                return new Result.Success<>(parcel);
            } else {
                return new Result.Error(new Exception("Server result code: " + registeredParcelResponse.code() ));
            }

            }catch(IllegalStateException | JsonSyntaxException exception){
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error registering parcel" + e.toString(), e));
        }
    }

    public Result<List<ParcelInfo>> showParcels(String username) {

        try{
            try{
                Call<List<ParcelInfo>> showListService = service.doShowParcel(new RequestData(username));
                Response<List<ParcelInfo>> response = showListService.execute();
                gson.toJson(response); //TODO maybe?

                if(response.isSuccessful()){
                    List<ParcelInfo> allParcels= response.body();
                    return new Result.Success<>(allParcels);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error showing parcels" + e.toString(), e));
        }
    }
}

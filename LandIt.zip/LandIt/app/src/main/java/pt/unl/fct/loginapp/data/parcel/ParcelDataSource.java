package pt.unl.fct.loginapp.data.parcel;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.util.List;

import pt.unl.fct.loginapp.data.RestAPI;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.model.ParcelData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.ParcelSearchRegionData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelUpdateData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelVerifyData;
import pt.unl.fct.loginapp.data.parcel.model.RegisteredParcel;
import pt.unl.fct.loginapp.data.parcel.model.RequestData;
import pt.unl.fct.loginapp.data.rewards.model.RemoveObjectData;
import pt.unl.fct.loginapp.data.users.model.updatePwd.PasswordUpdateData;
import pt.unl.fct.loginapp.data.users.model.updatePwd.UpdatedPwdUser;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.RegisteredParcelView;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ParcelDataSource {

   private final RestAPI service;
   Gson gson = new GsonBuilder().setLenient().create();
   private static final int DEFAULT_TYPE = 1;

    public ParcelDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://landit-app.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        this.service = retrofit.create(RestAPI.class);
    }

    public Result<RegisteredParcel> registerParcel(String owner, String[] owners, String name, String county, String district, String freguesia, String description,
                                                   String groundType, String currUsage,String prevUsage,
                                                   double[] allLats, double[] allLongs, byte[] confirmation) {
        try {

            try{
            // Call the REST services and do the post
            Call<RegisteredParcel> registerService = service.doRegisterParcel(
                    new ParcelData(owner, owners, name, district, county, freguesia, description, groundType,currUsage,
                            prevUsage, allLats, allLongs, confirmation, DEFAULT_TYPE)) ;

            Response<RegisteredParcel> registeredParcelResponse = registerService.execute();
            gson.toJson(registeredParcelResponse);
            if( registeredParcelResponse.isSuccessful() ) {
                RegisteredParcel parcel = registeredParcelResponse.body();
                return new Result.Success<>(parcel);
            } else {
                return new Result.Error(new Exception("Server result code: " + registeredParcelResponse.code() ));
            }

            }catch(IllegalStateException | JsonSyntaxException exception){
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error registering parcel" + e.toString(), e));
        }
    }

    public Result<List<ParcelInfo>> showParcels(String username) {

        try{
            try{
                Call<List<ParcelInfo>> showListService = service.doShowParcel(new RequestData(username));
                Response<List<ParcelInfo>> response = showListService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<ParcelInfo> allParcels= response.body();
                    return new Result.Success<>(allParcels);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error showing parcels" + e.toString(), e));
        }
    }

    public Result<RegisteredParcel> updateParcel(String username, String username1, String[] owners,
                                                 String pName, String description, String groundType,
                                                 String currUsage, String prevUsage, double[] latitudes,
                                                 double[] longitudes) {
        try {
            try {
                // Call the REST services and do the post
                Call<RegisteredParcel> updateService = service.doUpdateParcel(
                        new ParcelUpdateData(username, username1, owners, pName, description, groundType,
                                currUsage, prevUsage, latitudes, longitudes));
                Response<RegisteredParcel> updateResponse = updateService.execute();

                if (updateResponse.isSuccessful()) {
                    RegisteredParcel parcel = updateResponse.body();
                    return new Result.Success<>(parcel);
                } else {
                    return new Result.Error(new Exception("Server result code: " + updateResponse.code()));
                }
            }catch (IllegalStateException | JsonSyntaxException | java.io.IOException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging out", e));
        }

    }

    public Result<List<ParcelInfo>> showRepParcels(String username) {

        try{
            try{
                Call<List<ParcelInfo>> showListService = service.showRepParcels(new RequestData(username));
                Response<List<ParcelInfo>> response = showListService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<ParcelInfo> allParcels= response.body();
                    return new Result.Success<>(allParcels);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error showing parcels" + e.toString(), e));
        }
    }


    public Result<RegisteredParcel> verifyParcel(String username, String owner, String parcelName,
                                                 String reason, boolean confirmation){
        try{
            try{
                Call<RegisteredParcel> verifyService= service.verifyParcel(new ParcelVerifyData(username,
                        owner, parcelName, reason, confirmation));
                Response<RegisteredParcel> response = verifyService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    RegisteredParcel parcel = response.body();
                    return new Result.Success<>(parcel);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }
    }

    public Result<RegisteredParcel> removeParcel(String username, String owner, String parcelName){
        try{
            try{
                Call<RegisteredParcel> removeService= service.removeParcel(new RemoveObjectData(username,
                        owner, parcelName));
                Response<RegisteredParcel> response = removeService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    RegisteredParcel parcel = response.body();
                    return new Result.Success<>(parcel);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException |java.io.IOException e) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }
    }

    public Result<List<ParcelInfo>> showParcelsRegion(String username, String region, int type){
        try{
            try{
                Call<List<ParcelInfo>> showListService = service.listParcelsFromRegion(
                        new ParcelSearchRegionData(username,region, type));
                Response<List<ParcelInfo>> response = showListService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<ParcelInfo> allParcels= response.body();
                    return new Result.Success<>(allParcels);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error showing parcels" + e.toString(), e));
        }
    }



}








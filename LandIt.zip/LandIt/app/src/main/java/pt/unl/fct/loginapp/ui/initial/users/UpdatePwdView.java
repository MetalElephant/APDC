package pt.unl.fct.loginapp.ui.initial.users;

public class UpdatePwdView {
    public UpdatePwdView(){}
}

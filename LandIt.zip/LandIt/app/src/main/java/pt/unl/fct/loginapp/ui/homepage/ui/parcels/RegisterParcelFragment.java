package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.databinding.FragmentRegisterParcelBinding;
import pt.unl.fct.loginapp.ui.homepage.NothingSelectedSpinnerAdapter;
import pt.unl.fct.loginapp.ui.initial.users.LoginActivity;
import pt.unl.fct.loginapp.ui.initial.users.LoginViewModel;
import pt.unl.fct.loginapp.ui.initial.users.LoginViewModelFactory;
import pt.unl.fct.loginapp.ui.initial.users.RegisterFormState;
import pt.unl.fct.loginapp.ui.initial.users.RegisterResult;

public class RegisterParcelFragment extends Fragment {

    private FragmentRegisterParcelBinding binding;
    private ParcelViewModel parcelViewModel;
    private View mView;

    public RegisterParcelFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentRegisterParcelBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Spinner soilSpinner = root.findViewById(R.id.parcelGroundType_input_spinner);//binding.parcelGroundTypeInputSpinner;
        setSpinnerGroundType(soilSpinner);

        Button registerParcelBtn = binding.registerParcelBtn;

        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);




        //----Handling of parcel parameters
        final String username = loadLoggedInUserElem("username");
        final EditText parcelNameEditText = binding.parcelNameInput;
        final EditText parcelRegionEditText = binding.parcelRegionInput;
        final EditText parcelDescriptionEditText = binding.parcelDescriptionInput;
        final Spinner p = (Spinner) binding.parcelGroundTypeInputSpinner;
        //mView = getLayoutInflater().inflate(R.layout.fragment_register_parcel, null);
       // final Spinner parcelGroundType = (Spinner) mView.findViewById(R.id.parcelGroundType_input_spinner);
        //final Spinner parcelGroundType = (Spinner) getActivity().findViewById(R.id.parcelGroundType_input_spinner);
        //final String words= parcelGroundType.getSelectedItem().toString();
        //final String parcelGroundType = soilSpinner.getSelectedItem().toString(); //TODO: this crap doesnt work bc of binding
        final EditText parcelCurrUsageEditText = binding.parcelCurrUsageInput;
        final EditText parcelPrevUsageEditText = binding.parcelPrevUsageInput;
        final EditText parcelAreaEditText = binding.parcelAreaInput;
        final ProgressBar loadingProgressBar = binding.loadingRegisterParcel;

        float[] lats = RegisterParcelFragmentArgs.fromBundle(requireArguments()).getLats();
        float[] longs = RegisterParcelFragmentArgs.fromBundle(requireArguments()).getLongs();

        double[] latitudes = castFloatArray(lats);
        double[] longitudes = castFloatArray(longs);


        //deal with changes in register forms
        parcelViewModel.getParcelFormState().observe(getViewLifecycleOwner(), new Observer<ParcelRegisterFormState>() {

            @Override
            public void onChanged(@Nullable ParcelRegisterFormState parcelRegisterFormState) {
                if (parcelRegisterFormState == null) {
                    return;
                }
                //enables the button to be clickable if condition being true
                registerParcelBtn.setEnabled(parcelRegisterFormState.isDataValid()
                                                /*&& soilSpinner.isSelected()*/);

                //shows the little error messages if info in forms is not correct
                if (parcelRegisterFormState.getParcelNameError() != null) {
                    parcelNameEditText.setError(getString(parcelRegisterFormState.getParcelNameError()));
                }
                else if(parcelRegisterFormState.getDescriptionError() != null){
                    parcelDescriptionEditText.setError(getString(parcelRegisterFormState.getDescriptionError()));
                }
                else if(parcelRegisterFormState.getRegionError() != null){
                    parcelDescriptionEditText.setError(getString(parcelRegisterFormState.getRegionError()));
                }
                else if(parcelRegisterFormState.getCurrUsageError() != null){
                    parcelDescriptionEditText.setError(getString(parcelRegisterFormState.getCurrUsageError()));
                }
                else if(parcelRegisterFormState.getPrevUsageError() != null){
                    parcelDescriptionEditText.setError(getString(parcelRegisterFormState.getPrevUsageError()));
                }
                else if(parcelRegisterFormState.getAreaError() != null){
                    parcelDescriptionEditText.setError(getString(parcelRegisterFormState.getAreaError()));
                }
            }
        });

        //Observer for registerParcelResult
        parcelViewModel.getParcelResult().observe(getViewLifecycleOwner(), new Observer<ParcelResult>() {
            @Override
            public void onChanged(@Nullable ParcelResult parcelResult) {
                if (parcelResult == null) {
                    return;
                }

                loadingProgressBar.setVisibility(View.GONE);

                if (parcelResult.getError() != null) {
                    showRegisterFailed(parcelResult.getError());
                }
                if (parcelResult.getSuccess() != null) { //where we change the page being shown
                    updateUi(parcelResult.getSuccess());

                    //equivalent of pressing back button
                    getActivity().onBackPressed();

                }
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                parcelViewModel.registerDataChanged(parcelNameEditText.getText().toString(),
                        parcelRegionEditText.getText().toString(),
                        parcelDescriptionEditText.getText().toString(),
                        "Rock - placeholder", //TODO
                        parcelCurrUsageEditText.getText().toString(),
                        parcelPrevUsageEditText.getText().toString(),
                        parcelAreaEditText.getText().toString());
            }
        };

        parcelNameEditText.addTextChangedListener(afterTextChangedListener);
        parcelRegionEditText.addTextChangedListener(afterTextChangedListener);
        parcelDescriptionEditText.addTextChangedListener(afterTextChangedListener);
        parcelCurrUsageEditText.addTextChangedListener(afterTextChangedListener);
        parcelPrevUsageEditText.addTextChangedListener(afterTextChangedListener);
        parcelAreaEditText.addTextChangedListener(afterTextChangedListener);

        registerParcelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingProgressBar.setVisibility(View.VISIBLE);

               /* parcelViewModel.registerParcel(username,toText(parcelNameEditText), "county", "district", "freguesia" ,
                        toText(parcelDescriptionEditText), "Stone",toText(parcelCurrUsageEditText),
                        toText(parcelPrevUsageEditText), toText(parcelAreaEditText), latitudes, longitudes);*/

               String ground = p.getSelectedItem()
                       .toString();
                parcelViewModel.registerParcel(username, toText(parcelNameEditText), "county", "district", "freguesia",
                        toText(parcelDescriptionEditText), ground, toText(parcelCurrUsageEditText), toText(parcelPrevUsageEditText),
                        toText(parcelAreaEditText), latitudes, longitudes);
            }
        });


        return root;
    }
    //---------------------AUX---------------------------//

    /**
     * Sets the spinner, which is a kind of drop down menu
     */
    private void setSpinnerGroundType(Spinner soilSpinner) {

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.ground_types, android.R.layout.simple_spinner_item);
        //specify the layout to use when the choices appear
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        //sets drop down menu for selecting the ground type
        soilSpinner.setAdapter(adapter);
        soilSpinner.setPrompt("Select the Ground Type");
        soilSpinner.setAdapter(
                //code to set the "hint" - thank stack overflow for this one
                new NothingSelectedSpinnerAdapter(
                        adapter,
                        R.layout.contact_spinner_row_nothing_selected,
                        getContext()));
        adapter.notifyDataSetChanged();




    }

    /**
     *  Get username method, for this fragment
     */
    private String loadLoggedInUserElem(String parameter) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String userParam = sharedPreferences.getString(parameter, "");
        return userParam;

    }

    /**
     * Cast float array to double. Android bundles arguments don't recognize doubles, so
     * drastic measures had to be taken
     * @param floatArray
     * @return array of doubles
     */
    private double[] castFloatArray(float[] floatArray){

        double[] doubleArray = new double[floatArray.length];
        for (int i = 0 ; i < floatArray.length; i++)
            doubleArray[i] = (double) floatArray[i];

        return doubleArray;
    }

    private void showRegisterFailed(@StringRes Integer errorString) {
        Toast.makeText(getContext(), errorString, Toast.LENGTH_SHORT).show();

    }

    private void updateUi(RegisteredParcelView success) {
        String registerSuccess = getString(R.string.register_success)+ " ";
        Toast.makeText(getContext(), registerSuccess, Toast.LENGTH_LONG).show();
    }

    private String toText(EditText ed){
        return ed.getText().toString();
    }
}
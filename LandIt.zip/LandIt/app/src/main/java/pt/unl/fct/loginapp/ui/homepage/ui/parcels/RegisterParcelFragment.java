package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.databinding.FragmentRegisterParcelBinding;
import pt.unl.fct.loginapp.ui.homepage.NothingSelectedSpinnerAdapter;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.CSVReader;

public class RegisterParcelFragment extends Fragment {

    private FragmentRegisterParcelBinding binding;
    private ParcelViewModel parcelViewModel;
    List<byte[]> confirmation;
    Button uploadPdfBtn;
    private AuxMethods aux = new AuxMethods();

    public RegisterParcelFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentRegisterParcelBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Button registerParcelBtn = binding.registerParcelBtn;
        uploadPdfBtn = binding.uploadPdfBtn;

        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);

        //region----Handling of parcel parameters
        final String username = aux.loadLoggedInUserElem(getString(R.string.username), getContext());
        final EditText parcelNameEditText = binding.parcelNameInput;
        final EditText parcelDescriptionEditText = binding.parcelDescriptionInput;
        final EditText parcelCurrUsageEditText = binding.parcelCurrUsageInput;
        final EditText parcelPrevUsageEditText = binding.parcelPrevUsageInput;
        final EditText parcelAreaEditText = binding.parcelAreaInput;
        final ProgressBar loadingProgressBar = binding.loadingRegisterParcel;

        //spinners
        final Spinner soilSpinner = (Spinner) binding.parcelGroundTypeInputSpinner;
        aux.setSpinnerAdapterType(soilSpinner,R.string.selectGroundType, "",getContext());
        final Spinner parcelCountySpinner = (Spinner) binding.parcelCountyInputSpinner;
        parcelCountySpinner.setEnabled(false);
        aux.setSpinnerAdapterType(parcelCountySpinner, R.string.selectCounty, "", getContext());
        final Spinner parcelDistrictSpinner = (Spinner) binding.parcelDistrictInputSpinner;
        aux.setSpinnerAdapterType(parcelDistrictSpinner,R.string.selectDistrict, "", getContext());
        final Spinner parcelMunicipalitySpinner = (Spinner) binding.parcelFreguesiaInputSpinner;
        parcelMunicipalitySpinner.setEnabled(false);
        aux.setSpinnerAdapterType(parcelMunicipalitySpinner,R.string.selectMunicipality, "", getContext());

        float[] lats = RegisterParcelFragmentArgs.fromBundle(requireArguments()).getLats();
        float[] longs = RegisterParcelFragmentArgs.fromBundle(requireArguments()).getLongs();

        double[] latitudes = castFloatArray(lats);
        double[] longitudes = castFloatArray(longs);

        confirmation = new ArrayList<>();
        boolean isPdfChosen = false;

        //endregion

        //observer for changes
        parcelViewModel.getParcelFormState().observe(getViewLifecycleOwner(), new Observer<ParcelRegisterFormState>() {

            @Override
            public void onChanged(@Nullable ParcelRegisterFormState parcelRegisterFormState) {
                if (parcelRegisterFormState == null) {
                    return;
                }
                //enables the button to be clickable if condition is true
                registerParcelBtn.setEnabled(parcelRegisterFormState.isDataValid()
                        && !(confirmation.isEmpty())
                        && !soilSpinner.getSelectedItem().equals(R.string.selectGroundType)
                        && !parcelMunicipalitySpinner.getSelectedItem().equals(R.string.selectMunicipality));

                //shows the little error messages if info in forms is not correct
                if (parcelRegisterFormState.getParcelNameError() != null) {
                    parcelNameEditText.setError(getString(parcelRegisterFormState.getParcelNameError()));
                }
                if(parcelRegisterFormState.getDescriptionError() != null){
                    parcelDescriptionEditText.setError(getString(parcelRegisterFormState.getDescriptionError()));
                }
                if(parcelRegisterFormState.getCurrUsageError() != null){
                    parcelCurrUsageEditText.setError(getString(parcelRegisterFormState.getCurrUsageError()));
                }
                if(parcelRegisterFormState.getPrevUsageError() != null){
                    parcelPrevUsageEditText.setError(getString(parcelRegisterFormState.getPrevUsageError()));
                }
                if(parcelRegisterFormState.getAreaError() != null){
                    parcelAreaEditText.setError(getString(parcelRegisterFormState.getAreaError()));
                }
                if(parcelRegisterFormState.getConfirmationError() != null){
                    uploadPdfBtn.setError(getString(parcelRegisterFormState.getConfirmationError()));
                }
            }
        });

        //Observer for result
        parcelViewModel.getParcelResult().observe(getViewLifecycleOwner(), new Observer<ParcelResult>() {
            @Override
            public void onChanged(@Nullable ParcelResult parcelResult) {
                if (parcelResult == null) {
                    return;
                }

                loadingProgressBar.setVisibility(View.GONE);
                registerParcelBtn.setVisibility(View.VISIBLE);

                if (parcelResult.getError() != null) {
                    showRegisterFailed(parcelResult.getError());
                }
                if (parcelResult.getSuccess() != null) { //where we change the page being shown
                    updateUi(parcelResult.getSuccess());

                    //equivalent of pressing back button
                    NavController navController = NavHostFragment.findNavController(getParentFragment());
                    navController.popBackStack();

                    //getActivity().onBackPressed();
                }
            }
        });

        //region TextWatcher
        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                parcelViewModel.registerDataChanged(parcelNameEditText.getText().toString(),
                        parcelDescriptionEditText.getText().toString(),
                        parcelCurrUsageEditText.getText().toString(),
                        parcelPrevUsageEditText.getText().toString(),
                        parcelAreaEditText.getText().toString(), confirmation);
            }
        };

        parcelNameEditText.addTextChangedListener(afterTextChangedListener);
        parcelDescriptionEditText.addTextChangedListener(afterTextChangedListener);
        parcelCurrUsageEditText.addTextChangedListener(afterTextChangedListener);
        parcelPrevUsageEditText.addTextChangedListener(afterTextChangedListener);
        parcelAreaEditText.addTextChangedListener(afterTextChangedListener);
        registerParcelBtn.addTextChangedListener(afterTextChangedListener);

        //endregion

        registerParcelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingProgressBar.setVisibility(View.VISIBLE);
                registerParcelBtn.setVisibility(View.GONE);

               String ground = soilSpinner.getSelectedItem().toString();
               String county = parcelCountySpinner.getSelectedItem().toString();
               String district = parcelDistrictSpinner.getSelectedItem().toString();
               String municipality = parcelMunicipalitySpinner.getSelectedItem().toString();
               byte[] confirmationValue = confirmation.get(0); //pdf file
                parcelViewModel.registerParcel(username, toText(parcelNameEditText), county, district, municipality,
                        toText(parcelDescriptionEditText), ground, toText(parcelCurrUsageEditText), toText(parcelPrevUsageEditText),
                        latitudes, longitudes, confirmationValue);
            }
        });

        //region spinners listeners
        //takes care of spinners only showing what needs to
        parcelDistrictSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(parcelDistrictSpinner.getSelectedItem() != null) {
                    String district = parcelDistrictSpinner.getSelectedItem().toString();
                    //sets the city/county spinner, only showing cities from the district chosen
                    aux.setSpinnerAdapterType(parcelCountySpinner, R.string.selectCounty, district, getContext());
                    parcelCountySpinner.setEnabled(true);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        parcelCountySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(parcelCountySpinner.getSelectedItem() != null){
                    String county = parcelCountySpinner.getSelectedItem().toString();
                    aux.setSpinnerAdapterType(parcelMunicipalitySpinner, R.string.selectMunicipality, county, getContext());
                    parcelMunicipalitySpinner.setEnabled(true);

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //endregion

        //upload pdf listener
        uploadPdfBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");

                getResult.launch(intent);

            }
        });

        return root;
    }

    /**
     * Document upload handling
     */
    ActivityResultLauncher<Intent> getResult = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode() == RESULT_OK){
                        Intent data = result.getData();
                            if(data != null){
                                Uri uri = data.getData();

                                try {
                                    InputStream is = getActivity().getContentResolver().openInputStream(uri);
                                    byte[] bytesArray = new byte[is.available()];

                                    is.read(bytesArray);
                                    confirmation.add(bytesArray);
                                    uploadPdfBtn.setText(R.string.uploadedDocsOk);
                                    uploadPdfBtn.setError(null);


                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                    }else{
                        Snackbar.make(getView(), R.string.uploadDocWarning, Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                    }
                  //  result.getData();

                }
            });

    //---------------------AUX---------------------------//

    //region Spinner functions


    //endregion

    /**
     * Cast float array to double. Android bundles arguments don't recognize doubles, so
     * drastic measures had to be taken
     * @param floatArray
     * @return array of doubles
     */
    private double[] castFloatArray(float[] floatArray){

        double[] doubleArray = new double[floatArray.length];
        for (int i = 0 ; i < floatArray.length; i++)
            doubleArray[i] = (double) floatArray[i];

        return doubleArray;
    }

    private void showRegisterFailed(@StringRes Integer errorString) {
        Toast.makeText(getContext(), errorString, Toast.LENGTH_SHORT).show();

    }

    private void updateUi(RegisteredParcelView success) {
        String registerSuccess = getString(R.string.register_success)+ " ";
        Toast.makeText(getContext(), registerSuccess, Toast.LENGTH_LONG).show();
    }

    private String toText(EditText ed){
        return ed.getText().toString();
    }
}
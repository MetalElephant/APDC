package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

public class RegisteredParcelView {

    RegisteredParcelView(){
    }
}

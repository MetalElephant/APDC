package pt.unl.fct.loginapp.data.parcel.model;

import static pt.unl.fct.loginapp.util.AuxMethods.CHAR;
import static pt.unl.fct.loginapp.util.AuxMethods.COMMASPACE;
import static pt.unl.fct.loginapp.util.AuxMethods.SEMICOLON;

import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;
import java.util.Arrays;

import pt.unl.fct.loginapp.util.AuxMethods;

public class ParcelInfo implements Serializable {

    public static final String YES = "YES";
    public static final String NO = "NO";

    public String owner, parcelName, county, district, freguesia, description, groundType, currUsage, prevUsage, area, confirmation;
    public LatLng[] markers;
    public String[] owners;
    public boolean confirmed;

    public ParcelInfo(String owner, String[] owners, String parcelName, String county, String district, String freguesia, String description,
                      String groundType, String currUsage, String prevUsage, String area, LatLng[] markers, String confirmation, boolean confirmed) {
        this.owner = owner;
        this.owners = owners;
        this.parcelName = parcelName;
        this.county = county;
        this.district = district;
        this.freguesia = freguesia;
        this.description = description;
        this.groundType = groundType;
        this.currUsage = currUsage;
        this.prevUsage = prevUsage;
        this.area = area;
        this.markers = markers;
        this.confirmation = confirmation;
        this.confirmed = confirmed;
    }

    public LatLng[] getMarkers() {
        return markers;
    }

    public String getDescription() {
        return description;
    }

    public String getCounty() {
        return county;
    }

    public String getFreguesia() {
        return freguesia;
    }

    public String getGroundType() {
        return groundType;
    }

    public String getCurrUsage() {
        return currUsage;
    }

    public String getPrevUsage() {
        return prevUsage;
    }

    public String[] getOwners() {
        return owners;
    }

    public String getOwnersString(){
        String toShow = "";
        for (int i = 0; i< owners.length; i++) {
            if(i == owners.length-1)
                toShow.concat(owners[i]);
            else
                toShow.concat(owners[i] + COMMASPACE);

        }
        return toShow;
    }

    public String getParcelName(){
        return parcelName;
    }

    public String getOwner() {
        return owner;
    }

    public String getArea() {
        return area;
    }

    public String getDistrict() {
        return district;
    }

    public String getLocation() {
        return freguesia+ COMMASPACE+county + COMMASPACE+ district;
    }

    private String[] convertMarkersToString(){
        String[] markersString = new String[markers.length];
        for (int i = 0; i< markers.length; i++){
            markersString[i] = Double.toString(markers[i].latitude)+ SEMICOLON +
                    Double.toString(markers[i].longitude);
        }
        return markersString;
    }

    public String getConfirmation() {
        return confirmation;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public String isConfirmedString(){
        if(isConfirmed())
            return YES;
        else
            return NO;
    }

    @Override
    public String toString() {
        return owner + CHAR + parcelName +
                CHAR+ county
                + CHAR + district
                + CHAR + freguesia
                + CHAR + description
                + CHAR + groundType
                + CHAR + currUsage
                + CHAR + prevUsage
                + CHAR + area
                + CHAR + confirmation
                + CHAR + isConfirmedString()
                + CHAR + Arrays.toString(convertMarkersToString())
                + CHAR + Arrays.toString(owners);
    }
}

package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import androidx.annotation.Nullable;

public class ParcelRegisterFormState {

    @Nullable
    private Integer parcelNameError;
    @Nullable
    private Integer regionError;
    @Nullable
    private Integer descriptionError;
    @Nullable
    private Integer groundTypeError;
    @Nullable
    private Integer currUsageError;
    @Nullable
    private Integer prevUsageError;
    @Nullable
    private Integer areaError;
    @Nullable
    private Integer confirmationError;

    private boolean isDataValid;

    ParcelRegisterFormState(@Nullable Integer parcelNameError, @Nullable Integer regionError, @Nullable Integer descriptionError, @Nullable Integer groundTypeError, @Nullable Integer currUsageError,
    @Nullable Integer prevUsageError, @Nullable Integer areaError, @Nullable Integer confirmationError) {
        this.parcelNameError = parcelNameError;
        this.regionError = regionError;
        this.descriptionError = descriptionError;
        this.groundTypeError = groundTypeError;
        this.currUsageError = currUsageError;
        this.prevUsageError = prevUsageError;
        this.areaError = areaError;
        this.confirmationError = confirmationError;
        this.isDataValid = false;
    }

    ParcelRegisterFormState(boolean isDataValid) {
        this.parcelNameError = null;
        this.regionError = null;
        this.descriptionError = null;
        this.groundTypeError = null;
        this.currUsageError = null;
        this.prevUsageError = null;
        this.areaError = null;
        this.confirmationError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    Integer getParcelNameError() {
        return parcelNameError;
    }

    @Nullable
    Integer getRegionError() {
        return regionError;
    }

    @Nullable
    Integer getDescriptionError() { return descriptionError; }

    @Nullable
    Integer getGroundTypeError() { return groundTypeError; }

    @Nullable
    Integer getCurrUsageError() { return currUsageError; }

    @Nullable
    Integer getPrevUsageError(){return prevUsageError; }

    @Nullable
    Integer getAreaError(){return areaError; }

    @Nullable
    Integer getConfirmationError(){return confirmationError;}

    boolean isDataValid() {
        return isDataValid;
    }
}

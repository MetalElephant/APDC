package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

import java.util.List;

import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;

public class RewardListView {
    public List<RewardData> rewards;

    public RewardListView(List<RewardData> allRewards){
        this.rewards = allRewards;
    }

    public List<RewardData> getRewards() {
        return rewards;
    }
}

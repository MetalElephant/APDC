package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import androidx.annotation.Nullable;

public class ParcelResult {
    @Nullable
    private RegisteredParcelView success;
    @Nullable
    private ParcelInfoView successP;
    @Nullable
    private Integer error;

    ParcelResult(@Nullable Integer error) {
        this.error = error;
    }

    ParcelResult(@Nullable RegisteredParcelView success) {
        this.success = success;
    }

    ParcelResult(@Nullable  ParcelInfoView successP) {
        this.successP = successP;
    }

    @Nullable
    RegisteredParcelView getSuccess() {
        return success;
    }

    @Nullable
    public ParcelInfoView getSuccessP(){
        return successP;
    }

    @Nullable
    public Integer getError() {
        return error;
    }
}

package pt.unl.fct.loginapp.data.rewards.model;

public class RewardRedeemData {

    public String username, owner, reward;

    public RewardRedeemData() {}

    public RewardRedeemData(String username, String owner, String reward) {
        this.username = username;
        this.owner = owner;
        this.reward = reward;
    }
}

package pt.unl.fct.loginapp.data.rewards.model;

public class RegisteredReward {
    public RegisteredReward(){}
}

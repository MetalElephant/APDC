package pt.unl.fct.loginapp.data.rewards.model;

import java.io.Serializable;

public class RewardData implements Serializable {

    private static final String LINESEPARATOR = "line.separator";
    public String name, description, owner, price, timesRedeemed;

    public RewardData(){}

    public RewardData(String name, String description, String owner, String price, String timesRedeemed) {
        this.name = name;
        this.description = description;
        this.owner = owner;
        this.price = price; // the minimum price is 1000 points
        this.timesRedeemed = timesRedeemed;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getOwner() {
        return owner;
    }

    public String getPrice() {
        return price;
    }

    public String getTimesRedeemed() {
        return timesRedeemed;
    }

    @Override
    public String toString() {
        return "Recompensa: "+ getName() + System.getProperty(LINESEPARATOR) +
                "Descrição: " + getDescription() + System.getProperty(LINESEPARATOR) +
                "Preço: " + getTimesRedeemed() + System.getProperty(LINESEPARATOR) +
                "De: " + getOwner() + System.getProperty(LINESEPARATOR) +
                "Redimido: " + getPrice() + " vezes";
    }
}

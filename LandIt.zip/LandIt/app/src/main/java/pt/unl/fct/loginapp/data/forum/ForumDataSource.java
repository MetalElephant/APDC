package pt.unl.fct.loginapp.data.forum;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.util.List;

import pt.unl.fct.loginapp.data.RestAPI;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.forum.model.ForumInfo;
import pt.unl.fct.loginapp.data.forum.model.ForumMessageData;
import pt.unl.fct.loginapp.data.forum.model.ForumRegisterData;
import pt.unl.fct.loginapp.data.forum.model.ForumRemoveData;
import pt.unl.fct.loginapp.data.forum.model.MessageInfo;
import pt.unl.fct.loginapp.data.forum.model.RegisteredForum;
import pt.unl.fct.loginapp.data.forum.model.RemoveMessageData;
import pt.unl.fct.loginapp.data.parcel.model.RequestData;
import pt.unl.fct.loginapp.data.rewards.model.RegisteredReward;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ForumDataSource {

    private final RestAPI service;
    Gson gson = new GsonBuilder().setLenient().create();
    private static final int DEFAULT_TYPE = 1;

    public ForumDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://landit-app.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        this.service = retrofit.create(RestAPI.class);
    }

    public Result<RegisteredForum> registerForum(String username, String forumName, String topic) {

        try {
            try{
            Call<RegisteredForum> registerService = service.doRegisterForum(
                    new ForumRegisterData(username, forumName, topic)) ;
            Response<RegisteredForum> response = registerService.execute();

            if( response.isSuccessful() ) {
                RegisteredForum r = response.body();
                return new Result.Success<>(r);
            } else {
                return new Result.Error(new Exception("Server result code: " + response.code() ));
            }
            }catch (IllegalStateException | JsonSyntaxException |java.io.IOException exception ) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }


    public Result<RegisteredForum> registerMessage(String username, String owner, String forum, String msg){
        try {
            try{
            Call<RegisteredForum> registerMsgService = service.doSendMessage(
                    new ForumMessageData(username, owner, forum, msg)) ;
            Response<RegisteredForum> response = registerMsgService.execute();

            if( response.isSuccessful() ) {
                RegisteredForum r = response.body();
                return new Result.Success<>(r);
            } else {
                return new Result.Error(new Exception("Server result code: " + response.code() ));
            }
            }catch (IllegalStateException | JsonSyntaxException |java.io.IOException exception ) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<RegisteredForum> removeForum(String username, String owner, String fName){
        try {
            try{
            Call<RegisteredForum> removeService = service.removeForum(
                    new ForumRemoveData(username, owner, fName)) ;
            Response<RegisteredForum> response = removeService.execute();

            if( response.isSuccessful() ) {
                RegisteredForum r = response.body();
                return new Result.Success<>(r);
            } else {
                return new Result.Error(new Exception("Server result code: " + response.code() ));
            }
            }catch (IllegalStateException | JsonSyntaxException |java.io.IOException exception ) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }


    public Result<RegisteredForum> removeMessage(String username, String forumOwner,
                                                 String forumName, String msg, String msgOwner){
        try {
            try{
            Call<RegisteredForum> registerService = service.removeMessage(
                    new RemoveMessageData(username,forumOwner,forumName,msg, msgOwner));
            Response<RegisteredForum> response = registerService.execute();

            if( response.isSuccessful() ) {
                RegisteredForum r = response.body();
                return new Result.Success<>(r);
            } else {
                return new Result.Error(new Exception("Server result code: " + response.code() ));
            }
            }catch (IllegalStateException | JsonSyntaxException |java.io.IOException exception ) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<List<ForumInfo>> listForums(String username){
        try{
            try{
                Call<List<ForumInfo>> listService = service.listForums(new RequestData(username));
                Response<List<ForumInfo>> response = listService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<ForumInfo> allForums= response.body();
                    return new Result.Success<>(allForums);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException |java.io.IOException exception ) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }

    }

    public Result<List<ForumInfo>> listAllForums(){
        try{
            try{
                Call<List<ForumInfo>> listService = service.listAllForums();
                Response<List<ForumInfo>> response = listService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<ForumInfo> allForums= response.body();
                    return new Result.Success<>(allForums);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException |java.io.IOException exception ) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }

    }

    public Result<List<MessageInfo>> listMessages(String username, String fName){
        try{
            try{
                Call<List<MessageInfo>> listService = service.listMessages(new RequestData(username, fName));
                Response<List<MessageInfo>> response = listService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<MessageInfo> allMessages= response.body();
                    return new Result.Success<>(allMessages);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }

    }






}

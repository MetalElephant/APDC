package pt.unl.fct.loginapp.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Class to help read the insane amount of cities in portugal from csv file
 * and set the spinners to change according to what was already picked
 */
public class CSVReader {
    InputStream inputStream;

    public CSVReader(InputStream inputStream){
        this.inputStream = inputStream;
    }

    public List read(){
        List<String[]> resultList = new ArrayList<String[]>();
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new InputStreamReader(inputStream, "ISO-8859-1"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] row = line.split(";");
                resultList.add(row);
            }
        }
        catch (IOException ex) {
            throw new RuntimeException("Error in reading CSV file: "+ex);
        }
        finally {
            try {
                inputStream.close();
            }
            catch (IOException e) {
                throw new RuntimeException("Error while closing input stream: "+e);
            }
        }
        return resultList;
    }

    public List<String> allDistricts(){
        return getAll(0);
    }
    public List<String> allCounties(){
        return getAll(1);
    }
    public List<String> allMunicipalities(){
        return getAll(2);
    }

    public List<String> allCountiesFromDistrict(String district){

        return allLocationsFromX(1, 0, district);
    }

    public List<String> allMunicipalitiesFromCounty(String county){

        return allLocationsFromX(2, 1, county);
    }

    public List<String> districtFromCounty(String county){

        return allLocationsFromX(0, 1, county);
    }

    public List<String> districtFromMunicipality(String municipality){

        return allLocationsFromX(0, 2, municipality);
    }

    public List<String> countyFromMunicipality(String municipality){

        return allLocationsFromX(1, 2, municipality);
    }


    /**
     * Gets all districts, counties or municipalities belonging to a certain other district, county or municipality
     */
    private List<String> allLocationsFromX(int typeOfZoneToGet, int typeOfZoneFrom, String zoneFrom){

        List<String[]> allLines = read();
        List<String> locations = new ArrayList<>();

        for (String[] lines: allLines){
            if (lines[typeOfZoneFrom].contains(zoneFrom)) {
                String zone = lines[typeOfZoneToGet];
                if (!locations.contains(zone))
                    locations.add(zone);
            }

            Collections.sort(locations, String.CASE_INSENSITIVE_ORDER);
        }

        return locations;

    }


    /**
     * Gets all districts (0), counties (1) or municipalities(3)
     */
    private List<String> getAll(int typeOfZone){
        List<String[]> allLines = read();
        List<String> locations = new ArrayList<>();
        String prevLocation = "";

        for (String[] lines: allLines){
            String zone = lines[typeOfZone];
            if(!zone.equalsIgnoreCase(prevLocation)) //no repeats
                locations.add(zone);

            prevLocation = zone;
        }

        return locations;

    }


}

package pt.unl.fct.loginapp.data.users.model.updatePwd;

public class PasswordUpdateData {
    public String username;
    public String oldPwd;
    public String newPwd;
    public String pwdConfirmation;

    public PasswordUpdateData(String username, String oldPassword, String newPassword, String pwdConfirmation) {
        this.username = username;
        this.oldPwd = oldPassword;
        this.newPwd = newPassword;
        this.pwdConfirmation = pwdConfirmation;
    }
}

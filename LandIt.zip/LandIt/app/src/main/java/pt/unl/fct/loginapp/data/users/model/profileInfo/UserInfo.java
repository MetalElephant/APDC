package pt.unl.fct.loginapp.data.users.model.profileInfo;


import java.io.Serializable;

public class UserInfo implements Serializable {
    public String username, email, name, district, county, autarchy, street, landphone, mobilephone, nif, role, photo;
    public int points;

    public UserInfo(String username, String email, String name, String district, String county,
                    String autarchy, String street, String landphone, String mobilephone, String nif, String role, String photo, int points) {
        this.username = username;
        this.email = email;
        this.name = name;
        this.district = district;
        this.county = county;
        this.autarchy = autarchy;
        this.street = street;
        this.landphone = landphone;
        this.mobilephone = mobilephone;
        this.nif = nif;
        this.role = role;
        this.photo = photo;
        this.points = points;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getLandphone() {
        return landphone;
    }

    public String getMobilephone() {
        return mobilephone;
    }

    public String getNif() {
        return nif;
    }

    public String getRole() {
        return role;
    }

    public String getPhoto() {
        return photo;
    }

    public String getDistrict() {
        return district;
    }

    public String getCounty() {
        return county;
    }

    public String getAutarchy() {
        return autarchy;
    }

    public int getPoints() {
        return points;
    }

    public String getPointsString() {
        return Integer.toString(points);
    }

    public String getStreet(){
        return street;
    }

    public String getAddressRegion(){
        return district + ", "+county + ", "+autarchy;
    }
}

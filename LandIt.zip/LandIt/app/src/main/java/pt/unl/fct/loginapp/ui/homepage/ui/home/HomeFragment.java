package pt.unl.fct.loginapp.ui.homepage.ui.home;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.content.Context.LOCATION_SERVICE;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.preference.PreferenceScreen;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.FragmentHomeBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

/**
 * Fragment with the map and associated operations
 */
public class HomeFragment extends Fragment {

    private View view = null;
    boolean isFirstSync;


    private static final String LATS = "lats";
    private static final String LONGS = "longs";
    private static final double DEFAULT_LOCATION_LAT = 39.556567;
    private static final double DEFAULT_LOCATION_LONG = -7.995878;

    private FragmentHomeBinding binding;
    private ParcelViewModel parcelViewModel;
    private SupportMapFragment supportMapFragment;
    private AuxMethods aux = new AuxMethods();

    //vars related to getting current location through google API
    private GoogleMap gMap;
    private Location currentLocation;
    private FusedLocationProviderClient client;

    //vars related to parcels a user might register
    private List<LatLng> newParcelMarkers;
    private List<Marker> addedMarkers;
    private List<Polygon> addedPolygons;
    private List<Float> latitudes;
    private List<Float> longitudes;

    //vars related to parcels a user already has
    private List<LatLng[]> allParcelsLocations; //all parcels of the owner
    private List<Marker> allMarkers;
    private List<Polygon> allPolygons;
    private boolean shouldRefresh = false;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);


        //initialize view
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        String role = aux.loadRole(getContext());

        if(!Roles.isModOrSUOrMerchant(role) && !Roles.isRep(role)) {

            //region load Parcels
            parcelViewModel.showParcels(aux.loadLoggedInUserElem(getString(R.string.username), getContext()));

            //observer for getting user parcels, adds them to ownerParcels
            parcelViewModel.getParcelResult().observe(getViewLifecycleOwner(), parcelResult -> {
                if (parcelResult == null) {
                    return;
                }
                if (parcelResult.getError() != null) {
                }
                if (parcelResult.getSuccessP() != null) {
                    loadUserParcels(parcelResult);
                }
            });

            //Button to show users parcels or not
            Switch showParcelsSwitch = binding.showParcelsSwitch;
            showParcelsSwitch.setOnCheckedChangeListener((compoundButton, isChecked) -> {
                if (isChecked) {
                    setMarkersVisible(true);
                } else {
                    setMarkersVisible(false);
                }
            });
            //endregion

            //Button to go to register fragment
            Button registerParcelBtn = binding.buttonMap;
            registerParcelBtn.setOnClickListener(view -> {

                //to send information in a bundle to the registerParcel fragment
                //Convert list to floatArray, put in the bundle
                Bundle lats = new Bundle();
                float[] latsArray = listToArray(latitudes);
                lats.putFloatArray(LATS, latsArray);

                Bundle longs = new Bundle();
                float[] longsArray = listToArray(longitudes);
                longs.putFloatArray(LONGS, longsArray);


                if (latitudes.size() < 3 && longitudes.size() < 3) {
                    Snackbar.make(view, R.string.invalidPoints, Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                } else {
                    //clear previous parcel markers
                    //isFirstSync = true;
                    removeFromMap(addedMarkers, addedPolygons);
                    showParcelsSwitch.setChecked(false);
                    //

                    //latitudes.clear();
                    //longitudes.clear();

                    //go to the registerParcelFrag and send latitudes and longitudes along with it
                    Navigation.findNavController(view)
                            .navigate(HomeFragmentDirections.moveToRegisterParcel(latsArray, longsArray));

                }
            });

            //region add and remove markers with FloatingActionButtons
            FloatingActionButton fab1 = binding.fabAdd;
            fab1.setOnClickListener(view -> {
                LatLng latLng = gMap.getCameraPosition().target;
                onMapClickAction(latLng);
            });
            FloatingActionButton fabClear = binding.fabClear;
            fabClear.setOnClickListener(view -> {
                        if (!newParcelMarkers.isEmpty()) {
                            //remove all markers and polygons
                            removeFromMap(addedMarkers, addedPolygons);
                            newParcelMarkers.remove(newParcelMarkers.size() - 1);
                            latitudes.remove(latitudes.size() - 1);
                            longitudes.remove(longitudes.size() - 1);

                            for (int i = 0; i < newParcelMarkers.size(); i++) {
                                LatLng latLng = newParcelMarkers.get(i);

                                MarkerOptions markerOptions = new MarkerOptions();
                                markerOptions.position(latLng);
                                gMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                                Marker m = gMap.addMarker(markerOptions);
                                addedMarkers.add(m);
                                //area
                                Polygon p = gMap.addPolygon(new PolygonOptions()
                                        .addAll(newParcelMarkers)
                                        .strokeColor(Color.BLACK)
                                        .fillColor(Color.GRAY));
                                addedPolygons.add(p);
                                //LatLng location = addedMarkers.get(i).getPosition();
                                // addMarkerToMap(location, newParcelMarkers);
                            }

                        }

                    }


            );
            FloatingActionButton fabHelp = binding.fabHelp;
            fabHelp.setOnClickListener(view1 -> {
                AlertDialog alertDialog = aux.initAlert(getContext(), R.string.fabHelpTitle, R.string.fabHelpMessage);
                alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, getString(R.string.ok),
                        (DialogInterface.OnClickListener) (dialogInterface, i) -> {
                        });
                alertDialog.show();
            });

            //endregion

            //region //--------------- Map Handling ------------------//

            newParcelMarkers = new ArrayList<>();
            addedMarkers = new ArrayList<>();
            addedPolygons = new ArrayList<>();

            allParcelsLocations = new ArrayList<>();
            allMarkers = new ArrayList<>();
            allPolygons = new ArrayList<>();

            latitudes = new ArrayList<>();
            longitudes = new ArrayList<>();


            isFirstSync = true;

            //init map
            supportMapFragment = (SupportMapFragment) getChildFragmentManager()
                    .findFragmentById(R.id.map);


            //init fused location - for finding your location with gps
            client = LocationServices.getFusedLocationProviderClient(getContext());

            //get new location and sync every 10 seconds
            if (isGPSEnabled()) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getCurrentLocation(isFirstSync);
                        isFirstSync = false;
                        handler.postDelayed(this, 1000 * 6); //every 10 seconds?
                    }
                }, 1000);
            }
            //endregion

        }
        return root;
    }

    private void updateArea() {
        for (Polygon p: addedPolygons) {
            p.remove();
        }
        addArea();
    }

    private void addArea(){
        Polygon p = gMap.addPolygon(new PolygonOptions()
                .addAll(newParcelMarkers)
                .strokeColor(Color.BLACK)
                .fillColor(Color.GRAY));
        addedPolygons.add(p);
    }


    private void syncMap(Location location, boolean hasPermission, boolean isFirstSync) {

        supportMapFragment.getMapAsync(new OnMapReadyCallback() {
            @SuppressLint("MissingPermission")
            @Override
            public void onMapReady(@NonNull GoogleMap googleMap) {

                gMap = googleMap;

                //adds all parcels that were loaded with the rest call
                if(isFirstSync)
                    addParcelsToMap();

                if(hasPermission)
                    gMap.setMyLocationEnabled(true);

                //when map is loaded
                LatLng initLocation = new LatLng(location.getLatitude(), location.getLongitude());

                if(!hasPermission) {
                    gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(initLocation, 15));
                }

                //when clicking on map
                gMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(@NonNull LatLng latLng) {
                        onMapClickAction(latLng);
                    }
                });
            }
        });
    }

    private void clearFromMap(){
        removeFromMap(addedMarkers, addedPolygons);
        newParcelMarkers.clear();
        latitudes.clear();
        longitudes.clear();
    }


    private void onMapClickAction(LatLng latLng){

        //init marker options
        MarkerOptions markerOptions = new MarkerOptions();

        //add marker to the map and to the array of lat and longs we'll
        //send to the REST call
        newParcelMarkers.add(latLng);
        if (newParcelMarkers.size() < 10) {
            latitudes.add((float)latLng.latitude);
            longitudes.add((float)latLng.longitude);
        }

        //set position of marker
        markerOptions.position(latLng);

        //animate to move on marker
        gMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));

        //add marker to map
        // & to list of markers, for easier removal
        Marker m = gMap.addMarker(markerOptions);
        addedMarkers.add(m);

        //area
        addArea();

        //clear past certain amount of points
        if (newParcelMarkers.size() > 10) {
            clearFromMap();
        }

    }

    /**
     * Checks if user has given necessary location permissions, gets current location and syncs map
     */
    private void getCurrentLocation(boolean isFirstSync) {

        //request permission, if not granted before
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            //if permission granted

            Task<Location> task = client.getLastLocation();
            task.addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {
                            currentLocation = location;
                            syncMap(location, true, isFirstSync);
                    }
                    else{
                        Toast.makeText(getContext(), getString(R.string.gpsOff), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else{
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{ACCESS_FINE_LOCATION}, 44);

        }

    }

    /**
     * Sends default location value to syncMap method, in case user doesn't authorize using location services
     */
    private void syncMapWithoutPermissions() {
        final Location defaultLocation = new Location("");
        defaultLocation.setLatitude(DEFAULT_LOCATION_LAT);
        defaultLocation.setLongitude(DEFAULT_LOCATION_LONG);
        //parcelViewModel.showParcels(loadLoggedInUserElem("username"));
        syncMap(defaultLocation, false, true);

    }

    /**
     * Deals with location turned on or off; if off, opens a dialogue that redirects you to settings
     */
    private boolean isGPSEnabled(){

        //if already turned on
        if( isOn()){
            return true;
        }
        else{
            if(view == null) {//only ask once, everytime user boots up
                view = binding.getRoot();
                AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                        .setTitle(R.string.gpsAlertTitle)
                        .setMessage(R.string.gpsAlertMessage)
                        .setPositiveButton(R.string.yes, ((dialogInterface, i) -> {
                            //user will be redirected to settings
                            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            getResult.launch(intent);
                        }))
                        .setNegativeButton(R.string.no, ((dialogInterface, i) -> {
                            //if not allowed, sync map with a default location
                            syncMapWithoutPermissions();
                        }))
                        .setCancelable(false).show();

            }
            else{
                syncMapWithoutPermissions();

            }
        }

        return false;
    }

    /**
     * Just checks if location is enabled
     */
    private boolean isOn(){
        LocationManager locationManager = (LocationManager) getContext().getSystemService(LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    /**
     * Receiver from having redirected to phone settings
     * Note: onActivityResult() from 2021 was deprecated -_-
     */
    ActivityResultLauncher<Intent> getResult = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {

                    if(isOn()){
                        //activated GPS, get location and sync
                        getCurrentLocation(true);
                    }
                    else{
                        //did not activate, send default location and sync
                        syncMapWithoutPermissions();
                    }

                }
            });

    /**
     * Removes all markers of the given list, and the respective polygons that they form
     */
    private void removeFromMap(List<Marker> mMarkers, List<Polygon> mPolygons) {
        for (Marker marker: mMarkers) {
            marker.remove();
        }
        mMarkers.clear();

        for (Polygon polygon: mPolygons) {
            polygon.remove();
        }
        mPolygons.clear();
    }

    /**
     * Adds list of markers to map
     */
    private void addMarkerToMap(LatLng latLng, List<LatLng> markers){

        MarkerOptions markerOptions = new MarkerOptions();

        //set position of marker
        markerOptions.position(latLng);

        //animate to move on marker
        gMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));

        //add marker to map
        Marker m = gMap.addMarker(markerOptions);
        allMarkers.add(m);

        //area
        Polygon p = gMap.addPolygon(new PolygonOptions()
                .addAll(markers)
                .strokeColor(Color.BLACK)
                .fillColor(Color.GRAY));
        allPolygons.add(p);

    }

    /**
     * Get array of LatLng of each parcel - from the REST call - and store them in global list
     */
    private void loadUserParcels(ParcelResult parcelResult) {

        ParcelInfoView infoView = parcelResult.getSuccessP();
        List<ParcelInfo> allParcels = infoView.getParcels();

        //add each parcel's marker's locations to list
        for (ParcelInfo parcel: allParcels) {
            allParcelsLocations.add(parcel.getMarkers());
        }
    }

    /**
     * Adds all of the user's parcels to map
     */
    private void addParcelsToMap() {

        // go through the locations of all markers for each parcel
        for(LatLng[] markerLocations: allParcelsLocations){
            List<LatLng> mLocations = Arrays.asList(markerLocations);

            int size = markerLocations.length;
            for (int i = 0; i < size; i++) {
                LatLng location = markerLocations[i];
                addMarkerToMap(location, mLocations);
            }
        }
        //initially, we dont want a lot of markers overbearing the user
        Switch s = binding.showParcelsSwitch;
        if(!s.isChecked())
            setMarkersVisible(false);

    }


    private void setMarkersVisible(boolean isVisible){
        if(isVisible && allMarkers.isEmpty() && allPolygons.isEmpty()){
            Snackbar.make(getView(), R.string.noParcels, Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        } else{
            for (Marker m : allMarkers) {
                m.setVisible(isVisible);
            }
            for (Polygon p : allPolygons) {
                p.setVisible(isVisible);
            }
        }
    }

    private float[] listToArray(List<Float> list){
        float[] newArray = new float[list.size()];

        for (int i = 0; i < list.size(); i++)
            newArray[i] = list.get(i);

        return newArray;

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }



}
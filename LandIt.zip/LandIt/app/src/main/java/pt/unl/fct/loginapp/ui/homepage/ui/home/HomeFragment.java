package pt.unl.fct.loginapp.ui.homepage.ui.home;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.content.Context.LOCATION_SERVICE;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.FragmentHomeBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.home.animation.LatLngInterpolator;
import pt.unl.fct.loginapp.ui.homepage.ui.home.animation.MarkerAnimation;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;

/**
 * Fragment with the map and associated operations
 */
public class HomeFragment extends Fragment {

    private static final String LATS = "lats";
    private static final String LONGS = "longs";
    private static final double DEFAULT_LOCATION_LAT = 39.556567;
    private static final double DEFAULT_LOCATION_LONG = -7.995878;

    private FragmentHomeBinding binding;
    private ParcelViewModel parcelViewModel;
    private SupportMapFragment supportMapFragment;

    //vars related to getting current location through google API
    private GoogleMap gMap;
    private Location currentLocation;
    private FusedLocationProviderClient client;

    //vars related to parcels a user might register
    private List<LatLng> newParcelMarkers;
    private List<Marker> addedMarkers;
    private List<Polygon> addedPolygons;
    private List<Float> latitudes;
    private List<Float> longitudes;

    //vars related to parcels a user already has
    private List<LatLng[]> allParcelsLocations; //all parcels of the owner
    private List<Marker> allMarkers;
    private List<Polygon> allPolygons;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);

        //initialize view
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //immediately load the parcels belonging to the user - REST call
        //listener takes care of the rest
        parcelViewModel.showParcels(loadLoggedInUserElem("username"));


        //Button to go to register fragment
        Button registerParcelBtn = binding.buttonMap;
        registerParcelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //to send information in a bundle to the registerParcel fragment
                //Convert list to floatArray, put in the bundle
                Bundle lats = new Bundle();
                float[] latsArray =  listToArray(latitudes);
                lats.putFloatArray(LATS, latsArray);

                Bundle longs = new Bundle();
                float[] longsArray = listToArray(longitudes);
                longs.putFloatArray(LONGS, longsArray);


                if (latitudes.size() < 3 && longitudes.size() < 3) {
                    Snackbar.make(view, R.string.invalidPoints, Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                } else {
                    //clear previous parcel markers
                    removeFromMap(addedMarkers, addedPolygons);

                    //latitudes.clear();
                    //longitudes.clear();

                    //go to the registerParcelFrag and send latitudes and longitudes along with it
                    Navigation.findNavController(view)
                            .navigate(HomeFragmentDirections.moveToRegisterParcel(latsArray, longsArray));
                }
            }
        });

        //Button to show users parcels or not
        Switch showParcelsSwitch = binding.showParcelsSwitch;
        showParcelsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    setMarkersVisible(true);
                } else {
                    setMarkersVisible(false);
                }
            }
        });

        //observer for getting user parcels, adds them to ownerParcels
        parcelViewModel.getParcelResult().observe(getViewLifecycleOwner(), new Observer<ParcelResult>() {
            @Override
            public void onChanged(@Nullable ParcelResult parcelResult) {
                if (parcelResult == null) {
                    return;
                }

                if (parcelResult.getError() != null) {
                    Toast.makeText(getContext(), R.string.noParcels, Toast.LENGTH_SHORT).show();
                }
                if (parcelResult.getSuccessP() != null) {
                    Toast.makeText(getContext(), R.string.showParcels, Toast.LENGTH_SHORT).show();

                    loadUserParcels(parcelResult);

                    //String example = b.get(0).description;
                }
            }
        });


        //region //--------------- Map Handling ------------------//

        newParcelMarkers = new ArrayList<>(4);
        addedMarkers = new ArrayList<>();
        addedPolygons = new ArrayList<>();

        allParcelsLocations = new ArrayList<>();
        allMarkers = new ArrayList<>();
        allPolygons = new ArrayList<>();

        latitudes = new ArrayList<>();
        longitudes = new ArrayList<>();

        //init map
        supportMapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);

        //init fused location - for finding your location with gps
        client = LocationServices.getFusedLocationProviderClient(getContext());

        //get new location and sync every 10 seconds
        if (isGPSEnabled()) {
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    getCurrentLocation();
                    handler.postDelayed(this, 1000 * 6); //every 10 seconds?
                }
            }, 1000);
        }
        //endregion

        return root;
    }

    private void syncMap(Location location, boolean hasPermission) {

        supportMapFragment.getMapAsync(new OnMapReadyCallback() {
            @SuppressLint("MissingPermission")
            @Override
            public void onMapReady(@NonNull GoogleMap googleMap) {

                gMap = googleMap;

                //adds to map all parcels, that were loaded with the rest call
                addParcelsToMap();

                if(hasPermission)
                    gMap.setMyLocationEnabled(true);

                //when map is loaded
                LatLng initLocation = new LatLng(location.getLatitude(), location.getLongitude());
                gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(initLocation, 15));

               /* MarkerOptions mOps = new MarkerOptions();
                mOps.position(initLocation);
                Marker m = gMap.addMarker(mOps);*/

                //MarkerAnimation.animateMarkerToGB(m, initLocation, new LatLngInterpolator.Spherical());

                //when clicking on map
                gMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(@NonNull LatLng latLng) {
                        //init marker options
                        MarkerOptions markerOptions = new MarkerOptions();


                        //add marker to the map and to the array of lat and longs we'll
                        //send to the REST call
                        newParcelMarkers.add(latLng);
                        if (newParcelMarkers.size() < 10) {
                            latitudes.add((float)latLng.latitude);
                            longitudes.add((float)latLng.longitude);

                            //longitudes[newParcelMarkers.size() - 1] = (float) latLng.longitude;
                            //latitudes[newParcelMarkers.size() - 1] = (float) latLng.latitude;
                        }

                        //set position of marker
                        markerOptions.position(latLng);

                        //animate to move on marker
                        gMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));

                        //add marker to map
                        // & to list of markers, for easier removal
                        Marker m = gMap.addMarker(markerOptions);
                        addedMarkers.add(m);

                        //area
                        Polygon p = gMap.addPolygon(new PolygonOptions()
                                .addAll(newParcelMarkers)
                                .strokeColor(Color.BLACK)
                                .fillColor(Color.GRAY));
                        addedPolygons.add(p);

                        //clear past 4 points
                        if (newParcelMarkers.size() > 5) {
                            removeFromMap(addedMarkers, addedPolygons);
                            //googleMap.clear();
                            newParcelMarkers.clear();
                            latitudes.clear();
                            longitudes.clear();
                            //longitudes = new float[4];
                            //latitudes = new float[4];
                        }


                    }
                });
            }
        });
    }


    /**
     * Checks if user has given necessary location permissions, gets current location and syncs map
     */
    private void getCurrentLocation() {

        //request permission, if not granted before
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            //if permission granted

            Task<Location> task = client.getLastLocation();
            task.addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {

                        currentLocation = location;
                        syncMap(location, true);
                    }
                    else{
                        Toast.makeText(getContext(), "Please turn on your location", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else{
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{ACCESS_FINE_LOCATION}, 44);
        }

    }

    /**
     * Sends default location value to syncMap method, in case user doesn't authorize using location services
     */
    private void syncMapWithoutPermissions() {
        final Location defaultLocation = new Location("");
        defaultLocation.setLatitude(DEFAULT_LOCATION_LAT);
        defaultLocation.setLongitude(DEFAULT_LOCATION_LONG);
        syncMap(defaultLocation, false);
        Snackbar.make(getView(), R.string.noPermissionWarning, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    /**
     * Deals with location turned on or off; if off, opens a dialogue that redirects you to settings
     */
    private boolean isGPSEnabled(){

        //if already turned on
        if( isOn()){
            return true;
        }
        else{
            AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                    .setTitle(R.string.gpsAlertTitle)
                    .setMessage(R.string.gpsAlertMessage)
                    .setPositiveButton(R.string.yes,((dialogInterface, i) -> {
                        //user will be redirected to settings
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        getResult.launch(intent);
                    }))
                    .setNegativeButton(R.string.no, ((dialogInterface, i) -> {
                        //if not allowed, sync map with a default location
                        syncMapWithoutPermissions();
                    }))
                    .setCancelable(false).show();
        }

        return false;
    }

    /**
     * Just checks if location is enabled
     */
    private boolean isOn(){
        LocationManager locationManager = (LocationManager) getContext().getSystemService(LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    /**
     * Receiver from having redirected to phone settings
     * Note: onActivityResult() from 2021 was deprecated -_-
     */
    ActivityResultLauncher<Intent> getResult = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {

                    if(isOn()){
                        //activated GPS, get location and sync
                        getCurrentLocation();
                    }
                    else{
                        //did not activate, send default location and sync
                        syncMapWithoutPermissions();
                    }

                }
            });

    /**
     * Removes all markers of the given list, and the respective polygons that they form
     */
    private void removeFromMap(List<Marker> mMarkers, List<Polygon> mPolygons) {
        for (Marker marker: mMarkers) {
            marker.remove();
        }
        mMarkers.clear();

        for (Polygon polygon: mPolygons) {
            polygon.remove();
        }
        mPolygons.clear();
    }

    /**
     * Adds list of markers to map
     */
    private void addMarkerToMap(LatLng latLng, List<LatLng> markers){

        MarkerOptions markerOptions = new MarkerOptions();

        //set position of marker
        markerOptions.position(latLng);

        //animate to move on marker
        gMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));

        //add marker to map
        Marker m = gMap.addMarker(markerOptions);
        allMarkers.add(m);

        //area
        Polygon p = gMap.addPolygon(new PolygonOptions()
                .addAll(markers)
                .strokeColor(Color.BLACK)
                .fillColor(Color.GRAY));
        allPolygons.add(p);

    }

    /**
     * Get array of LatLng of each parcel - from the REST call - and store them in global list
     */
    private void loadUserParcels(ParcelResult parcelResult) {

        ParcelInfoView infoView = parcelResult.getSuccessP();
        List<ParcelInfo> allParcels = infoView.getParcels();

        //add each parcel's marker's locations to list
        for (ParcelInfo parcel: allParcels) {
            allParcelsLocations.add(parcel.getMarkers());
        }
    }

    /**
     * Adds all of the user's parcels to map
     */
    private void addParcelsToMap() {

        // go through the locations of all markers for each parcel
        for(LatLng[] markerLocations: allParcelsLocations){
            List<LatLng> mLocations = Arrays.asList(markerLocations);

            int size = markerLocations.length;
            for (int i = 0; i < size; i++) {
                LatLng location = markerLocations[i];
                addMarkerToMap(location, mLocations);
            }
        }
        //initially, we dont want a lot of markers overbearing the user
        setMarkersVisible(false);
    }

    private String loadLoggedInUserElem(String parameter) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String userParam = sharedPreferences.getString(parameter, "");
        return userParam;

    }

    private void setMarkersVisible(boolean isVisible){
        for (Marker m : allMarkers) {
            m.setVisible(isVisible);
        }
        for (Polygon p : allPolygons) {
            p.setVisible(isVisible);
        }
    }

    private float[] listToArray(List<Float> list){
        float[] newArray = new float[list.size()];

        for (int i = 0; i < list.size(); i++)
            newArray[i] = list.get(i);

        return newArray;

    };

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }



}
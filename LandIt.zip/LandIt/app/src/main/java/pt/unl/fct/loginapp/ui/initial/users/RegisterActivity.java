package pt.unl.fct.loginapp.ui.initial.users;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.databinding.ActivityLoginBinding;
import pt.unl.fct.loginapp.databinding.ActivityRegisterBinding;

public class RegisterActivity extends AppCompatActivity {

    private LoginViewModel registerViewModel;
    private ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_register);

        //get button to change activity - go to login
        Button yourButton = findViewById(R.id.button_register);
        yourButton.setOnClickListener(view -> {
            Intent changeAct = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(changeAct);
            finish();
        });

        //init viewmodel
        registerViewModel = new ViewModelProvider(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        //bind with the things in the xml
        final EditText usernameEditText = findViewById(R.id.username_input_r);
        final EditText passwordEditText = findViewById(R.id.password_input_r);
        final EditText confirmationEditText = findViewById(R.id.password2_input_r);;
        final EditText emailEditText = findViewById(R.id.email_input);
        final EditText nameEditText = findViewById(R.id.name_input);
        final RadioGroup visibilityGroup = findViewById(R.id.radiogroupRegister);
        final EditText homePhoneEditText = findViewById(R.id.homephone_input);
        final EditText mobilePhoneEditText = findViewById(R.id.mobilephone_input);
        final EditText addressEditText = findViewById(R.id.adress_input);
        final EditText nifEditText = findViewById(R.id.nif_input);
        final Button registerButton = findViewById(R.id.register_button_1);
        final ProgressBar loadingProgressBar = findViewById(R.id.loading_register);


        //deal with changes in register forms
        registerViewModel.getRegisterFormState().observe(this, new Observer<pt.unl.fct.loginapp.ui.initial.users.RegisterFormState>() {
            @Override
            public void onChanged(@Nullable RegisterFormState registerFormState) {
                if (registerFormState == null) {
                    return;
                }
                //enables the button to be clickable if condition being true
                registerButton.setEnabled(registerFormState.isDataValid());

                //shows the little error messages if info in forms is not correct
                if (registerFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(registerFormState.getUsernameError()));
                }
                if (registerFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(registerFormState.getPasswordError()));
                }
                if (registerFormState.getConfirmationError() != null) {
                    confirmationEditText.setError(getString(registerFormState.getConfirmationError()));
                }
                if (registerFormState.getEmailError() != null) {
                    emailEditText.setError(getString(registerFormState.getEmailError()));
                }
                if (registerFormState.getNameError() != null) {
                    nameEditText.setError(getString(registerFormState.getNameError()));
                }
            }
        });

        //deal with clicking Sign In bar - Observer for registerResult
        registerViewModel.getRegisterResult().observe(this, new Observer<pt.unl.fct.loginapp.ui.initial.users.RegisterResult>() {
            @Override
            public void onChanged(@Nullable RegisterResult registerResult) {
                if (registerResult == null) {
                    return;
                }

                loadingProgressBar.setVisibility(View.GONE);
                if (registerResult.getError() != null) {
                    showRegisterFailed(registerResult.getError());
                }
                if (registerResult.getSuccess() != null) { //where we change the page being shown
                    updateUiWithUser(registerResult.getSuccess());
                    Intent changeAct = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(changeAct);

                    //Complete and destroy register activity once successful
                    finish();
                }
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //Toast.makeText(getApplicationContext(), "before change",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                registerViewModel.registerDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString(),
                        confirmationEditText.getText().toString(),
                        emailEditText.getText().toString(),
                        nameEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        confirmationEditText.addTextChangedListener(afterTextChangedListener);
        emailEditText.addTextChangedListener(afterTextChangedListener);
        nameEditText.addTextChangedListener(afterTextChangedListener);
        addressEditText.addTextChangedListener(afterTextChangedListener);
        homePhoneEditText.addTextChangedListener(afterTextChangedListener);
        mobilePhoneEditText.addTextChangedListener(afterTextChangedListener);
        nifEditText.addTextChangedListener(afterTextChangedListener);
/*        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loadingProgressBar.setVisibility(View.VISIBLE);
                    registerViewModel.register(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString(),
                            confirmationEditText.getText().toString(),
                            emailEditText.getText().toString(),
                            nameEditText.getText().toString(),
                            privateEditText.getText().toString(),
                            homePhoneEditText.getText().toString(),
                            mobilePhoneEditText.getText().toString(),
                            addressEditText.getText().toString(),
                            nifEditText.getText().toString()
                            );
                }
                return false;
            }
        });*/

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
                registerViewModel.register(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString(),
                        confirmationEditText.getText().toString(),
                        emailEditText.getText().toString(),
                        nameEditText.getText().toString(),
                        getVisibilityValue(visibilityGroup),
                        processEditText(homePhoneEditText),
                        processEditText(mobilePhoneEditText),
                        processEditText(addressEditText),
                        processEditText(nifEditText)
                );
            }
        });
    }

    private String processEditText(EditText text) {
        if(text.getText().toString().equalsIgnoreCase("")) {
            return null;
        }
        return text.getText().toString();
    }

    private String getVisibilityValue(RadioGroup group){
        String result;
        int checkedId = group.getCheckedRadioButtonId();
        RadioButton button = findViewById(checkedId);

        switch(checkedId) {
            case R.id.radioButton_public:
            case R.id.radioButton_private:
                result = button.getText().toString();
                break;
            default:
                result = null;
                break;
        }
        return result;
    }


    private void updateUiWithUser(pt.unl.fct.loginapp.ui.initial.users.RegisteredUserView model) {
        String registerSuccess = getString(R.string.register_success)+ " ";
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), registerSuccess, Toast.LENGTH_LONG).show();
    }

    private void showRegisterFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }
}
package pt.unl.fct.loginapp.ui.initial.users;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.databinding.ActivityRegisterBinding;
import pt.unl.fct.loginapp.ui.homepage.HomePageActivity;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class RegisterActivity extends AppCompatActivity {

    private UserViewModel registerViewModel;
    private ActivityRegisterBinding binding;
    Spinner parcelCountySpinner;
    Spinner parcelDistrictSpinner;
    Spinner parcelMunicipalitySpinner;
    private AuxMethods aux = new AuxMethods();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_register);

        //get button to change activity - go to login
        Button yourButton = findViewById(R.id.button_register);
        yourButton.setOnClickListener(view -> {
            Intent changeAct = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(changeAct);
            finish();
        });

        //init viewmodel
        registerViewModel = new ViewModelProvider(this, new UserViewModelFactory())
                .get(UserViewModel.class);

        //bind with the things in the xml
        final EditText usernameEditText = findViewById(R.id.username_input_r);
        final EditText passwordEditText = findViewById(R.id.password_input_r);
        final EditText confirmationEditText = findViewById(R.id.password2_input_r);
        final EditText emailEditText = findViewById(R.id.email_input);
        final EditText nameEditText = findViewById(R.id.name_input);
        final RadioGroup roleGroup = findViewById(R.id.radiogroupRole);
        final EditText streetEditText = findViewById(R.id.street_input);

        parcelCountySpinner = (Spinner) findViewById(R.id.parcelCounty_input_spinner_r);
        parcelCountySpinner.setEnabled(false);
        aux.setSpinnerAdapterType(parcelCountySpinner, R.string.selectCounty, "", getApplicationContext());
        parcelDistrictSpinner = (Spinner) findViewById(R.id.parcelDistrict_input_spinner_r);
        aux.setSpinnerAdapterType(parcelDistrictSpinner,R.string.selectDistrict, "", getApplicationContext());
        parcelMunicipalitySpinner = (Spinner) findViewById(R.id.parcelFreguesia_input_spinner_r);
        parcelMunicipalitySpinner.setEnabled(false);
        aux.setSpinnerAdapterType(parcelMunicipalitySpinner,R.string.selectMunicipality, "", getApplicationContext());

        final EditText homePhoneEditText = findViewById(R.id.homephone_input);
        final EditText mobilePhoneEditText = findViewById(R.id.mobilephone_input);
        final EditText nifEditText = findViewById(R.id.nif_input);
        final Button registerButton = findViewById(R.id.register_button_1);
        final ProgressBar loadingProgressBar = findViewById(R.id.loading_register);

        //deal with changes in register forms
        registerViewModel.getRegisterFormState().observe(this, registerFormState -> {
            if (registerFormState == null) {
                return;
            }
            //enables the button to be clickable if condition is true
            registerButton.setEnabled(registerFormState.isDataValid()
                    && parcelMunicipalitySpinner.getSelectedItem() != null);

            //shows the little error messages if info in forms is not correct
            if (registerFormState.getUsernameError() != null) {
                usernameEditText.setError(getString(registerFormState.getUsernameError()));
            }
            if (registerFormState.getPasswordError() != null) {
                passwordEditText.setError(getString(registerFormState.getPasswordError()));
            }
            if (registerFormState.getConfirmationError() != null) {
                confirmationEditText.setError(getString(registerFormState.getConfirmationError()));
            }
            if (registerFormState.getEmailError() != null) {
                emailEditText.setError(getString(registerFormState.getEmailError()));
            }
            if (registerFormState.getNameError() != null) {
                nameEditText.setError(getString(registerFormState.getNameError()));
            }
        });

        //observer
        registerViewModel.getUserResult().observe(this, registerResult -> {
            if (registerResult == null) {
                return;
            }

            loadingProgressBar.setVisibility(View.GONE);
            if (registerResult.getError() != null) {
                showRegisterFailed(registerResult.getError());
            }
            if (registerResult.getSuccess() != null) { //where we change the page being shown
                updateUiWithUser(registerResult.getSuccess());
                Intent changeAct = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(changeAct);

                finish();
            }
        });

        //region textwatcher
        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                registerViewModel.registerDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString(),
                        confirmationEditText.getText().toString(),
                        emailEditText.getText().toString(),
                        nameEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        confirmationEditText.addTextChangedListener(afterTextChangedListener);
        emailEditText.addTextChangedListener(afterTextChangedListener);
        nameEditText.addTextChangedListener(afterTextChangedListener);
        homePhoneEditText.addTextChangedListener(afterTextChangedListener);
        mobilePhoneEditText.addTextChangedListener(afterTextChangedListener);
        nifEditText.addTextChangedListener(afterTextChangedListener);
        streetEditText.addTextChangedListener(afterTextChangedListener);

        //endregion

        //region spinners listeners
        //takes care of spinners only showing what needs to
        parcelDistrictSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                registerViewModel.registerDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString(),
                        confirmationEditText.getText().toString(),
                        emailEditText.getText().toString(),
                        nameEditText.getText().toString());
                if(parcelDistrictSpinner.getSelectedItem() != null) {
                    String district = parcelDistrictSpinner.getSelectedItem().toString();
                    //sets the city/county spinner, only showing cities from the district chosen
                    aux.setSpinnerAdapterType(parcelCountySpinner, R.string.selectCounty, district, getApplicationContext());
                    parcelCountySpinner.setEnabled(true);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        parcelCountySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                registerViewModel.registerDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString(),
                        confirmationEditText.getText().toString(),
                        emailEditText.getText().toString(),
                        nameEditText.getText().toString());

                if(parcelCountySpinner.getSelectedItem() != null){
                    String county = parcelCountySpinner.getSelectedItem().toString();
                    aux.setSpinnerAdapterType(parcelMunicipalitySpinner, R.string.selectMunicipality,
                            county, getApplicationContext());
                    parcelMunicipalitySpinner.setEnabled(true);


                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        parcelMunicipalitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                registerViewModel.registerDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString(),
                        confirmationEditText.getText().toString(),
                        emailEditText.getText().toString(),
                        nameEditText.getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //endregion

        registerButton.setOnClickListener(v -> {
            loadingProgressBar.setVisibility(View.VISIBLE);
            byte[] photo = {};
            String county = parcelCountySpinner.getSelectedItem().toString();
            String district = parcelDistrictSpinner.getSelectedItem().toString();
            String municipality = parcelMunicipalitySpinner.getSelectedItem().toString();


            registerViewModel.register(usernameEditText.getText().toString(),
                    passwordEditText.getText().toString(),
                    confirmationEditText.getText().toString(),
                    emailEditText.getText().toString(),
                    nameEditText.getText().toString(),
                    getRoleValue(roleGroup),
                    district,
                    county,
                    municipality,
                    processEditText(streetEditText),
                    processEditText(homePhoneEditText),
                    processEditText(mobilePhoneEditText),
                    processEditText(nifEditText),getString(R.string.code),
                    photo);
        });
    }

    private String processEditText(EditText text) {
        if(text.getText().toString().equalsIgnoreCase("")) {
            return null;
        }
        return text.getText().toString();
    }


    private String getRoleValue(RadioGroup group){
        String result;
        int checkedId = group.getCheckedRadioButtonId();

        switch(checkedId) {
            case R.id.radioButton_owner:
                result = Roles.PROPRIETARIO.toString(); //because it can be different according to phone language
                break;
            case R.id.radioButton_merchant:
                result = Roles.COMERCIANTE.toString();
                break;
            default:
                result = null;
                break;
        }
        return result;
    }


    private void updateUiWithUser(pt.unl.fct.loginapp.ui.initial.users.RegisteredUserView model) {
        String registerSuccess = getString(R.string.register_success)+ " ";
        Toast.makeText(getApplicationContext(), registerSuccess, Toast.LENGTH_LONG).show();
    }

    private void showRegisterFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

}
package pt.unl.fct.loginapp.ui.initial.users;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import android.util.Patterns;

import pt.unl.fct.loginapp.data.users.LoginRepository;
import pt.unl.fct.loginapp.data.users.LoginRepositoryCallback;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.users.LogoutRepositoryCallback;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;
import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.RegisterRepositoryCallback;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import pt.unl.fct.loginapp.ui.homepage.LoggedOutUserView;
import pt.unl.fct.loginapp.ui.homepage.LogoutResult;

public class LoginViewModel extends ViewModel {

    private MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>();
    private MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();
    private MutableLiveData<LogoutResult> logoutResult = new MutableLiveData<>();

    private MutableLiveData<RegisterFormState> registerFormState = new MutableLiveData<>();
    private MutableLiveData<RegisterResult> registerResult = new MutableLiveData<>();

    private LoginRepository loginRepository;

    LoginViewModel(LoginRepository loginRepository) {
        this.loginRepository = loginRepository;
    }

    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    public LiveData<LogoutResult> getLogoutResult() {
        return logoutResult;
    }

    //To deal with the login - using LoginResult
    public void login(String username, String password) {
        // can be launched in a separate asynchronous job
        loginRepository.login(username, password, new LoginRepositoryCallback<LoggedInUser>() {
            @Override
            public void onComplete(Result<LoggedInUser> result) {
                if (result instanceof Result.Success) {
                    LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
                    loginResult.postValue(new LoginResult(new LoggedInUserView(data.getUsername(), data.getRole())));
                } else if(result.isCode("404")){
                    loginResult.postValue(new LoginResult(R.string.loginForbidden));
                } else if(result.isCode("409")){ //should never happen
                    loginResult.postValue(new LoginResult(R.string.loginConflict));
                } else {
                    loginResult.postValue(new LoginResult(R.string.loginFailed));
                }
            }
        });
    }

    //deal with logout
    public void logout(String username) {
        // can be launched in a separate asynchronous job
        loginRepository.logout(username, new LogoutRepositoryCallback<LoggedOutUser>() {
            @Override
            public void onComplete(Result<LoggedOutUser> result) {
                if (result instanceof Result.Success) {
                    //LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
                    logoutResult.postValue(new LogoutResult(new LoggedOutUserView()));
                } else {
                    logoutResult.postValue(new LogoutResult(R.string.logoutFailed));
                }
            }
        });

    }

    LiveData<RegisterFormState> getRegisterFormState() {
        return registerFormState;
    }

    LiveData<RegisterResult> getRegisterResult() {
        return registerResult;
    }

    //To deal with the register - using RegisterResult
    public void register(String username, String password, String confirmation, String email, String name, String visibility, String homePhone, String mobilePhone, String address, String nif) {
        // can be launched in a separate asynchronous job
        loginRepository.register(username, password, confirmation, email, name, visibility, homePhone, mobilePhone, address, nif, new RegisterRepositoryCallback<RegisteredUser>() {

            @Override
            public void onComplete(Result<RegisteredUser> result) {
                if (result instanceof Result.Success) {
                    RegisteredUser data = ((Result.Success<RegisteredUser>) result).getData();
                    registerResult.postValue(new RegisterResult(new RegisteredUserView()));
                } else if (result.isCode("404")) { //should never reach this
                    registerResult.postValue(new RegisterResult(R.string.registerBadRequest));
                } else if (result.isCode("409")) {
                    registerResult.postValue(new RegisterResult(R.string.registerConflict));
                }else{
                        registerResult.postValue(new RegisterResult(R.string.registerFailed));
                    }
                }
        });

    }

    //To validate data put in the boxes - using RegisterFormState
    public void registerDataChanged(String username, String password, String confirmation, String email, String name) {
        if (!isUserNameValid(username)) {
            registerFormState.setValue(new RegisterFormState(R.string.invalidUsername, null, null, null, null));
        } else if (!isPasswordValid(password)) {
            registerFormState.setValue(new RegisterFormState(null, R.string.invalidPassword, null, null, null));
        } else if (!isConfirmationValid(confirmation, password)) {
            registerFormState.setValue(new RegisterFormState(null, null, R.string.invalidConfirmation, null, null));
        } else if (!isEmailValid(email)) {
            registerFormState.setValue(new RegisterFormState(null, null, null, R.string.invalidEmail, null));
        } else if (!isNameValid(name)) {
            registerFormState.setValue(new RegisterFormState(null, null, null, null, R.string.invalidName));
        } else {
            registerFormState.setValue(new RegisterFormState(true));
        }
    }

    //---------------------------------------------------------------------------------------//

    //To validate data put in the boxes - using LoginFormState
    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalidUsername, null));
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.invalidPassword));
        } else {
            loginFormState.setValue(new LoginFormState(true));
        }
    }

    //---------------------------------------------------------------------------------//

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches(); //verifies if is email
        } else {
            return !username.trim().isEmpty();
        }
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5;
    }


    private boolean isConfirmationValid(String confirmation, String password) {
        return confirmation != null && confirmation.equals(password) &&
                confirmation.trim().length() > 5;
    }

    private boolean isEmailValid(String email) {
        if (email == null) {
            return false;
        }
        if (!email.contains("@")) {
            return false;
        }

        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isNameValid(String name) {
        if(name == null) {
            return false;
        }
        else {
            return !name.trim().isEmpty();
        }
    }
}
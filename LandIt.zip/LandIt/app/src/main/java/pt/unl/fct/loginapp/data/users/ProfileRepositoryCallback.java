package pt.unl.fct.loginapp.data.users;

import pt.unl.fct.loginapp.data.Result;

public interface ProfileRepositoryCallback<T> {
    void onComplete(Result<T> result);

}

package pt.unl.fct.loginapp.data.forum.model;

public class ForumRemoveData {

    public String username, owner, name;

    public ForumRemoveData() {}

    public ForumRemoveData(String username, String owner, String name) {
        this.username = username;
        this.owner = owner;
        this.name = name;
    }
}

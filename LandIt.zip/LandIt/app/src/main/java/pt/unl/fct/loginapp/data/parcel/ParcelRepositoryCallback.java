package pt.unl.fct.loginapp.data.parcel;

import pt.unl.fct.loginapp.data.Result;

public interface ParcelRepositoryCallback<T> {
    void onComplete(Result<T> result);

}

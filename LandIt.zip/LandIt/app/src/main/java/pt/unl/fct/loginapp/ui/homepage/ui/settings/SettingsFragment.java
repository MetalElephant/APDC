package pt.unl.fct.loginapp.ui.homepage.ui.settings;

import android.os.Bundle;

import androidx.preference.PreferenceFragmentCompat;
import pt.unl.fct.loginapp.R;

//should I put this directly in the settings activity?
public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey);
    }
}
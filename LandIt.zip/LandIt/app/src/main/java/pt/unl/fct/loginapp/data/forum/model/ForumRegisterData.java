package pt.unl.fct.loginapp.data.forum.model;

public class ForumRegisterData {
    public String username, forumName, topic;

    public ForumRegisterData(){}

    public ForumRegisterData(String username, String forumName, String topic){
        this.username = username;
        this.forumName = forumName;
        this.topic = topic;
    }
}

package pt.unl.fct.loginapp.data.users.model.logout;

public class LoggedOutUser {

    public LoggedOutUser() { }
}

package pt.unl.fct.loginapp.data.forum;

import pt.unl.fct.loginapp.data.Result;

public interface ForumRepositoryCallback<T> {
    void onComplete(Result<T> result);

}

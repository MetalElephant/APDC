package pt.unl.fct.loginapp.data.users.model.updatePwd;

public class UpdatedPwdUser {
    public UpdatedPwdUser(){}
}

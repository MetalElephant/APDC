package pt.unl.fct.loginapp.ui.initial.users;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import java.util.concurrent.Executor;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.databinding.ActivityLoginBinding;
import pt.unl.fct.loginapp.ui.homepage.HomePageActivity;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.SimpleCrypto;

public class LoginActivity extends AppCompatActivity { //the screen for the login

    //the main thing for this, the viewModel
    private UserViewModel userViewModel;
    private ActivityLoginBinding binding;
    private Button fingerBtn;
    private EditText passwordEditText;
    private EditText usernameEditText;
    private static final String APPROVAL = "approval";
    private static final String CRYPTO = "Master-Password";
    private static final String USERNAME = "username";
    private AuxMethods aux = new AuxMethods();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //do binding
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //get button to change activity - go to register
        Button yourButton = findViewById(R.id.button_register);
        yourButton.setOnClickListener(view -> {
            Intent changeAct = new Intent(getApplicationContext(), RegisterActivity.class);
            startActivity(changeAct);
            finish();
        });

        //init viewmodel
        userViewModel = new ViewModelProvider(this, new UserViewModelFactory())
                .get(UserViewModel.class);
        

        //bind with the things in the xml
        usernameEditText = binding.usernameInput;
        passwordEditText = binding.passwordInput;
        final Button loginButton = binding.login;
        final ProgressBar loadingProgressBar = binding.loading;

        //deal with changes in the forms
        userViewModel.getLoginFormState().observe(this, loginFormState -> {
            if (loginFormState == null) {
                return;
            }
            //enables the button to be clickable if condition being true
            loginButton.setEnabled(loginFormState.isDataValid()); //or setClickable

            //shows the little error messages if info in forms is not correct
            if (loginFormState.getUsernameError() != null) {
                usernameEditText.setError(getString(loginFormState.getUsernameError()));
            }
            if (loginFormState.getPasswordError() != null) {
                passwordEditText.setError(getString(loginFormState.getPasswordError()));
            }
        });

        //Observer for LoginResult
        userViewModel.getLoginResult().observe(this, loginResult -> {
            if (loginResult == null) {
                return;
            }

            if (loginResult.getError() != null) {
                loadingProgressBar.setVisibility(View.GONE);
                showLoginFailed(loginResult.getError());

            }
            if (loginResult.getSuccess() != null) { //where we change the page being shown
                updateUiWithUser(loginResult.getSuccess());

                updatePreferences(loginResult.getSuccess().getUsername());

            }
        });

        //region textwatcher
        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                userViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };

        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loadingProgressBar.setVisibility(View.VISIBLE);
                    userViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());
                }
                return false;
            }
        });

        //endregion

        //login
        loginButton.setOnClickListener(v -> {
            loadingProgressBar.setVisibility(View.VISIBLE);
            userViewModel.login(usernameEditText.getText().toString(),
                    passwordEditText.getText().toString());
        });

        //region biometrics

        //login with biometrics/pin
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(LoginActivity.this,
                executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(LoginActivity.this, R.string.authError, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);

                if(aux.loadLoggedInUserElem(APPROVAL,getApplicationContext()).
                        equalsIgnoreCase(getString(R.string.yes))) {

                    try {
                        String pass = SimpleCrypto.decrypt(CRYPTO,
                                aux.loadLoggedInUserElem(CRYPTO, getApplicationContext()) );
                        userViewModel.login(aux.loadUsername(getApplicationContext()),pass);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }else{
                    Toast.makeText(LoginActivity.this, R.string.notAllowedLogin,
                            Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(LoginActivity.this, R.string.authError, Toast.LENGTH_SHORT).show();
            }

        });

        fingerBtn = findViewById(R.id.button_fingerprint);
        checkBiometricsPermissions();

        fingerBtn.setOnClickListener(view -> {
            BiometricPrompt.PromptInfo.Builder prompt = dialogMetric();
            prompt.setDeviceCredentialAllowed(true);
            biometricPrompt.authenticate(prompt.build());

        });

        //endregion

        //once we get the user roles saved to the preferences, then we move into the homepageactivity
        userViewModel.getUserInfoResult().observe(this, profileResult -> {
            if(profileResult == null){
                return;
            }

            loadingProgressBar.setVisibility(View.GONE);

            if (profileResult.getError() != null){
                Toast.makeText(LoginActivity.this, profileResult.getError(), Toast.LENGTH_SHORT).show();
            }
            if(profileResult.getSuccess() != null){
                savePreferences("role", profileResult.getSuccess().getUserInfo().getRole());
                savePreferences("points", profileResult.getSuccess().getUserInfo().getPointsString());

                goToHomePage();

            }

        });
    }


    //region biometrics
    BiometricPrompt.PromptInfo.Builder dialogMetric(){
        return new BiometricPrompt.PromptInfo.Builder()
                .setTitle(getString(R.string.actionSignIn))
                .setSubtitle(getString(R.string.actionSignInFinger));
    }

    private void checkBiometricsPermissions() {
        BiometricManager manager = BiometricManager.from(this);
        String info = "";

        switch(manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK
                | BiometricManager.Authenticators.BIOMETRIC_STRONG)){
            case BiometricManager.BIOMETRIC_SUCCESS:
                info = getString(R.string.biometricsSuccess);
                enableButton(true);
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                info =  getString(R.string.biometricsError1);
                enableButton(false);
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                info =  getString(R.string.biometricsError2);
                enableButton(false);
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                info =  getString(R.string.biometricsError3);
                enableButton(false, true);
                break;
            default:
                info = getString(R.string.no);
                break;
        }

        fingerBtn.setText(info);

    }

    private void enableButton(boolean enable){

        fingerBtn.setEnabled(enable);

    }

    private void enableButton(boolean enable, boolean enroll){
        enableButton(enable);
        if(!enroll) return;
        Intent enrollIntent = new Intent(Settings.ACTION_BIOMETRIC_ENROLL);
        enrollIntent.putExtra(Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                BiometricManager.Authenticators.BIOMETRIC_WEAK
                        | BiometricManager.Authenticators.BIOMETRIC_STRONG);
        startActivity(enrollIntent);
    }

    //endregion

    private void updateUiWithUser(LoggedInUserView model) {
        String welcome = getString(R.string.welcome) + model.getUsername();
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

    private void savePreferences(String key, String value){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();

    }


    private void goToHomePage() {
        Intent changeAct = new Intent(getApplicationContext(), HomePageActivity.class);
        startActivity(changeAct);
        finish();
    }

    private void updatePreferences(String username) {

        if(!username.equals(aux.loadUsername(getApplicationContext()))
        ||aux.loadUsername(getApplicationContext()) == null) { //its a new user
            AlertDialog alertDialog = aux.initAlert(LoginActivity.this, R.string.askSaveLoginTitle, R.string.askSaveLogin);

            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes),
                    (dialogInterface, j) -> {

                        savePreferences(APPROVAL, getString(R.string.yes));

                        try {
                            String a = SimpleCrypto.encrypt(CRYPTO, passwordEditText.getText().toString());
                            savePreferences(CRYPTO, a);
                            String p = aux.loadLoggedInUserElem(CRYPTO, getApplicationContext());
                            String finalS = SimpleCrypto.decrypt(CRYPTO, p);

                            savePreferences(USERNAME, username);
                            userViewModel.getUserInfo(username);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        /**
                         * I was going to implement EncryptedSharedPreferences, but the API requirements
                         * were too high, so I had to use the normal preferences with a bit of encryption
                         * Not ideal at all, probably should make the user just login every time
                         */

                    });
            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no),
                    (dialogInterface, j) -> {
                        savePreferences(APPROVAL, getString(R.string.no));
                        savePreferences(USERNAME, username);
                        userViewModel.getUserInfo(username);
                    });
            alertDialog.show();

        }else{
            savePreferences(USERNAME, username);
            userViewModel.getUserInfo(username);

        }



    }




}
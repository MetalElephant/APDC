package pt.unl.fct.loginapp.ui.homepage.ui.forums;

import androidx.annotation.Nullable;

public class RegisterForumFormState {
    @Nullable
    private Integer forumName;
    @Nullable
    private Integer topic;


    private boolean isDataValid;

    RegisterForumFormState(@Nullable Integer forumName, @Nullable Integer topic) {
        this.forumName = forumName;
        this.topic = topic;
        this.isDataValid = false;
    }

    RegisterForumFormState(boolean isDataValid) {
        this.forumName = null;
        this.topic = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getForumName() {
        return forumName;
    }

    @Nullable
    public Integer getTopic() {
        return topic;
    }

    boolean isDataValid() {
        return isDataValid;
    }
}

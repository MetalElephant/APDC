package pt.unl.fct.loginapp.data.parcel;

import com.google.gson.JsonSyntaxException;

import java.util.List;
import java.util.concurrent.Executor;

import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.RegisteredParcel;
import pt.unl.fct.loginapp.data.users.RegisterRepositoryCallback;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;

public class ParcelRepository {

    private static volatile ParcelRepository instance;

    private ParcelDataSource dataSource;
    private Executor executor;

    // If user credentials will be cached in local storage, it is recommended it be encrypted
    // @see https://developer.android.com/training/articles/keystore
    private RegisteredParcel parcel = null;

    // private constructor : singleton access
    private ParcelRepository(ParcelDataSource dataSource, Executor executor) {
        this.dataSource = dataSource;
        this.executor = executor;
    }

    public static ParcelRepository getInstance(ParcelDataSource dataSource, Executor executor) {
        if (instance == null) {
            instance = new ParcelRepository(dataSource,executor);
        }
        return instance;
    }

   // public boolean isLoggedIn() {        return user != null;    }
    public void registerParcel(String owner, String[] owners, String name, String county, String district, String freguesia, String description,
                               String groundType, String currUsage,String prevUsage, String area,
                               double[] allLats, double[] allLongs, ParcelRepositoryCallback<RegisteredParcel> callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {

                // go to dataSource and do the REST services
                    Result<RegisteredParcel> result = dataSource.registerParcel(owner, owners, name, county, district, freguesia, description, groundType,currUsage,
                            prevUsage, area, allLats, allLongs);
                    if (result instanceof Result.Success) {
                    }

                callback.onComplete(result);
            }
        });
    }

    public void showParcels(String username, ParcelRepositoryCallback<List<ParcelInfo>> callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<List<ParcelInfo>> result = dataSource.showParcels(username);

                callback.onComplete(result);
            }
        });
    }
}

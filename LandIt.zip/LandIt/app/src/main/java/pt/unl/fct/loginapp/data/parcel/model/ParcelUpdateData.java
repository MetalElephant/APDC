package pt.unl.fct.loginapp.data.parcel.model;

public class ParcelUpdateData {
    public String username, owner, parcelName, description, groundType, currUsage, prevUsage;
    public String[] owners;
    public double[] allLats, allLngs;

    public ParcelUpdateData() {}

    public ParcelUpdateData(String username, String owner, String[] owners, String parcelName,
                            String description, String groundType, String currUsage,
                            String prevUsage, double[] allLats, double[] allLngs) {
        this.username = username;
        this.owner = owner;
        this.parcelName = parcelName;
        this.owners = owners;
        this.description = description;
        this.groundType = groundType;
        this.currUsage = currUsage;
        this.prevUsage = prevUsage;
        this.allLats = allLats;
        this.allLngs = allLngs;
    }
}

package pt.unl.fct.loginapp.ui.homepage.ui.forums;

import java.util.List;
import pt.unl.fct.loginapp.data.forum.model.MessageInfo;

public class ForumResultListMsgView {
    public List<MessageInfo> messages;

    public ForumResultListMsgView(List<MessageInfo> allMessages){
        this.messages = allMessages;
    }

    public List<MessageInfo> getMessages() {
        return messages;
    }
}

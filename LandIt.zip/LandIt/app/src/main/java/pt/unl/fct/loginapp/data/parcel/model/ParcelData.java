package pt.unl.fct.loginapp.data.parcel.model;

public class ParcelData {

    public String owner, parcelName, county, district, freguesia, description, groundType, currUsage, prevUsage, area;
    public String[] owners;
    public double[] allLats, allLngs;

    public ParcelData() {}

    public ParcelData(String owner, String[] owners, String parcelName, String county, String district, String freguesia, String description,
                      String groundType, String currUsage, String prevUsage, String area, double[] allLats, double[] allLngs) {
        this.owner = owner;
        this.owners = owners;
        this.parcelName = parcelName;
        this.county = county;
        this.district = district;
        this.freguesia = freguesia;
        this.description = description;
        this.groundType = groundType;
        this.currUsage = currUsage;
        this.prevUsage = prevUsage;
        this.area = area;
        this.allLats = allLats;
        this.allLngs = allLngs;
    }
}

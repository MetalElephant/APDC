package pt.unl.fct.loginapp.data.parcel.model;

public class ParcelData {

    public String owner, parcelName, county, district, autarchy, description, groundType, currUsage, prevUsage;
    public String[] owners;
    public double[] allLats, allLngs;
    public byte[] confirmation;
    public int type;

    public ParcelData() {}

    public ParcelData(String owner, String[] owners, String parcelName, String district, String county, String autarchy, String description,
                      String groundType, String currUsage, String prevUsage, double[] allLats, double[] allLngs, byte[] confirmation,
                      int type) {
        this.owner = owner;
        this.owners = owners;
        this.parcelName = parcelName;
        this.county = county;
        this.district = district;
        this.autarchy = autarchy;
        this.description = description;
        this.groundType = groundType;
        this.currUsage = currUsage;
        this.prevUsage = prevUsage;
        this.allLats = allLats;
        this.allLngs = allLngs;
        this.confirmation = confirmation;
        this.type = type;
    }
}

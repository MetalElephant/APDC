package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

public class RewardResultView {
    public RewardResultView(){}
}

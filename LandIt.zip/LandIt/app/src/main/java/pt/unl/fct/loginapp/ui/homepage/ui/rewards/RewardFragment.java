package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;
import pt.unl.fct.loginapp.databinding.RewardFragmentBinding;
import pt.unl.fct.loginapp.ui.homepage.HomePageActivity;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class RewardFragment extends Fragment {

    private RewardViewModel rewardViewModel;
    private RewardFragmentBinding binding;
    private ListView list;
    private ListView listRedeemed;
    private ArrayList<RewardData> allRewards;
    private ArrayList<RewardData> allRewardsRedeemed;
    private ArrayList<String> toDisplayList1;
    private ArrayList<String> toDisplayList2;
    private LinearLayout loadingLayout;
    private ArrayAdapter<String> arrayAdapter;
    private ArrayAdapter<String> arrayAdapter2;
    String role, username;
    private AuxMethods aux = new AuxMethods();

    private boolean shouldRefresh = false;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        rewardViewModel =
                new ViewModelProvider(this, new RewardViewModelFactory())
                        .get(RewardViewModel.class);;


        binding = RewardFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        username = aux.loadUsername(getContext());
        role = aux.loadRole(getContext());
        String points = aux.loadPoints(getContext());

        //region bindings & initializations
        Button addRewardBtn = binding.registerRewardBtn;
        list = binding.listOfRedeemedRewards;
        listRedeemed = binding.listOfRedeemableRewards;
        loadingLayout = binding.layoutLoading;
        TextView noRewardsTxt = binding.textNoRewards;
        TextView redeemInstructions = binding.redeemRewardTxt;
        redeemInstructions.setText(getString(R.string.redeemRewardInstructions,points));
        TextView deleteInstructions = binding.deleteRewardTxt;
        TextView rewardsRedeemedTxt = binding.yourRewardsTxt;
        allRewards = new ArrayList<>();
        toDisplayList1 = new ArrayList<>();
        allRewardsRedeemed = new ArrayList<>();
        toDisplayList2 = new ArrayList<>();

        //endregion

        //region load rewards (according to role)
        if(Roles.isMerchant(role)){
            addRewardBtn.setVisibility(View.VISIBLE);
            redeemInstructions.setVisibility(View.GONE);
            rewardsRedeemedTxt.setVisibility(View.GONE);

            rewardViewModel.listRewards(username);

        }else if(Roles.isOwner(role)){
            deleteInstructions.setVisibility(View.GONE);


            rewardViewModel.listRedeemable(username);
            rewardViewModel.listRedeemed(username);
        }else{
            redeemInstructions.setVisibility(View.GONE);
            rewardsRedeemedTxt.setVisibility(View.GONE);
            rewardViewModel.listAllRewards();
        }

        //observer
        rewardViewModel.getRewardResult().observe(getViewLifecycleOwner(), rewardResult -> {
            loadingLayout.setVisibility(View.GONE);
            if(rewardResult == null)
                return;

            if(rewardResult.getError() != null)
                aux.makeToast(rewardResult.getError(),getContext());

            if(rewardResult.getSuccess()!= null){ //success for registering reward
                allRewards.clear();
                toDisplayList1.clear();
                rewardViewModel.listRewards(username);
            }

            if(rewardResult.getSuccessR() != null){ //success for getting list of rewards
                if(allRewards.isEmpty())
                    loadRewards(rewardResult);


                //set the listView with elements loaded
                if(allRewards.isEmpty() && toDisplayList1.isEmpty()){
                    noRewardsTxt.setVisibility(View.VISIBLE);
                }
                else {
                    noRewardsTxt.setVisibility(View.GONE);
                    setListView();
                }
            }
        });

        rewardViewModel.getRedeemedResult().observe(getViewLifecycleOwner(), rewardResult -> {
            loadingLayout.setVisibility(View.GONE);
            if(rewardResult == null)
                return;

            if(rewardResult.getError() != null)
                aux.makeToast(rewardResult.getError(),getContext());

            if(rewardResult.getSuccessR() != null){ //success for getting list of rewards ALREADY REDEEMED
                if(allRewardsRedeemed.isEmpty())
                    loadRewardsRedeemed(rewardResult);

                //set the listView with elements loaded
                if(allRewardsRedeemed.isEmpty() && toDisplayList2.isEmpty()){
                    noRewardsTxt.setVisibility(View.VISIBLE);
                }
                else {
                    setListViewRedeemed();
                }
            }

        });
        //endregion

        //region go to register reward
        addRewardBtn.setOnClickListener(view -> {

            Intent intent = new Intent(getContext(), RegisterRewardActivity.class);
            startActivity(intent);



        });
        //endregion

        //region redeem & delete observers
        rewardViewModel.getRedeemResult().observe(getViewLifecycleOwner(), rewardResult -> {

            if(rewardResult == null){
                return;
            }

            if(rewardResult.getError() != null){
                aux.makeToast(rewardResult.getError(), getContext());
            }

            if(rewardResult.getSuccess() != null){
                Snackbar.make(root, R.string.redeemRewardSuccess, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                getActivity().onBackPressed();
            }

        });

        rewardViewModel.getRemoveResult().observe(getViewLifecycleOwner(), rewardResult -> {
            if(rewardResult == null){
                return;
            }

            if(rewardResult.getError() != null){
                aux.makeToast(rewardResult.getError(), getContext());
            }

            if(rewardResult.getSuccess() != null){
                Snackbar.make(root, R.string.deleteRewardSuccess, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                refreshFragment();
            }

        });

        //endregion

        //region search
        SearchView searchView = binding.searchRewardsView;
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                doSearchResults(s);

                return false;
            }
        });

        //endregion

        return root;
    }

    //region list handling
    private void setListViewRedeemed() {
        ListView list = initTableRedeemed();

    }

    private void setListView() {
        ListView list = initTable();

        list.setOnItemClickListener((adapterView, view, i, l) -> {

            if(Roles.isModOrSUOrMerchant(role)){
                AlertDialog alertDialog = aux.initAlert(getContext(),R.string.deleteReward,
                        R.string.deleteRewardWarning);
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes),(dialogInterface, j) -> {
                    RewardData reward = allRewards.get(i);
                    rewardViewModel.removeReward(reward.getOwner(),username,reward.getName());

                } );
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE,getString(R.string.no), (dialogInterface, i1) -> {

                });
                alertDialog.show();

            }
            else{
                AlertDialog alertDialog = aux.initAlert(getContext(),R.string.redeemReward,
                        R.string.redeemRewardWarning);
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes),(dialogInterface, j) -> {
                    RewardData reward = allRewards.get(i);
                    rewardViewModel.redeemRewards(reward.getOwner(),username,reward.getName());

                } );
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE,getString(R.string.no), (dialogInterface, i1) -> {

                });

                alertDialog.show();
            }


        });
    }


    private void loadRewards(RewardResult rewardResult) {
        RewardListView infoView = rewardResult.getSuccessR();
        List<RewardData> listR = infoView.getRewards();

        for (RewardData reward : listR) {
            allRewards.add(reward);
            toDisplayList1.add(reward.toString());
        }
    }

    private void loadRewardsRedeemed(RewardResult rewardResult) {
        RewardListView infoView = rewardResult.getSuccessR();
        List<RewardData> listR = infoView.getRewards();

        for (RewardData reward : listR) {
            allRewardsRedeemed.add(reward);
            toDisplayList2.add(reward.toString());
        }
    }


    private void doSearchResults(String s) {
        ArrayList<String> filteredRewards = new ArrayList<>();

        for (int i = 0; i< allRewards.size(); i++){
            RewardData elem = allRewards.get(i);
            if(elem.getName().toLowerCase().contains(s.toLowerCase())
                    || elem.getOwner().toLowerCase().contains(s.toLowerCase())) {
                filteredRewards.add(toDisplayList1.get(i));
            }
        }
        arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, filteredRewards);
        list.setAdapter(arrayAdapter);
    }

    private ListView initTable(){
        arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, toDisplayList1);

        list.setAdapter(arrayAdapter);

        arrayAdapter.notifyDataSetChanged();

        return list;
    }

    private ListView initTableRedeemed(){
        arrayAdapter2 = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, toDisplayList2);

        listRedeemed.setAdapter(arrayAdapter2);

        arrayAdapter2.notifyDataSetChanged();

        return list;
    }

    //endregion

    //literally my biggest salvation ever
    private void refreshFragment(){
        NavController navController = Navigation.findNavController(getActivity(),R.id.nav_host_fragment_content_main);
        navController.popBackStack();
        navController.navigate(R.id.nav_rewards_V1);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Check should we need to refresh the fragment
        if(shouldRefresh){
           refreshFragment();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        shouldRefresh = true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
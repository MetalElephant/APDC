package pt.unl.fct.loginapp.ui.homepage.ui.userManagement;

import androidx.lifecycle.ViewModel;

public class ManageUsersViewModel extends ViewModel {
    public ManageUsersViewModel(){}

}
package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

import androidx.annotation.Nullable;

public class RegisterRewardFormState {

    @Nullable
    private Integer rewardNameError;
    @Nullable
    private Integer descriptionError;
    @Nullable
    private Integer priceError;

    private boolean isDataValid;

    RegisterRewardFormState(@Nullable Integer rewardNameError, @Nullable Integer descriptionError,
                          @Nullable Integer priceError) {
        this.rewardNameError = rewardNameError;
        this.descriptionError = descriptionError;
        this.priceError = priceError;
        this.isDataValid = false;
    }

    RegisterRewardFormState(boolean isDataValid) {
        this.rewardNameError = null;
        this.descriptionError = null;
        this.priceError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getRewardNameError() {
        return rewardNameError;
    }

    @Nullable
    public Integer getDescriptionError() {
        return descriptionError;
    }

    @Nullable
    public Integer getPriceError() {
        return priceError;
    }

    public boolean isDataValid() {
        return isDataValid;
    }
}

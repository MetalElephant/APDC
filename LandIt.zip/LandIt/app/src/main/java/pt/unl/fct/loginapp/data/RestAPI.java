package pt.unl.fct.loginapp.data;

import java.util.List;

import pt.unl.fct.loginapp.data.forum.model.ForumInfo;
import pt.unl.fct.loginapp.data.forum.model.ForumMessageData;
import pt.unl.fct.loginapp.data.forum.model.ForumRegisterData;
import pt.unl.fct.loginapp.data.forum.model.ForumRemoveData;
import pt.unl.fct.loginapp.data.forum.model.MessageInfo;
import pt.unl.fct.loginapp.data.forum.model.RegisteredForum;
import pt.unl.fct.loginapp.data.forum.model.RemoveMessageData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.ParcelSearchRegionData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelUpdateData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelVerifyData;
import pt.unl.fct.loginapp.data.parcel.model.RegisteredParcel;
import pt.unl.fct.loginapp.data.parcel.model.RequestData;
import pt.unl.fct.loginapp.data.rewards.model.RegisteredReward;
import pt.unl.fct.loginapp.data.rewards.model.RemoveObjectData;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;
import pt.unl.fct.loginapp.data.rewards.model.RewardRedeemData;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.model.login.LoginData;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;
import pt.unl.fct.loginapp.data.users.model.logout.LogoutData;
import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;
import pt.unl.fct.loginapp.data.users.model.register.RegisterData;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import pt.unl.fct.loginapp.data.users.model.updateInfo.UserUpdateData;
import pt.unl.fct.loginapp.data.users.model.updatePwd.PasswordUpdateData;
import pt.unl.fct.loginapp.data.users.model.updatePwd.UpdatedPwdUser;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.PUT;

public interface RestAPI {

    //users
    @PUT("/rest/user/login")
    Call<LoggedInUser> doLogin(@Body LoginData credentials) ;

    @POST("/rest/user/register")
    Call<RegisteredUser> doRegister(@Body RegisterData credentials);

    @HTTP(method = "DELETE", path = "/rest/user/logout", hasBody = true)
    Call<LoggedOutUser> doLogout(@Body LogoutData logoutData);

    @PUT("/rest/user/updatePwd") //tc
    Call<UpdatedPwdUser> doUpdatePwd(@Body PasswordUpdateData passwordUpdateData);

    @PUT("/rest/user/update") //tc
    Call<RegisteredUser> doUpdateUser(@Body UserUpdateData userUpdateData);

    @POST("/rest/user/info") //tc
    Call<UserInfo> getInfo(@Body RequestData requestData);

    @GET("/rest/user/list")
    Call<List<UserInfo>> listAllUsers();

    @HTTP(method = "DELETE", path = "/rest/user/remove", hasBody = true)
    Call<RegisteredUser> removeUser(@Body RequestData data);


    //parcels
    @POST("/rest/parcel/register")
    Call<RegisteredParcel> doRegisterParcel(@Body ParcelData parcelRegisterData);

    @POST("/rest/parcel/listUser")
    Call<List<ParcelInfo>> doShowParcel(@Body RequestData requestData);

    @POST("rest/parcel/listRep")
    Call<List<ParcelInfo>> showRepParcels(@Body RequestData requestData); //tc

    @POST("rest/parcel/verify")
    Call<RegisteredParcel> verifyParcel(@Body ParcelVerifyData verifyData); //tc

    @PUT("/rest/parcel/update")
    Call<RegisteredParcel> doUpdateParcel(@Body ParcelUpdateData parcelUpdateData); //tc

    @HTTP(method = "DELETE", path = "/rest/parcel/remove", hasBody = true)
    Call<RegisteredParcel> removeParcel(@Body RemoveObjectData removeObjectData);

    @POST("/rest/parcel/searchByRegion")
    Call<List<ParcelInfo>> listParcelsFromRegion(@Body ParcelSearchRegionData data);


    //rewards
    @POST("/rest/reward/register")
    Call<RegisteredReward> doRegisterReward(@Body RewardData rewardData);

    @HTTP(method = "DELETE", path = "/rest/reward/remove", hasBody = true)
    Call<RegisteredReward> removeReward(@Body RemoveObjectData data);

    @PUT("/rest/reward/redeem")
    Call<RegisteredReward> doRedeem(@Body RewardRedeemData data);

    @POST("rest/reward/list") //show all merchant - created rewards
    Call<List<RewardData>> listMerchantRewards(@Body RequestData data);

    @GET("rest/reward/listAll")
    Call<List<RewardData>> listAllRewards();

    @POST("rest/reward/listRedeemable")
    Call<List<RewardData>> listRedeemable(@Body RequestData data);

    @POST("rest/reward/listRedeemed")
    Call<List<RewardData>> listRedeemed(@Body RequestData data);


    //forums
    @POST("rest/forum/register")
    Call<RegisteredForum> doRegisterForum(@Body ForumRegisterData data);

    @POST("rest/forum/message")
    Call<RegisteredForum> doSendMessage(@Body ForumMessageData data);

    @HTTP(method = "DELETE", path = "/rest/forum/removeForum", hasBody = true)
    Call<RegisteredForum> removeForum (@Body ForumRemoveData data);

    @HTTP(method = "DELETE", path = "/rest/forum/removeMessage", hasBody = true)
    Call<RegisteredForum> removeMessage (@Body RemoveMessageData data);

    @POST("rest/forum/listParcel")
    Call<List<ForumInfo>> listForums(@Body RequestData data);

    @GET("rest/forum/list")
    Call<List<ForumInfo>> listAllForums();

    @POST("rest/forum/listMessages")
    Call<List<MessageInfo>> listMessages(@Body RequestData data);



}

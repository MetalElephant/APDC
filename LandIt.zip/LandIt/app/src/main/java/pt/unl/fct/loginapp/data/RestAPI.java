package pt.unl.fct.loginapp.data;

import java.util.List;

import pt.unl.fct.loginapp.data.parcel.model.ParcelData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.RegisteredParcel;
import pt.unl.fct.loginapp.data.parcel.model.RequestData;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.model.login.LoginData;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;
import pt.unl.fct.loginapp.data.users.model.logout.LogoutData;
import pt.unl.fct.loginapp.data.users.model.register.RegisterData;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.HTTP;
import retrofit2.http.POST;

public interface RestAPI {
    @POST("/rest/users/login")
    Call<LoggedInUser> doLogin(@Body LoginData credentials) ;

    @POST("/rest/users/register")
    Call<RegisteredUser> doRegister(@Body RegisterData credentials);

    @HTTP(method = "DELETE", path = "/rest/users/logout", hasBody = true)
    Call<LoggedOutUser> doLogout(@Body LogoutData logoutData);

    @POST("/rest/parcel/register")
    Call<RegisteredParcel> doRegisterParcel(@Body ParcelData parcelRegisterData);

    @POST("/rest/parcel/list")
    Call<List<ParcelInfo>> doShowParcel(@Body RequestData requestData);
}

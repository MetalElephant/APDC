package pt.unl.fct.loginapp.data.forum.model;

public class RegisteredForum {
    public RegisteredForum(){}
}

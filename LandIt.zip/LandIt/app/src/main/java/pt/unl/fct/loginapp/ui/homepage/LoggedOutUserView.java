package pt.unl.fct.loginapp.ui.homepage;

public class LoggedOutUserView {
    public LoggedOutUserView(){}
}

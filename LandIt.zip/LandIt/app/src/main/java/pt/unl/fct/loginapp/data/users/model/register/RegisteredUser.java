package pt.unl.fct.loginapp.data.users.model.register;

public class RegisteredUser {
    public RegisteredUser() { }

}

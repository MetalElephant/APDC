package pt.unl.fct.loginapp.ui.initial.users;

class RegisteredUserView {
    RegisteredUserView() { }
}

package pt.unl.fct.loginapp.ui.homepage.ui.profile;

import static pt.unl.fct.loginapp.util.Roles.isMod;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.snackbar.Snackbar;

import java.io.InputStream;
import java.net.URL;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;
import pt.unl.fct.loginapp.databinding.ProfileFragmentBinding;
import pt.unl.fct.loginapp.ui.homepage.HomePageActivity;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.RegisterParcelFragmentArgs;
import pt.unl.fct.loginapp.ui.initial.InitialActivity;
import pt.unl.fct.loginapp.ui.initial.users.UserResult;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModelFactory;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModel;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class ProfileFragment extends Fragment {

    private ProfileFragmentBinding binding;
    private UserViewModel userViewModel;
    ShapeableImageView profilePic;
    RelativeLayout imageLayout;
    EditText nameEdit;
    TextView usernameText;
    TextView usernameText2;
    EditText emailEdit;
    EditText mobilePhoneEdit;
    EditText homePhoneEdit;
    EditText addressEdit;
    EditText nifEdit;
    TextView profileName;
    TextView profileRole;
    TextView profileUsername;
    TextView regionTxt;
    ProgressBar loadingUpdate;
    private String username;
    private String picUrl;
    private static final String UNDEFINED = "Não Definido";


    private AuxMethods aux = new AuxMethods();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ProfileViewModel profileViewModel =
                new ViewModelProvider(this).get(ProfileViewModel.class);

        userViewModel = new ViewModelProvider(this, new UserViewModelFactory())
                .get(UserViewModel.class);

        binding = ProfileFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        username = aux.loadUsername(getContext());

        //region bindings
        profilePic = binding.profilePic;
        nameEdit = binding.profileNameEdit;
        usernameText = binding.profileUsername;
        usernameText2 = binding.profileUsernameEdit;
        emailEdit = binding.profileEmail;
        mobilePhoneEdit = binding.profileMobilePhone;
        homePhoneEdit = binding.profileHomePhone;
        addressEdit = binding.profileAddress;
        nifEdit = binding.profileNif;
        profileName = binding.profileName;
        profileUsername = binding.profileUsername;
        profileUsername.setText(username);
        profileRole = binding.profileRole;
        regionTxt = binding.profileRegion;

        loadingUpdate = binding.loadingUpdateInfo;
        loadingUpdate.setVisibility(View.GONE);

        //this is so there is a sort of "loading screen" while the rest call grabs the user's info
        imageLayout = binding.imgUser;
        imageLayout.setVisibility(View.GONE);
        LinearLayout infoLayout = binding.linearLayoutInfo;
        infoLayout.setVisibility(View.GONE);
        ProgressBar loadingInfo = binding.loadingInfo;
        TextView loadingInfoTxt = binding.loadingInfoTxt;
        TextView youAreTxt = binding.youAreTxt;
        youAreTxt.setVisibility(View.GONE);

        //endregion

        //region getInfo
        userViewModel.getUserInfo(username);

        //result observer
        userViewModel.getUserInfoResult().observe(getViewLifecycleOwner(), profileResult -> {

            if (profileResult == null) {
                return;
            }

            if (profileResult.getError() != null) {
                Toast.makeText(getContext(), R.string.no, Toast.LENGTH_SHORT).show();
            }
            if (profileResult.getSuccess() != null) {
                loadingInfo.setVisibility(View.GONE);
                loadingInfoTxt.setVisibility(View.GONE);
                youAreTxt.setVisibility(View.VISIBLE);
                infoLayout.setVisibility(View.VISIBLE);
                imageLayout.setVisibility(View.VISIBLE);
                loadUserInfo(profileResult);
            }
        });

        //endregion

        //region updateInfo

        Button updateBtn = binding.updateProfileInfoBtn;
        updateBtn.setOnClickListener(view -> {
            loadingUpdate.setVisibility(View.VISIBLE);

            String name = toText(nameEdit);
            String email = toText(emailEdit);
            String username1 = username;
            String username2 = usernameText.getText().toString();
            String mPhone = toText(mobilePhoneEdit);
            String hPhone = toText(homePhoneEdit);
            String address = toText(addressEdit);
            String nif = toText(nifEdit);
            //String visibility = getVisibilityValue(visibilityGroup);
            String[] region = regionTxt.getText().toString().split(AuxMethods.COMMASPACE);
            userViewModel.updateUser(username1, username2, name, email,
                    region[0], region[1], region[2],address,
                    hPhone, mPhone, nif);


        });

        //observer
        userViewModel.getUpdateResult().observe(getViewLifecycleOwner(), userResult -> {
            loadingUpdate.setVisibility(View.GONE);
            if (userResult == null) {
                return;
            }
            if (userResult.getError() != null) {
                Toast.makeText(getContext(), R.string.defaultError, Toast.LENGTH_SHORT).show();
            }
            if (userResult.getSuccess() != null) {
                Snackbar.make(root, R.string.updateUserSuccess, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

            }
        });

        //changedFields
        userViewModel.getUpdateUserFormState().observe(getViewLifecycleOwner(), updateUserFormState -> {

            if (updateUserFormState == null) {
                return;
            }

            updateBtn.setEnabled(updateUserFormState.isDataValid());

            if (updateUserFormState.getNameError() != null) {
                nameEdit.setError(getString(updateUserFormState.getNameError()));
            }
            if (updateUserFormState.getEmailError() != null) {
                emailEdit.setError(getString(updateUserFormState.getEmailError()));
            }

        });

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                userViewModel.updateUserDataChanged(toText(nameEdit), toText(emailEdit));
            }
        };
        nameEdit.addTextChangedListener(textWatcher);
        emailEdit.addTextChangedListener(textWatcher);

        //endregion

        //region removeuser
        Button deleteUserBtn = binding.deleteUserBtn;
        deleteUserBtn.setOnClickListener(view -> {
            deleteAction();

        });

        userViewModel.getUserResult().observe(getViewLifecycleOwner(), result -> {
            if (result == null) {
                return;
            }

            loadingUpdate.setVisibility(View.GONE);
            if (result.getError() != null) {
                Snackbar.make(root, result.getError(), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
            if (result.getSuccess() != null) { //where we change the page being shown
                //Intent intent = new Intent(getContext(), InitialActivity.class);
                //startActivity(intent);
                getActivity().finish();
            }
        });


        //endregion

        //go to modifyPassword fragment
        Button modifyPwdBtn = binding.modifyPwdBtn;
        modifyPwdBtn.setOnClickListener(view -> Navigation.findNavController(view)
                .navigate(ProfileFragmentDirections.actionNavProfileToModifyPasswordFragment()));


        return root;
    }

    /**
     * Starts alert box and sends delete rest call if user confirms the decision by
     * inputting their username correctly
     */
    void deleteAction() {
        final EditText inputUsername = new EditText(getContext());

        AlertDialog alertDialog =
                aux.initAlert(getContext(),R.string.deleteAcc,R.string.deleteAccWarning);

        alertDialog.setView(inputUsername);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes),
                (dialogInterface, i) -> {
                    if(inputUsername.getText().toString().equals(username)) {
                        //call delete
                        loadingUpdate.setVisibility(View.VISIBLE);

                        //todo if role == mod etc, then different usernames
                        userViewModel.removeUser(username, username);
                    }
                    else{
                        aux.makeToast(R.string.wrongUsername, getContext());
                    }

                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no),
                (dialogInterface, i) -> {
                });
        alertDialog.show();
    }



    private void loadUserInfo(ProfileResult profileResult) {

        UserInfoView userInfoView = profileResult.getSuccess();
        UserInfo user = userInfoView.getUserInfo();
        usernameText.setText(username);
        usernameText2.setText(username);
        String name = user.getName();
        updateText(nameEdit, name);
        profileName.setText(name);
        String email = user.getEmail();
        updateText(emailEdit, email);
        String mobilePhone = user.getMobilephone();
        updateText(mobilePhoneEdit, mobilePhone);
        String homePhone = user.getLandphone();
        updateText(homePhoneEdit, homePhone);
        String address = user.getStreet();
        updateText(addressEdit, address);
        String nif = user.getNif();
        updateText(nifEdit, nif);
        String role = user.getRole();
        profileRole.setText(role);
        String region = user.getAddressRegion();
        regionTxt.setText(region);


        picUrl = user.getPhoto();

        //if user doesnt have a picture, we just show the default user pic
        if (!picUrl.equalsIgnoreCase(UNDEFINED)) {
            getImageThread.start();
        }

    }

    /**
     * load the image using a new thread, otherwise we get an exception thrown
     */
    Thread getImageThread = new Thread(new Runnable(){
        @Override
        public void run() {
            try {
                //get profile picture
                InputStream is = (InputStream) new URL(picUrl).getContent();
                Drawable d = Drawable.createFromStream(is, picUrl);

                profilePic.setImageDrawable(d);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    });


    private void updateText(EditText field, String newValue) {
        if (!newValue.equalsIgnoreCase(UNDEFINED))
            field.setText(newValue);
    }

    private String toText(EditText editText) {
        return editText.getText().toString();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
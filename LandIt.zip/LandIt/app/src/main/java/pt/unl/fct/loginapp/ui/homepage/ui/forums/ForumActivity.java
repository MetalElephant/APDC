package pt.unl.fct.loginapp.ui.homepage.ui.forums;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.forum.model.ForumInfo;
import pt.unl.fct.loginapp.data.forum.model.MessageInfo;
import pt.unl.fct.loginapp.databinding.ActivityForumBinding;
import pt.unl.fct.loginapp.databinding.ActivityParcelInfoBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo.ParcelsFragment;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class ForumActivity extends AppCompatActivity {

    private ActivityForumBinding binding;
    private ForumViewModel forumViewModel;
    private AuxMethods aux = new AuxMethods();
    private ArrayAdapter<String> arrayAdapter;
    private ListView list;
    private LinearLayout loadingLayout;
    ArrayList<MessageInfo> elems;
    ArrayList<String> toDisplay;
    private String username;
    private String role;
    ForumInfo thisForum;
    private static final int MAX_MSG_CHARS = 600;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityForumBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        forumViewModel =
                new ViewModelProvider(this, new ForumViewModelFactory()).get(ForumViewModel.class);

        FloatingActionButton sendBtn = binding.fabMessage;
        EditText messageEditText = binding.inputMessage;
        loadingLayout = binding.layoutLoading;
        TextView noMsgText = binding.textNoMessages;
        //make entire text clickable, otherwise you can't go back in a message
        messageEditText.setSelection(0, messageEditText.getText().length());
        Button deleteForumBtn = binding.deleteForumBtn;
        list = binding.listOfMessages;
        elems = new ArrayList<>();
        toDisplay = new ArrayList<>();

        role = aux.loadRole(getApplicationContext());
        username = aux.loadUsername(getApplicationContext());
        thisForum = (ForumInfo)getIntent().getSerializableExtra(getString(R.string.forumName));


        if(Roles.isModOrSU(role)){
            deleteForumBtn.setVisibility(View.VISIBLE);
        }

        deleteForumBtn.setOnClickListener(view -> {
            forumViewModel.removeForum(username,thisForum.getOwner(), thisForum.getName());

        });

        //load messages
        forumViewModel.listMessages(thisForum.getOwner(),thisForum.getName());

        //observer
        forumViewModel.getForumResult().observe(this, forumResult -> {
            loadingLayout.setVisibility(View.GONE);
            if(forumResult == null)
                return;

            if(forumResult.getError()!= null){
                aux.makeToast(forumResult.getError(),getApplicationContext());
            }

            if(forumResult.getSuccess() != null){//deleted or sent message
                Intent intent = new Intent(this, ForumActivity.class);
                elems.clear();
                toDisplay.clear();

                forumViewModel.listMessages(thisForum.getOwner(),thisForum.getName());


            }

            if(forumResult.getSuccessM() != null){//list of messages
                if(elems.isEmpty())
                    loadUserMessages(forumResult);

                //set the listView with elements loaded
                if(elems.isEmpty() && toDisplay.isEmpty()){
                    noMsgText.setVisibility(View.VISIBLE);
                }
                else {
                    noMsgText.setVisibility(View.GONE);
                    setListView();
                }
            }

        });

/*        forumViewModel.getMessageResult().observe(this, forumResult -> {
            loadingLayout.setVisibility(View.GONE);
            if(forumResult == null)
                return;

            if(forumResult.getError()!= null){
                aux.makeToast(forumResult.getError(),getApplicationContext());
            }

            if(forumResult.getSuccess() != null){//deleted message
                Intent intent = new Intent(this, ForumActivity.class);
                intent.putExtra(getString(R.string.forumName), thisForum);
                startActivity(intent);
                finish();

            }
        });*/

        sendBtn.setOnClickListener(view -> {
            String msg = messageEditText.getText().toString();
            String[] expletives = getResources().getStringArray(R.array.bad_words);
            if(msg.equals("")){
                messageEditText.setError(getText(R.string.messageErrorNoMsg));
            }
            else if(aux.stringContainsStringsFromArray(msg.toLowerCase(), expletives)){
                messageEditText.setError(getText(R.string.messageErrorBadWord));
            }else if(msg.length() > MAX_MSG_CHARS){
                messageEditText.setError(getString(R.string.messageErrorLong));
            }
            else{
                loadingLayout.setVisibility(View.VISIBLE);
                forumViewModel.registerMessage(username,thisForum.getOwner(),thisForum.getName(),
                        msg);
            }
        });



    }

    private void loadUserMessages(ForumResult forumResult) {
        ForumResultListMsgView infoView = forumResult.getSuccessM();
        List<MessageInfo> listM = infoView.getMessages();

        for (MessageInfo msg: listM) {
            elems.add(msg);
            toDisplay.add(msg.toString());
        }

    }

    private ListView initTable(){
        ArrayAdapter arrayAdapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, elems);

        list.setAdapter(arrayAdapter);
        list.setClickable(true);


        arrayAdapter.notifyDataSetChanged();

        return list;

    }


    private void setListView() {
        ListView list = initTable();

        list.setOnItemClickListener((adapterView, view, i, l) -> {

            //if WE wrote the message or we're mods
            if(elems.get(i).getOwner().equals(username) || Roles.isModOrSU(role)) {

                AlertDialog alertDialog = aux.initAlert(ForumActivity.this,
                        R.string.deleteMsg, R.string.deleteMsgWarning);
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes),
                        (dialogInterface, j) -> {
                            forumViewModel.removeMessage(username, thisForum.getOwner(),
                                    thisForum.getName(), elems.get(i).getMessage(),elems.get(i).getOwner());
                            //todo reload forum messages again
                            Intent intent = new Intent(this, ForumActivity.class);
                            intent.putExtra(getString(R.string.forumName), thisForum);
                            startActivity(intent);
                            finish();
                        });
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no),
                        (dialogInterface, j) -> {
                        });
                alertDialog.show();
            }


        });

    }

}
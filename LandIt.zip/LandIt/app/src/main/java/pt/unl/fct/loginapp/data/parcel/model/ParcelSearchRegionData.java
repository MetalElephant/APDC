package pt.unl.fct.loginapp.data.parcel.model;

public class ParcelSearchRegionData {
    public int type; // 1 county, 2 district, 3 freguesia
    public String username, region;

    public ParcelSearchRegionData(){}

    public ParcelSearchRegionData(String username, String region, int type){
        this.username = username;
        this.region = region;
        this.type = type;
    }
}

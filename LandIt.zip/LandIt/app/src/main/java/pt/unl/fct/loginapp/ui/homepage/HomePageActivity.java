package pt.unl.fct.loginapp.ui.homepage;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;


import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.ActivityHomePageBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.home.HomeFragmentDirections;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.ui.homepage.ui.settings.SettingsActivity;
import pt.unl.fct.loginapp.ui.initial.InitialActivity;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModel;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class HomePageActivity extends AppCompatActivity  {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityHomePageBinding binding;
    private UserViewModel userViewModel;
    private ParcelViewModel parcelViewModel;
    private DrawerLayout drawer;
    private String username;
    private Menu navMenu;
    private AuxMethods aux = new AuxMethods();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityHomePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userViewModel = new ViewModelProvider(this, new UserViewModelFactory())
                .get(UserViewModel.class);
        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);


        setSupportActionBar(binding.appBarMain.toolbar);
        drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_parcels, R.id.nav_forum)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);


        //region roleHandling
        navMenu = navigationView.getMenu();

        //TODO: get role here
        String role = aux.loadRole(getApplicationContext());

        switch (Roles.valueOf(role)){
            case PROPRIETARIO:
                disableMenuItem(R.id.nav_other_users);
                break;
            case COMERCIANTE:
                disableMenuItem(R.id.nav_home);
                disableMenuItem(R.id.nav_forum);
                disableMenuItem(R.id.nav_parcels);
                navController.setGraph(R.navigation.mobile_navigation_merchant);
                disableMenuItem(R.id.nav_other_users);
                break;
            case REPRESENTANTE:
                navController.setGraph(R.navigation.mobile_navigation_alt);
                disableMenuItem(R.id.nav_home);
                navMenu.findItem(R.id.nav_parcels).setTitle(R.string.menuParcelsV2);
                disableMenuItem(R.id.nav_forum);
                disableMenuItem(R.id.nav_rewards_V1);
                disableMenuItem(R.id.nav_other_users);
                break;
            case MODERADOR:
            case SUPERUSER:
                navController.setGraph(R.navigation.mobile_navigation_alt);
                disableMenuItem(R.id.nav_home);
                break;
            default:aux.makeToast(R.string.default_error_msg,getApplicationContext());

        }

        //endregion


        //region parcel and logout handling
        //Button that shows/hides parcels of that user
        username = aux.loadLoggedInUserElem(getString(R.string.username), getApplicationContext());


        //listener for showing the parcels
        parcelViewModel.getParcelResult().observe(this, new Observer<ParcelResult>() {
            @Override
            public void onChanged(@Nullable ParcelResult parcelResult) {
                if(parcelResult == null){
                    return;
                }

                if(parcelResult.getError() != null) {
                    Toast.makeText(HomePageActivity.this, R.string.noParcels, Toast.LENGTH_SHORT).show();
                }
                if(parcelResult.getSuccessP() != null){
                    ParcelInfoView a = parcelResult.getSuccessP();
                    List<ParcelInfo> b = a.getParcels();
                }
            }
        });


        //handle clicking certain buttons. In this case, handling the logout and delete account buttons on the drawer
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.nav_logoutClick) {
                    userViewModel.logout(username);
                    return true;
                }
                NavigationUI.onNavDestinationSelected(item, navController);
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });


        //listener for logout
        userViewModel.getLogoutResult().observe(this, logoutResult -> {
            if (logoutResult == null) {
                return;
            }
            //loadingProgressBar.setVisibility(View.GONE);
            if (logoutResult.getError() != null) {
                showLogoutFailed(logoutResult.getError());
            }
            if (logoutResult.getSuccess() != null) { //where we change the page being shown

                sayGoodbyeMessage();
                //Intent changeAct = new Intent(getApplicationContext(), InitialActivity.class);
                //startActivity(changeAct);
                //Complete and destroy login activity once successful
                finish();
            }
        });

        //endregion

        setNavigationDrawerUserInfo(navigationView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.welcome, menu);

        return true;
    }

    /**
     * Deal with clicking certain items, in this case settings option in the navigator
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_settings:
                Intent changeAct = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(changeAct);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    //-------------------------------AUX--------------------------------------------------//

    /**
     * Set the user info (username and role) in the upper bar of the navigation drawer
     */
    private void setNavigationDrawerUserInfo(NavigationView navigationView) {
        View headerView = navigationView.getHeaderView(0);
        TextView usernameTextView = headerView.findViewById(R.id.homePageProfileName);

        TextView userRoleTextView = headerView.findViewById(R.id.homePageProfileRole);
        //String userRole = loadLoggedInUserElem("role");

        String text = getString(R.string.hello) + " "+username;
        usernameTextView.setText(text);
        userRoleTextView.setText(getString(R.string.welcomeMessage));
    }


    private void sayGoodbyeMessage() {
        aux.makeToast(R.string.goodbye, getApplicationContext());
    }

    private void showLogoutFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

    private void disableMenuItem(@IdRes Integer item){
        navMenu.findItem(item).setVisible(false);

    }


}
package pt.unl.fct.loginapp.ui.homepage;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;


import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.ActivityHomePageBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.gallery.GalleryFragment;
import pt.unl.fct.loginapp.ui.homepage.ui.home.HomeFragment;
import pt.unl.fct.loginapp.ui.homepage.ui.home.HomeFragmentDirections;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.ui.homepage.ui.settings.SettingsActivity;
import pt.unl.fct.loginapp.ui.homepage.ui.slideshow.SlideshowFragment;
import pt.unl.fct.loginapp.ui.initial.InitialActivity;
import pt.unl.fct.loginapp.ui.initial.users.LoginActivity;
import pt.unl.fct.loginapp.ui.initial.users.LoginViewModel;
import pt.unl.fct.loginapp.ui.initial.users.LoginViewModelFactory;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;

public class HomePageActivity extends AppCompatActivity  {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityHomePageBinding binding;
    private LoginViewModel loginViewModel;
    private ParcelViewModel parcelViewModel;
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityHomePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        loginViewModel = new ViewModelProvider(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);
        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);

        setSupportActionBar(binding.appBarMain.toolbar);
        drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        //Button that shows/hides parcels of that user
        final String username = loadLoggedInUserElem("username");
        binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //do the rest call to show all users' parcels
                parcelViewModel.showParcels(username);
                //Snackbar.make(view, "TBD", Snackbar.LENGTH_LONG)
                  //      .setAction("Action", null).show();
            }
        });


        //handle clicking certain buttons. In this case, handling the logout button on the drawer
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.nav_logoutClick) {
                    String userToLogout = loadLoggedInUserElem("username");
                    loginViewModel.logout(userToLogout);
                    return true;
                }
                NavigationUI.onNavDestinationSelected(item, navController);
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        //listener for showing the parcels
        parcelViewModel.getParcelResult().observe(this, new Observer<ParcelResult>() {
            @Override
            public void onChanged(@Nullable ParcelResult parcelResult) {
                if(parcelResult == null){
                    return;
                }

                if(parcelResult.getError() != null) {
                    Toast.makeText(HomePageActivity.this, "No can do", Toast.LENGTH_SHORT).show();
                }
                if(parcelResult.getSuccessP() != null){
                    Toast.makeText(HomePageActivity.this, "make things show up", Toast.LENGTH_SHORT).show();
                    ParcelInfoView a = parcelResult.getSuccessP();
                    List<ParcelInfo> b = a.getParcels();
                    //String example = b.get(0).description;
                    Toast.makeText(HomePageActivity.this, "mmm", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //listener for logout
        loginViewModel.getLogoutResult().observe(this, new Observer<LogoutResult>() {
            @Override
            public void onChanged(@Nullable LogoutResult logoutResult) {
                if (logoutResult == null) {
                    return;
                }
                //loadingProgressBar.setVisibility(View.GONE);
                if (logoutResult.getError() != null) {
                    showLogoutFailed(logoutResult.getError());
                }
                if (logoutResult.getSuccess() != null) { //where we change the page being shown

                    sayGoodbyeMessage();
                    Intent changeAct = new Intent(getApplicationContext(), InitialActivity.class);
                    startActivity(changeAct);
                    //Complete and destroy login activity once successful
                    finish();
                }
            }
        });

        setNavigationDrawerUserInfo(navigationView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.welcome, menu);

        return true;
    }

    /**
     * Deal with clicking certain items, in this case settings option in the navigator
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_settings:
                Intent changeAct = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(changeAct);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    //-------------------------------AUX--------------------------------------------------//

    /**
     * Set the user info (username and role) in the upper bar of the navigation drawer
     */
    private void setNavigationDrawerUserInfo(NavigationView navigationView) {
        View headerView = navigationView.getHeaderView(0);
        TextView usernameTextView = headerView.findViewById(R.id.homePageProfileName);
        String username =loadLoggedInUserElem("username");

        TextView userRoleTextView = headerView.findViewById(R.id.homePageProfileRole);
        String userRole = loadLoggedInUserElem("role");

        usernameTextView.setText("Hello, "+ username);
        userRoleTextView.setText("User Role: "+userRole);
    }

    public String loadLoggedInUserElem(String parameter) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String userParam = sharedPreferences.getString(parameter, "");
        return userParam;

    }

    private void sayGoodbyeMessage() {
        String loggedUser = loadLoggedInUserElem("username");
        Toast.makeText(getApplicationContext(), "Goodbye, "+ loggedUser,Toast.LENGTH_SHORT).show();
    }

    private void showLogoutFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

}
package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import pt.unl.fct.loginapp.LandIt;
import pt.unl.fct.loginapp.data.rewards.RewardDataSource;
import pt.unl.fct.loginapp.data.rewards.RewardRepository;

public class RewardViewModelFactory implements ViewModelProvider.Factory {

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(RewardViewModel.class)) {
            return (T) new RewardViewModel(RewardRepository.getInstance(new RewardDataSource(), LandIt.getExecutorService()));
        } else {
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }
}

package pt.unl.fct.loginapp.ui.homepage.ui.forums;

public class ForumResultView {
    public ForumResultView(){}
}

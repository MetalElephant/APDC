package pt.unl.fct.loginapp.ui.homepage.ui.profile;

import androidx.lifecycle.ViewModel;

public class ModifyPasswordViewModel extends ViewModel {

    public ModifyPasswordViewModel(){

    }
}
package pt.unl.fct.loginapp.data.rewards;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;
import java.util.concurrent.Executor;

import pt.unl.fct.loginapp.data.RestAPI;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.rewards.model.RegisteredReward;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;
import pt.unl.fct.loginapp.data.users.RegisterRepositoryCallback;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RewardRepository {
    private static volatile RewardRepository instance;

    private RewardDataSource dataSource;
    private Executor executor;

    // If user credentials will be cached in local storage, it is recommended it be encrypted
    // @see https://developer.android.com/training/articles/keystore
    private RegisteredReward reward = null;

    // private constructor : singleton access
    private RewardRepository(RewardDataSource dataSource, Executor executor) {
        this.dataSource = dataSource;
        this.executor = executor;
    }

    public static RewardRepository getInstance(RewardDataSource dataSource, Executor executor) {
        if (instance == null) {
            instance = new RewardRepository(dataSource,executor);
        }
        return instance;
    }

    public void registerReward(String name, String description, String owner, String price, RegisterRepositoryCallback<RegisteredReward> callback) {
        // handle login in a separate thread
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // go to dataSource and do the REST services
                Result<RegisteredReward> result = dataSource.registerReward(name, description, owner, price);
                callback.onComplete(result);
            }
        });
    }

    public void removeReward(String username, String owner, String rewardName,
                             RewardRepositoryCallback<RegisteredReward> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<RegisteredReward> result = dataSource.removeReward(username, owner, rewardName);
                callback.onComplete(result);
            }
        });
    }

    public void redeemReward(String username, String owner, String rewardName,
                             RewardRepositoryCallback<RegisteredReward> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<RegisteredReward> result = dataSource.doRedeem(username, owner, rewardName);
                callback.onComplete(result);
            }
        });
    }

    public void listRewards(String username, RewardRepositoryCallback<List<RewardData>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<List<RewardData>> result = dataSource.listRewards(username);
                callback.onComplete(result);
            }
        });
    }

    public void listAllRewards(RewardRepositoryCallback<List<RewardData>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<List<RewardData>> result = dataSource.listAllRewards();
                callback.onComplete(result);
            }
        });
    }

    public void listRedeemable(String username, RewardRepositoryCallback<List<RewardData>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<List<RewardData>> result = dataSource.listRedeemable(username);
                callback.onComplete(result);
            }
        });
    }

    public void listRedeemed(String username, RewardRepositoryCallback<List<RewardData>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<List<RewardData>> result = dataSource.listRedeemed(username);
                callback.onComplete(result);
            }
        });
    }

    //ops
}

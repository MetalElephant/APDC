package pt.unl.fct.loginapp.data.forum;

import java.util.List;
import java.util.concurrent.Executor;

import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.forum.model.ForumInfo;
import pt.unl.fct.loginapp.data.forum.model.MessageInfo;
import pt.unl.fct.loginapp.data.forum.model.RegisteredForum;


public class ForumRepository {
    private static volatile ForumRepository instance;

    private ForumDataSource dataSource;
    private Executor executor;

    private RegisteredForum forum = null;

    // private constructor : singleton access
    private ForumRepository(ForumDataSource dataSource, Executor executor) {
        this.dataSource = dataSource;
        this.executor = executor;
    }

    public static ForumRepository getInstance(ForumDataSource dataSource, Executor executor) {
        if (instance == null) {
            instance = new ForumRepository(dataSource,executor);
        }
        return instance;
    }

    public void registerForum(String username, String forumName, String topic,
                              ForumRepositoryCallback<RegisteredForum> callback) {
        // handle login in a separate thread
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // go to dataSource and do the REST services
                Result<RegisteredForum> result = dataSource.registerForum(
                        username, forumName, topic);
                if (result instanceof Result.Success) {
                }
                callback.onComplete(result);
            }
        });
    }

    public void registerMessage(String username, String owner, String forum, String msg,
                                ForumRepositoryCallback<RegisteredForum> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<RegisteredForum> result = dataSource.registerMessage(username, owner, forum, msg);

                callback.onComplete(result);
            }
        });
    }

    public void removeForum(String username, String owner, String fName,
                            ForumRepositoryCallback<RegisteredForum> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<RegisteredForum> result = dataSource.removeForum(username, owner, fName);

                callback.onComplete(result);
            }
        });
    }

    public void removeMessage(String username, String forumOwner, String forumName, String msg,
                              String msgOwner, ForumRepositoryCallback<RegisteredForum> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<RegisteredForum> result = dataSource.removeMessage(username, forumOwner,
                        forumName, msg, msgOwner);

                callback.onComplete(result);
            }
        });
    }

    public void listForums(String username, ForumRepositoryCallback<List<ForumInfo>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result <List<ForumInfo>> result = dataSource.listForums(username);

                callback.onComplete(result);
            }
        });
    }

    public void listAllForums(ForumRepositoryCallback<List<ForumInfo>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result <List<ForumInfo>> result = dataSource.listAllForums();

                callback.onComplete(result);
            }
        });
    }

    public void listMessages(String username, String fName,
                             ForumRepositoryCallback<List<MessageInfo>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<List<MessageInfo>> result = dataSource.listMessages(username,fName);
                callback.onComplete(result);
            }
        });
    }

}

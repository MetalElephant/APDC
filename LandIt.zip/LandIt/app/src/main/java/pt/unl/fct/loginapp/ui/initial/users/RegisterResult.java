package pt.unl.fct.loginapp.ui.initial.users;

import androidx.annotation.Nullable;

public class RegisterResult {

    @Nullable
    private pt.unl.fct.loginapp.ui.initial.users.RegisteredUserView success;
    @Nullable
    private Integer error;

    RegisterResult(@Nullable Integer error) {
        this.error = error;
    }

    RegisterResult(@Nullable pt.unl.fct.loginapp.ui.initial.users.RegisteredUserView success) {
        this.success = success;
    }

    @Nullable
    pt.unl.fct.loginapp.ui.initial.users.RegisteredUserView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}

package pt.unl.fct.loginapp.data.users.model.updateInfo;

public class UserUpdateData {

    public String username, usernameToUpdate;

    public String email, name, homePhone, mobilePhone, street, nif, district, county, autarchy;

    public UserUpdateData(String username, String usernameToUpdate, String name,  String email,
                          String district, String county, String autarchy,String street,
                          String homePhone,String mobilePhone, String nif) {
        this.username = username;
        this.usernameToUpdate = usernameToUpdate;
        this.name = name;
        this.email = email;
        this.street = street;
        this.district = district;
        this.county = county;
        this.autarchy = autarchy;
        this.homePhone = homePhone;
        this.mobilePhone = mobilePhone;
        this.nif = nif;
    }
}

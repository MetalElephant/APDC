package pt.unl.fct.loginapp.data.parcel.model;

public class ParcelVerifyData {
    public String username, owner, parcelName, reason;
    public boolean confirmation;

    public ParcelVerifyData() {}

    public ParcelVerifyData(String username, String owner, String parcelName,String reason, boolean confirmation) {
        this.username = username;
        this.owner = owner;
        this.reason = reason;
        this.confirmation = confirmation;
        this.parcelName = parcelName;
    }
}

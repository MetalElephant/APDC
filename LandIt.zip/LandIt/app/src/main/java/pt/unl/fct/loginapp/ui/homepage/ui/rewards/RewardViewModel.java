package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.rewards.RewardRepository;
import pt.unl.fct.loginapp.data.rewards.RewardRepositoryCallback;
import pt.unl.fct.loginapp.data.rewards.model.RegisteredReward;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;
import pt.unl.fct.loginapp.data.users.RegisterRepositoryCallback;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelUpdateFormState;

public class RewardViewModel extends ViewModel {

    private MutableLiveData<RegisterRewardFormState> registerRewardFormState = new MutableLiveData<>();
    private MutableLiveData<RewardResult> rewardResult = new MutableLiveData<>();

    private MutableLiveData<RewardResult> deleteResult = new MutableLiveData<>();

    private MutableLiveData<RewardResult> redeemResult = new MutableLiveData<>();

    private MutableLiveData<RewardResult> rewardRedeemedResult = new MutableLiveData<>();

    private RewardRepository rewardRepository;

    public RewardViewModel(){}

    public RewardViewModel(RewardRepository rewardRepository) {
        this.rewardRepository = rewardRepository;
    }

    //region register
    public MutableLiveData<RewardResult> getRewardResult() { return rewardResult; }
    public MutableLiveData<RewardResult> getRedeemResult() { return redeemResult; }
    public MutableLiveData<RewardResult> getRemoveResult() { return deleteResult; }
    public MutableLiveData<RewardResult> getRedeemedResult() { return rewardRedeemedResult; }


    public MutableLiveData<RegisterRewardFormState> getRegisterDataChanged(){return registerRewardFormState;}

    public void registerDataChanged(String rName, String description, String price){
        if (!isParameterValid(rName)) {
            registerRewardFormState.setValue(
                    new RegisterRewardFormState(R.string.invalidName, null, null));
        }else if (!isParameterValid(description)) {
            registerRewardFormState.setValue(
                    new RegisterRewardFormState(null, R.string.invalidParcelDescription, null));
        } else if (!isPriceValid(price)) {
            registerRewardFormState.setValue(
                    new RegisterRewardFormState(null, null, R.string.invalidPrice));
        } else {
            registerRewardFormState.setValue(
                    new RegisterRewardFormState(true));
        }

    }

    public void register(String name, String description, String owner,  String price) {
        rewardRepository.registerReward(name, description, owner, price,
                new RegisterRepositoryCallback<RegisteredReward>() {

                    @Override
                    public void onComplete(Result<RegisteredReward> result) {
                        if (result instanceof Result.Success) {
                            rewardResult.postValue(new RewardResult(new RewardResultView()));
                        } else if (result.isCode("409")) { //should never reach this
                            rewardResult.postValue(new RewardResult(R.string.registerBadRequest));
                        } else {
                            rewardResult.postValue(new RewardResult(R.string.defaultError));
                        }
                    }
                });

    }


    //endregion

    public void removeReward(String owner, String username, String rewardName){
        rewardRepository.removeReward(username, owner, rewardName,
                new RewardRepositoryCallback<RegisteredReward>() {
                    @Override
                    public void onComplete(Result<RegisteredReward> result) {
                        if (result instanceof Result.Success) {
                            deleteResult.postValue(new RewardResult(new RewardResultView()));
                        } else{
                            deleteResult.postValue(new RewardResult(R.string.defaultError));
                        }
                    }
                });
    }

    public void redeemRewards(String owner, String username, String rewardName){
        rewardRepository.redeemReward(username, owner, rewardName,
                new RewardRepositoryCallback<RegisteredReward>() {
                    @Override
                    public void onComplete(Result<RegisteredReward> result) {
                        if (result instanceof Result.Success) {
                            redeemResult.postValue(new RewardResult(new RewardResultView()));
                        } else if(result.isCode("400")){
                            redeemResult.postValue(new RewardResult(R.string.notEnoughPoints));
                        }
                        else{
                            redeemResult.postValue(new RewardResult(R.string.defaultError));
                        }
                    }
                });
    }

    public void listRewards(String username){
        rewardRepository.listRewards(username, new RewardRepositoryCallback<List<RewardData>>() {
            @Override
            public void onComplete(Result<List<RewardData>> result) {
                if (result instanceof Result.Success) {
                    List<RewardData> data = ((Result.Success<List<RewardData>>) result).getData();

                    rewardResult.postValue(new RewardResult(new RewardListView( data )));
                } else{
                    rewardResult.postValue(new RewardResult(R.string.defaultError));
                }
            }
        });
    }

    public void listAllRewards(){
        rewardRepository.listAllRewards(new RewardRepositoryCallback<List<RewardData>>() {
            @Override
            public void onComplete(Result<List<RewardData>> result) {
                if (result instanceof Result.Success) {
                    List<RewardData> data = ((Result.Success<List<RewardData>>) result).getData();

                    rewardResult.postValue(new RewardResult(new RewardListView( data )));
                } else{
                    rewardResult.postValue(new RewardResult(R.string.defaultError));
                }
            }
        });
    }

    public void listRedeemable(String username){
        rewardRepository.listRedeemable(username, new RewardRepositoryCallback<List<RewardData>>() {
            @Override
            public void onComplete(Result<List<RewardData>> result) {
                if (result instanceof Result.Success) {
                    List<RewardData> data = ((Result.Success<List<RewardData>>) result).getData();

                    rewardResult.postValue(new RewardResult(new RewardListView( data )));
                } else{
                    rewardResult.postValue(new RewardResult(R.string.defaultError));
                }
            }
        });
    }

    public void listRedeemed(String username){
        rewardRepository.listRedeemed(username, new RewardRepositoryCallback<List<RewardData>>() {
            @Override
            public void onComplete(Result<List<RewardData>> result) {
                if (result instanceof Result.Success) {
                    List<RewardData> data = ((Result.Success<List<RewardData>>) result).getData();

                    rewardRedeemedResult.postValue(new RewardResult(new RewardListView( data )));
                } else{
                    rewardRedeemedResult.postValue(new RewardResult(R.string.defaultError));
                }
            }
        });
    }
    private boolean isParameterValid(String parameter){
        return parameter != null && !parameter.trim().isEmpty();
    }

    private boolean isPriceValid(String price){
        return isParameterValid(price) && price.matches("[0-9]+");
    }



}


package pt.unl.fct.loginapp.ui.homepage.ui.profile;

import java.util.List;

import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;

public class UserInfoListView {

    public List<UserInfo> infos;

    public UserInfoListView(List<UserInfo> userInfos){this.infos = userInfos;}

    public List<UserInfo> getUsers() {
        return infos;
    }
}

package pt.unl.fct.loginapp.ui.homepage.ui.forums;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.forum.ForumRepository;
import pt.unl.fct.loginapp.data.forum.ForumRepositoryCallback;
import pt.unl.fct.loginapp.data.forum.model.ForumInfo;
import pt.unl.fct.loginapp.data.forum.model.MessageInfo;
import pt.unl.fct.loginapp.data.forum.model.RegisteredForum;
import pt.unl.fct.loginapp.data.rewards.model.RegisteredReward;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;
import pt.unl.fct.loginapp.ui.homepage.ui.rewards.RewardListView;
import pt.unl.fct.loginapp.ui.homepage.ui.rewards.RewardResult;

public class ForumViewModel extends ViewModel {

    private ForumRepository forumRepository;

    public ForumViewModel(){}

    public ForumViewModel(ForumRepository forumRepository) {
        this.forumRepository = forumRepository;
    }

    private MutableLiveData<RegisterForumFormState> registerForumFormState = new MutableLiveData<>();
    private MutableLiveData<ForumResult> forumResult = new MutableLiveData<>();
    private MutableLiveData<ForumResult> messageResult = new MutableLiveData<>();


    public MutableLiveData<ForumResult> getForumResult() { return forumResult; }

    public MutableLiveData<ForumResult> getMessageResult() {
        return messageResult;
    }

    public MutableLiveData<RegisterForumFormState> getRegisterDataChanged(){return registerForumFormState;}

    public void registerDataChanged(String fName, String topic){
        if (!isParameterValid(fName)) {
            registerForumFormState.setValue(
                    new RegisterForumFormState(R.string.invalidName, null));
        }else if (!isParameterValid(topic)) {
            registerForumFormState.setValue(
                    new RegisterForumFormState(null, R.string.invalidTopic));
        } else {
            registerForumFormState.setValue(
                    new RegisterForumFormState(true));
        }

    }

    public void registerForum(String username, String fName, String topic) {
        forumRepository.registerForum(username,fName,topic,
            new ForumRepositoryCallback<RegisteredForum>() {

                @Override
                public void onComplete(Result<RegisteredForum> result) {
                    if (result instanceof Result.Success) {
                        RegisteredReward data = ((Result.Success<RegisteredReward>) result).getData();
                        forumResult.postValue(new ForumResult(new ForumResultView()));
                    } else if (result.isCode("409")) {
                        forumResult.postValue(new ForumResult(R.string.registerForumConflict));
                    } else {
                        forumResult.postValue(new ForumResult(R.string.defaultError));
                    }
                }
            });
    }

    public void registerMessage(String username, String owner, String forum, String msg) {
        forumRepository.registerMessage(username, owner, forum, msg,
                new ForumRepositoryCallback<RegisteredForum>() {
                    @Override
                    public void onComplete(Result<RegisteredForum> result) {
                        if (result instanceof Result.Success) {
                            forumResult.postValue(new ForumResult(new ForumResultView()));
                        } else {
                            forumResult.postValue(new ForumResult(R.string.defaultError));
                        }
                    }
                });
    }

    public void removeForum(String username, String owner, String fName){
        forumRepository.removeForum(username, owner, fName, new ForumRepositoryCallback<RegisteredForum>() {
            @Override
            public void onComplete(Result<RegisteredForum> result) {
                postValues(result);
            }
        });
    }

    public void removeMessage(String username, String forumOwner, String forumName, String msg,
                              String msgOwner){
        forumRepository.removeMessage(username, forumOwner, forumName, msg, msgOwner,
                new ForumRepositoryCallback<RegisteredForum>() {
            @Override
            public void onComplete(Result<RegisteredForum> result) {
                postValues(result);
            }
        });
    }

    public void listForums(String username){
        forumRepository.listForums(username, new ForumRepositoryCallback<List<ForumInfo>>() {
            @Override
            public void onComplete(Result<List<ForumInfo>> result) {
                if (result instanceof Result.Success) {
                    List<ForumInfo> data = ((Result.Success<List<ForumInfo>>) result).getData();

                    forumResult.postValue(new ForumResult(new ForumResultListView( data )));
                } else{
                    forumResult.postValue(new ForumResult(R.string.defaultError));
                }
            }
        });
    }

    public void listAllForums(){
        forumRepository.listAllForums( new ForumRepositoryCallback<List<ForumInfo>>() {
            @Override
            public void onComplete(Result<List<ForumInfo>> result) {
                if (result instanceof Result.Success) {
                    List<ForumInfo> data = ((Result.Success<List<ForumInfo>>) result).getData();

                    forumResult.postValue(new ForumResult(new ForumResultListView( data )));
                } else{
                    forumResult.postValue(new ForumResult(R.string.defaultError));
                }
            }
        });
    }

    public void listMessages(String username, String fName){
        forumRepository.listMessages(username, fName, new ForumRepositoryCallback<List<MessageInfo>>() {
            @Override
            public void onComplete(Result<List<MessageInfo>> result) {
                if(result instanceof Result.Success){
                    List<MessageInfo> data = ((Result.Success<List<MessageInfo>>) result).getData();

                    forumResult.postValue(new ForumResult(new ForumResultListMsgView(data)));
                } else {
                    forumResult.postValue(new ForumResult(R.string.defaultError));
                }
            }
        });
    }

    private void postValues(Result<RegisteredForum> result){
        if (result instanceof Result.Success) {
            forumResult.postValue(new ForumResult(new ForumResultView()));
        } else {
            forumResult.postValue(new ForumResult(R.string.defaultError));
        }
    }

    private boolean isParameterValid(String parameter){
        return parameter != null && !parameter.trim().isEmpty();
    }

}
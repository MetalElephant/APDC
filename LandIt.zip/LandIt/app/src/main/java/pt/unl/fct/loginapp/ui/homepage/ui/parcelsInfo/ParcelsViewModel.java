package pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ParcelsViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public ParcelsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is parcels fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
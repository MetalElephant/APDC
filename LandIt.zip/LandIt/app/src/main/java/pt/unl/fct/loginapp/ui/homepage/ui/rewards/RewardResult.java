package pt.unl.fct.loginapp.ui.homepage.ui.rewards;

import androidx.annotation.Nullable;

public class RewardResult {

    @Nullable
    private RewardResultView success;
    @Nullable
    private RewardListView successR;
    @Nullable
    private Integer error;

    public RewardResult(@Nullable Integer error) {
        this.error = error;
    }

    public RewardResult(@Nullable RewardResultView success) {
        this.success = success;
    }

    public RewardResult(@Nullable RewardListView success) {this.successR = success;}

    @Nullable
    RewardResultView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }

    @Nullable
    public RewardListView getSuccessR() {
        return successR;
    }
}

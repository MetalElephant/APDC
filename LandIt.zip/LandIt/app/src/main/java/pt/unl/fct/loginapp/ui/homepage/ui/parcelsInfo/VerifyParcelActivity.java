package pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioGroup;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.ActivityParcelInfoBinding;
import pt.unl.fct.loginapp.databinding.ActivityVerifyParcelBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class VerifyParcelActivity extends AppCompatActivity {

    private ActivityVerifyParcelBinding binding;
    private ParcelViewModel parcelViewModel;
    private RadioGroup verifyRadioGroup;
    private EditText reasonEditText;
    private ProgressBar loadingVerify;
    private boolean confirmation;
    private AuxMethods aux = new AuxMethods();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityVerifyParcelBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        parcelViewModel = new ViewModelProvider(this, new ParcelViewModelFactory())
                .get(ParcelViewModel.class);


        Button verifyParcelBtn = binding.verifyParcelBtn;
        verifyRadioGroup = binding.radioGroupVerify;
        reasonEditText = binding.reasonEditText;
        loadingVerify =binding.loadingVerification;
        confirmation = true;
        Button docBtn = binding.seeDocumentButton;

        String owner = getIntent().getStringExtra(getString(R.string.user));
        String parcelName = getIntent().getStringExtra(getString(R.string.parcel));
        String confirmationLink = getIntent().getStringExtra(getString(R.string.verification));

        verifyRadioGroup.setOnCheckedChangeListener((radioGroup, checkedId) -> {
            switch(checkedId) {
                case R.id.radioButton_approve:
                    confirmation = true;
                    reasonEditText.setVisibility(View.GONE);
                    verifyParcelBtn.setEnabled(true);
                    break;
                case R.id.radioButton_reject:
                    confirmation = false;
                    reasonEditText.setVisibility(View.VISIBLE);
                    if(reasonEditText.getText().toString().equals(""))
                        verifyParcelBtn.setEnabled(false);
                    break;
                default:
                    break;
            }
        });

        TextWatcher tw = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(editable.toString().equals("")) {
                    reasonEditText.setError(getString(R.string.messageErrorNoMsg));
                    verifyParcelBtn.setEnabled(false);
                }
                else{
                    reasonEditText.setError(null);
                    verifyParcelBtn.setEnabled(true);
                }
            }
        };
        reasonEditText.addTextChangedListener(tw);

        //send verification
        verifyParcelBtn.setOnClickListener(view -> {
            loadingVerify.setVisibility(View.VISIBLE);
            parcelViewModel.verifyParcel(aux.loadUsername(getApplicationContext()), owner, parcelName,
                    reasonEditText.getText().toString(), confirmation);

        });

        //result observer
        parcelViewModel.getVerifyParcelResult().observe(this, parcelResult -> {

            loadingVerify.setVisibility(View.GONE);
            if(parcelResult == null){
                return;
            }

            if(parcelResult.getError() != null){
                aux.makeToast(R.string.defaultError,VerifyParcelActivity.this);
            }

            if(parcelResult.getSuccess() != null){
                aux.makeToast(R.string.parcelVerified, VerifyParcelActivity.this);
                finish();
            }
        });

        //document
        docBtn.setOnClickListener(view -> {
            aux.loadPdfDocument(VerifyParcelActivity.this, confirmationLink);
        });


    }

}
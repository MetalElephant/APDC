package pt.unl.fct.loginapp.data.users;

import java.util.List;
import java.util.concurrent.Executor;

import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;
import pt.unl.fct.loginapp.data.users.model.logout.LoggedOutUser;
import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;
import pt.unl.fct.loginapp.data.users.model.register.RegisteredUser;
import pt.unl.fct.loginapp.data.users.model.updatePwd.UpdatedPwdUser;
import pt.unl.fct.loginapp.util.AuxMethods;

/**
 * Class that requests authentication and user information from the remote data source and
 * maintains an in-memory cache of login status and user credentials information.
 */
public class UserRepository {

    private static volatile UserRepository instance;

    private UserDataSource dataSource;
    private Executor executor;
    private AuxMethods aux = new AuxMethods();

    // If user credentials will be cached in local storage, it is recommended it be encrypted
    // @see https://developer.android.com/training/articles/keystore
    private LoggedInUser user = null;

    // private constructor : singleton access
    private UserRepository(UserDataSource dataSource, Executor executor) {
        this.dataSource = dataSource;
        this.executor = executor;
    }

    public static UserRepository getInstance(UserDataSource dataSource, Executor executor) {
        if (instance == null) {
            instance = new UserRepository(dataSource,executor);
        }
        return instance;
    }

    public boolean isLoggedIn() {
        return user != null;
    }

    public void logout(String username, LogoutRepositoryCallback<LoggedOutUser> callback) {
        // handle login in a separate thread
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // go to dataSource and do the REST services
                Result<LoggedOutUser> result = dataSource.logout(username);
                if (result instanceof Result.Success) {
                    user = null;
                    // setLoggedInUser(((Result.Success<LoggedInUser>) result).getData());
                }
                callback.onComplete(result);
            }
        });
    }

    private void setLoggedInUser(LoggedInUser user) {
        this.user = user;
    }

    // Called by viewModel, so as to handle login and execute in separate thread
    public void login(String username, String password, LoginRepositoryCallback<LoggedInUser> callback) {
        // handle login in a separate thread
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // go to dataSource and do the REST services
                Result<LoggedInUser> result = dataSource.login(username, password);
                if (result instanceof Result.Success) {
                    setLoggedInUser(((Result.Success<LoggedInUser>) result).getData());
                }
                callback.onComplete(result);
            }
        });
    }

    public void register(String username, String password, String confirmation,
                         String email, String name, String role,
                         String district, String county, String municipality,
                         String street, String homePhone, String mobilePhone,
                         String nif, String code,byte[]photo, RegisterRepositoryCallback<RegisteredUser> callback) {
        // handle login in a separate thread
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // go to dataSource and do the REST services
                Result<RegisteredUser> result = dataSource.register(username, password, confirmation, email, name, role, district, county,
                        municipality, street, homePhone, mobilePhone, nif, code, photo);
                if (result instanceof Result.Success) {
                    //setRegisteredUser(((Result.Success<RegisteredUser>) result).getData());
                }
                callback.onComplete(result);
            }
        });
    }

    public void updatePwd(String username, String prevPwd, String newPwd, String pwdConfirmation,
                          UpdatePasswordRepositoryCallback<UpdatedPwdUser> callback) {
    executor.execute(new Runnable() {
        @Override
        public void run() {
            Result<UpdatedPwdUser> result = dataSource.updatePwd(username,prevPwd, newPwd, pwdConfirmation);
            if(result instanceof Result.Success){

            }
            callback.onComplete(result);
        }
    });
    }

    public void getUserInfo(String username, ProfileRepositoryCallback<UserInfo> callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<UserInfo> result = dataSource.getUserInfo(username);

                callback.onComplete(result);
            }
        });
    }

    public void updateUser(String username, String usernameToUpdate, String name,
                           String email, String district, String county,
                           String municipality, String street,String homePhone,
                           String mobilePhone, String nif,
                           RegisterRepositoryCallback<RegisteredUser> callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result<RegisteredUser> result = dataSource.updateUser(username,
                        usernameToUpdate, name, email, district, county,municipality, street,
                        homePhone, mobilePhone, nif);

                callback.onComplete(result);
            }
        });
    }

    public void listUsers(RegisterRepositoryCallback<List<UserInfo>> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result <List<UserInfo>> result = dataSource.listUsers();

                callback.onComplete(result);
            }
        });
    }

    public void removeUser(String username,String name, RegisterRepositoryCallback<RegisteredUser> callback){
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Result <RegisteredUser> result = dataSource.removeUser(username, name);

                callback.onComplete(result);
            }
        });
    }
}
package pt.unl.fct.loginapp.data.users.model.register;

public class RegisterData {
    //Mandatory information
    public String username, password, pwdConfirmation, email, name, role, district, county, autarchy;

    //Optional or default information
    public String homePhone, mobilePhone, street,  nif, code;

    public byte[] photo;

    private static final String UNDEFINED = "Não Definido";


    public RegisterData(String username, String password, String confirmation, String email, String name,
                        String role, String district, String county, String autarchy, String street,
                        String homePhone, String mobilePhone, String nif, String code, byte[] photo) {
        //Mandatory information
        this.username = username;
        this.password = password;
        this.pwdConfirmation = confirmation;
        this.email = email;
        this.name = name;
        this.role = role;
        this.district = district;
        this.county = county;
        this.autarchy = autarchy;

        //Optional information
        this.street = street;
        this.homePhone = homePhone;
        this.mobilePhone = mobilePhone;
        this.nif = nif;
        this.code = code;
        this.photo = photo;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

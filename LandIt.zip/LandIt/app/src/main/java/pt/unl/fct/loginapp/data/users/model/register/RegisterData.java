package pt.unl.fct.loginapp.data.users.model.register;

public class RegisterData {
    private String username;
    private String password;
    private String pwdConfirmation;
    private String email;
    private String name;
    private String visibility;
    private String homePhone;
    private String mobilePhone;
    private String address;
    private String nif;

    public RegisterData(String username, String password, String pwdConfirmation, String email, String name, String visibility, String homePhone, String mobilePhone, String address, String nif) {
        this.username = username;
        this.password = password;
        this.pwdConfirmation = pwdConfirmation;
        this.email = email;
        this.name = name;
        this.visibility = visibility;
        this.homePhone = homePhone;
        this.mobilePhone = mobilePhone;
        this.address = address;
        this.nif = nif;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

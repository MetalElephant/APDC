package pt.unl.fct.loginapp.ui.homepage.ui.forums;


import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import pt.unl.fct.loginapp.LandIt;
import pt.unl.fct.loginapp.data.forum.ForumDataSource;
import pt.unl.fct.loginapp.data.forum.ForumRepository;

public class ForumViewModelFactory implements ViewModelProvider.Factory {

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(ForumViewModel.class)) {
            return (T) new ForumViewModel(ForumRepository.getInstance(new ForumDataSource(), LandIt.getExecutorService()));
        } else {
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }
}

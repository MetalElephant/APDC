package pt.unl.fct.loginapp.ui.initial.users;

import androidx.annotation.Nullable;

public class UpdatePwdResult {

    @Nullable
    private UpdatePwdView success;
    @Nullable
    private Integer error;

    UpdatePwdResult(@Nullable Integer error) {
        this.error = error;
    }

    UpdatePwdResult(@Nullable UpdatePwdView success) {
        this.success = success;
    }

    @Nullable
    public UpdatePwdView getSuccess() {
        return success;
    }

    @Nullable
    public Integer getError() {
        return error;
    }
}

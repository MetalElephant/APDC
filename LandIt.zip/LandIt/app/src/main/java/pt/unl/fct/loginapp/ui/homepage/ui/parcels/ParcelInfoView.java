package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import com.google.android.gms.maps.model.LatLng;

import java.util.List;

import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;

public class ParcelInfoView {

    public List<ParcelInfo> markers;

    public ParcelInfoView(List<ParcelInfo> parcels){
        this.markers = parcels;
    }

    public List<ParcelInfo> getParcels() {
        return markers;
    }
}

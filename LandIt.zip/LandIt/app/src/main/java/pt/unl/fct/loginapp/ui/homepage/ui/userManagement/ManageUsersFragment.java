package pt.unl.fct.loginapp.ui.homepage.ui.userManagement;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.users.model.profileInfo.UserInfo;
import pt.unl.fct.loginapp.databinding.ManageUsersFragmentBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.home.HomeFragmentDirections;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo.ParcelInfoActivity;
import pt.unl.fct.loginapp.ui.homepage.ui.profile.ProfileFragment;
import pt.unl.fct.loginapp.ui.homepage.ui.profile.ProfileManagementActivity;
import pt.unl.fct.loginapp.ui.homepage.ui.profile.UserInfoListView;
import pt.unl.fct.loginapp.ui.homepage.ui.rewards.RewardViewModel;
import pt.unl.fct.loginapp.ui.initial.users.UserResult;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModel;
import pt.unl.fct.loginapp.ui.initial.users.UserViewModelFactory;
import pt.unl.fct.loginapp.util.AuxMethods;

public class ManageUsersFragment extends Fragment {

    private ManageUsersViewModel manageUsersViewModel;
    private UserViewModel userViewModel;
    private ManageUsersFragmentBinding binding;
    private ArrayAdapter<String> arrayAdapter;
    private ArrayList<String> elems;
    private ArrayList<UserInfo> users;
    private ArrayList<String> toDisplay;
    private AuxMethods aux = new AuxMethods();
    ListView list;
    private boolean isFirst = true;
    private boolean shouldRefresh = false;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        userViewModel = new ViewModelProvider(this, new UserViewModelFactory())
                .get(UserViewModel.class);

        binding = ManageUsersFragmentBinding.inflate(inflater, container, false);

        View root = binding.getRoot();

        list = (ListView) binding.listOfUsers;
        LinearLayout loadingLayout = binding.layoutLoading;

        elems = new ArrayList<>();
        users = new ArrayList<>();
        toDisplay = new ArrayList<>();

        //region listUsers
        if(isFirst)
            userViewModel.showUsers();

        userViewModel.getUserResult().observe(getViewLifecycleOwner(), new Observer<UserResult>() {
            @Override
            public void onChanged(UserResult userResult) {
                loadingLayout.setVisibility(View.GONE);

                if (userResult == null) {
                    return;
                }

                if (userResult.getError() != null) {
                    aux.makeToast(userResult.getError(),getContext());

                }
                if (userResult.getSuccessU() != null) {
                    isFirst = false;
                    loadUsers(userResult);

                    if(users.isEmpty() && toDisplay.isEmpty()){
                        aux.makeToast(R.string.no,getContext());
                    }
                    else {
                        ListView list = initTable();

                        list.setOnItemClickListener((adapterView, view, i, l) -> {

                            //change activity
                            Intent intent = new Intent(getContext(), ProfileManagementActivity.class);
                            intent.putExtra(getString(R.string.user), users.get(i));
                            startActivity(intent);

                        });
                    }

                }

            }
        });

        //endregion

        //region search
        SearchView searchView = binding.searchUsersView;
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                ArrayList<String> filteredUsers = new ArrayList<>();

                for (int i = 0; i< users.size(); i++){
                    UserInfo elem = users.get(i);
                    if(elem.getUsername().toLowerCase().contains(s.toLowerCase())
                            || elem.getName().toLowerCase().contains(s.toLowerCase())) {
                        filteredUsers.add(toDisplay.get(i));
                    }

                }
                arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, filteredUsers);
                list.setAdapter(arrayAdapter);

                return false;
            }
        });

        //endregion

        return root;
    }

    //region list handling
    private void loadUsers(UserResult userResult) {
        UserInfoListView infoListView = userResult.getSuccessU();
        List<UserInfo> listU = infoListView.getUsers();

        for(UserInfo user: listU){
            users.add(user);
            elems.add(user.toString());
            String stringToAdd = "Nome: " + user.getName() + System.getProperty("line.separator")+
                    "Username: "+ user.getUsername();

            toDisplay.add(stringToAdd);

        }

    }

    private ListView initTable(){
        arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, toDisplay);

        list.setAdapter(arrayAdapter);

        arrayAdapter.notifyDataSetChanged();

        return list;
    }

    //endregion

    @Override
    public void onResume() {
        super.onResume();
        if(shouldRefresh){
            aux.refreshFragment(getActivity(),R.id.nav_other_users);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        shouldRefresh = true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}




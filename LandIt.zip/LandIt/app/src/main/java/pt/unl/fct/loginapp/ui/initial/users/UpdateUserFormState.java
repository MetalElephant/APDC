package pt.unl.fct.loginapp.ui.initial.users;

import androidx.annotation.Nullable;

public class UpdateUserFormState {

    @Nullable
    private Integer emailError;
    @Nullable
    private Integer nameError;

    private boolean isDataValid;

    UpdateUserFormState(@Nullable Integer nameError, @Nullable Integer emailError) {
        this.emailError = emailError;
        this.nameError = nameError;
        this.isDataValid = false;
    }

    UpdateUserFormState(boolean isDataValid) {
        this.emailError = null;
        this.nameError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getEmailError() { return emailError; }

    @Nullable
    public Integer getNameError() { return nameError; }

    public boolean isDataValid() {
        return isDataValid;
    }
}

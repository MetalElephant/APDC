package pt.unl.fct.loginapp.ui.homepage.ui.profile;

import androidx.annotation.Nullable;


public class ProfileResult {
    @Nullable
    private UserInfoView success;
    @Nullable
    private Integer error;

    public ProfileResult(@Nullable Integer error) {
        this.error = error;
    }

    public ProfileResult(@Nullable UserInfoView success) {
        this.success = success;
    }

    @Nullable
    public UserInfoView getSuccess() {
        return success;
    }

    @Nullable
    public Integer getError() {
        return error;
    }
}

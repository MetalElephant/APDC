package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.ParcelRepository;
import pt.unl.fct.loginapp.data.parcel.ParcelRepositoryCallback;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.RegisteredParcel;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;


public class ParcelViewModel extends ViewModel {

    private MutableLiveData<ParcelRegisterFormState> parcelFormState = new MutableLiveData<>();
    private MutableLiveData<ParcelResult> registerParcelResult = new MutableLiveData<>();

    private ParcelRepository parcelRepository;

    ParcelViewModel(ParcelRepository parcelRepository) {
        this.parcelRepository = parcelRepository;
    }

    LiveData<ParcelRegisterFormState> getParcelFormState() {
        return parcelFormState;
    }

    public LiveData<ParcelResult> getParcelResult() {
        return registerParcelResult;
    }

    //deal with registering parcel
    public void registerParcel(String owner, String name, String county, String district, String freguesia, String description,
                               String groundType, String currUsage,String prevUsage, String area,
                               double[] allLats, double[] allLongs) {

        String[] owners = {};
        // can be launched in a separate asynchronous job
        parcelRepository.registerParcel(owner, owners, name, county, district, freguesia, description, groundType,currUsage,
                prevUsage, area, allLats, allLongs, new ParcelRepositoryCallback<RegisteredParcel>() {
            @Override
            public void onComplete(Result<RegisteredParcel> result) {

                //Error handling
                    if (result instanceof Result.Success) {
                        registerParcelResult.postValue(new ParcelResult(new RegisteredParcelView()));
                    } else if(result.toString().contains("409")) {
                        registerParcelResult.postValue(new ParcelResult(R.string.parcelConflict));
                    }else{
                        registerParcelResult.postValue(new ParcelResult(R.string.registerParcelFailed));
                    }


            }

        });
    }

    //show users parcels
    public void showParcels(String username) {
        parcelRepository.showParcels(username, new ParcelRepositoryCallback<List<ParcelInfo>>(){ //TODO check this?
            @Override
            public void onComplete(Result<List<ParcelInfo>> result) {

                if (result instanceof Result.Success) {
                    List<ParcelInfo> data = ((Result.Success<List<ParcelInfo>>) result).getData();

                    registerParcelResult.postValue(new ParcelResult(new ParcelInfoView( data )));
                } else if(result.toString().contains("409")) {
                    registerParcelResult.postValue(new ParcelResult(R.string.parcelConflict));
                }else{
                    registerParcelResult.postValue(new ParcelResult(R.string.noParcels));
                }

            }
        });
    }


    //To validate data put in the boxes - using RegisterFormState
    public void registerDataChanged(String parcelName, String region, String description, String groundType, String currUsage, String prevUsage, String area) {
        if (!isParameterValid(parcelName)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(R.string.invalidParcelName, null, null, null, null, null, null));
        } else if (!isParameterValid(region)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, R.string.invalidRegion, null, null, null, null, null));
        } else if (!isParameterValid(description)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, R.string.invalidParcelDescription, null, null, null, null));
        } else if (!isParameterValid(groundType)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, R.string.invalidGroundType, null, null, null));
        } else if (!isParameterValid(currUsage)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, null, R.string.invalidUsage, null, null));
        } else if (!isParameterValid(prevUsage)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, null, null, R.string.invalidUsage, null));
        } else if (!isParameterValid(area)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, null, null, null, R.string.invalidArea));
        } else {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(true));
        }
    }

    //---------------------------------------------------------------------------------//

    // TODO make common methods for these, cuz a lot of them are very similar

    private boolean isParameterValid(String parameter){
        return parameter != null && !parameter.trim().isEmpty();
    }


}

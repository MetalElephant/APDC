package pt.unl.fct.loginapp.ui.homepage.ui.parcels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.ParcelRepository;
import pt.unl.fct.loginapp.data.parcel.ParcelRepositoryCallback;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.data.parcel.model.RegisteredParcel;
import pt.unl.fct.loginapp.data.users.model.login.LoggedInUser;


public class ParcelViewModel extends ViewModel {
    private ParcelRepository parcelRepository;

    ParcelViewModel(ParcelRepository parcelRepository) {
        this.parcelRepository = parcelRepository;
    }

    private MutableLiveData<ParcelRegisterFormState> parcelFormState = new MutableLiveData<>();
    private MutableLiveData<ParcelResult> registerParcelResult = new MutableLiveData<>();

    private MutableLiveData<ParcelUpdateFormState> parcelUpdateFormState = new MutableLiveData<>();
    private MutableLiveData<ParcelResult> updateParcelResult = new MutableLiveData<>();

    private MutableLiveData<ParcelResult> verifyParcelResult = new MutableLiveData<>();

    private MutableLiveData<ParcelResult> removeParcelResult = new MutableLiveData<>();


    //region register

    public LiveData<ParcelResult> getParcelResult() {return registerParcelResult;}

    LiveData<ParcelRegisterFormState> getParcelFormState() {return parcelFormState;}

    public void registerDataChanged(String parcelName, String description, String currUsage, String prevUsage, String area, List<byte[]> confirmation) {
        if (!isParameterValid(parcelName) && parcelName.contains(" ")) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(R.string.invalidParcelName, null, null, null, null, null, null, null));
        }else if (!isParameterValid(description)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, R.string.invalidParcelDescription, null, null, null, null, null));
        } else if (confirmation.isEmpty()) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, null, null, null, null, R.string.uploadDocWarning));
        }else if (!isParameterValid(currUsage)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, null, R.string.invalidUsage, null, null, null));
        } else if (!isParameterValid(prevUsage)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, null, null, R.string.invalidUsage, null, null));
        } else if (!isParameterValid(area)) {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(null, null, null, null, null, null, R.string.invalidArea,null));
        } else {
            parcelFormState.setValue(
                    new ParcelRegisterFormState(true));
        }
    }

    public void registerParcel(String owner, String name, String county, String district, String freguesia, String description,
                               String groundType, String currUsage,String prevUsage,
                               double[] allLats, double[] allLongs, byte[] confirmation) {

        String[] owners = {};
        // can be launched in a separate asynchronous job
        parcelRepository.registerParcel(owner, owners, name, county, district, freguesia, description, groundType,currUsage,
                prevUsage, allLats, allLongs, confirmation, new ParcelRepositoryCallback<RegisteredParcel>() {
            @Override
            public void onComplete(Result<RegisteredParcel> result) {
                 if (result instanceof Result.Success) {
                        registerParcelResult.postValue(new ParcelResult(new RegisteredParcelView()));
                    } else if(result.toString().contains("409")) {
                        registerParcelResult.postValue(new ParcelResult(R.string.parcelConflict));
                    }else{
                        registerParcelResult.postValue(new ParcelResult(R.string.registerParcelFailed));
                    }


            }

        });
    }

    //endregion

    //region show users parcels
    public void showParcels(String username) {
        parcelRepository.showParcels(username, new ParcelRepositoryCallback<List<ParcelInfo>>(){
            @Override
            public void onComplete(Result<List<ParcelInfo>> result) {

                if (result instanceof Result.Success) {
                    List<ParcelInfo> data = ((Result.Success<List<ParcelInfo>>) result).getData();

                    registerParcelResult.postValue(new ParcelResult(new ParcelInfoView( data )));
                }else{
                    registerParcelResult.postValue(new ParcelResult(R.string.noParcels));
                }

            }
        });
    }
    //endregion

    //region updateParcel

    public MutableLiveData<ParcelResult> getUpdateParcelResult() { return updateParcelResult;}

    public MutableLiveData<ParcelUpdateFormState> getParcelUpdateFormState() {return parcelUpdateFormState;}

    public void updateDataChanged(String pName, String description, String groundType, String currUsage,
                                  String prevUsage){
        if (!isParameterValid(pName) && pName.contains(" ")) {
            parcelUpdateFormState.setValue(
                    new ParcelUpdateFormState(R.string.invalidParcelName, null, null, null, null));
        }else if (!isParameterValid(description)) {
            parcelUpdateFormState.setValue(
                    new ParcelUpdateFormState(null, R.string.invalidParcelDescription, null, null, null));
        } else if (!isParameterValid(groundType)) {
            parcelUpdateFormState.setValue(
                    new ParcelUpdateFormState(null, null, R.string.invalidGroundType, null, null));
        }else if (!isParameterValid(currUsage)) {
            parcelUpdateFormState.setValue(
                    new ParcelUpdateFormState(null, null, null, R.string.invalidUsage, null));
        } else if (!isParameterValid(prevUsage)) {
            parcelUpdateFormState.setValue(
                    new ParcelUpdateFormState(null, null, null, null,  R.string.invalidUsage));
        } else {
            parcelUpdateFormState.setValue(
                    new ParcelUpdateFormState(true));
        }

    }

    public void updateParcel(String username, String username1, String[] owners, String pName,
                             String description, String groundType, String currUsage, String prevUsage,
                             double[] latitudes, double[] longitudes) {
        parcelRepository.updateParcel(username,username1, owners, pName, description, groundType,
                currUsage, prevUsage, latitudes, longitudes, new ParcelRepositoryCallback<RegisteredParcel>() {
                    @Override
                    public void onComplete(Result<RegisteredParcel> result) {
                        if (result instanceof Result.Success) {
                            updateParcelResult.postValue(new ParcelResult(new RegisteredParcelView()));
                        } else if(result.toString().contains("409")) {
                            updateParcelResult.postValue(new ParcelResult(R.string.parcelConflict));
                        }else{
                            updateParcelResult.postValue(new ParcelResult(R.string.registerParcelFailed));
                        }
                    }
                });
    }

    //endregion

    //region showRepParcels
    public void showRepParcels(String username) {
        parcelRepository.showRepParcels(username, new ParcelRepositoryCallback<List<ParcelInfo>>(){
            @Override
            public void onComplete(Result<List<ParcelInfo>> result) {

                if (result instanceof Result.Success) {
                    List<ParcelInfo> data = ((Result.Success<List<ParcelInfo>>) result).getData();

                    registerParcelResult.postValue(new ParcelResult(new ParcelInfoView( data )));
                } else{
                    registerParcelResult.postValue(new ParcelResult(R.string.noParcels));
                }

            }
        });
    }
    //endregion

    //region verifyParcel

    public MutableLiveData<ParcelResult> getVerifyParcelResult() {
        return verifyParcelResult;
    }

    public void verifyParcel(String username, String owner, String parcelName, String reason, boolean confirmation) {
        parcelRepository.verifyParcel(username,owner, parcelName, reason, confirmation
                , new ParcelRepositoryCallback<RegisteredParcel>() {
                    @Override
                    public void onComplete(Result<RegisteredParcel> result) {
                        if (result instanceof Result.Success) {
                            verifyParcelResult.postValue(new ParcelResult(new RegisteredParcelView()));
                        } else {
                            verifyParcelResult.postValue(new ParcelResult(R.string.defaultError));
                        }
                    }
                });
    }

    //endregion

    //region removeParcel

    public MutableLiveData<ParcelResult> getRemoveParcelResult() {
        return removeParcelResult;
    }

    public void removeParcel(String username, String owner, String parcelName) {
        parcelRepository.removeParcel(username,owner, parcelName, new ParcelRepositoryCallback<RegisteredParcel>() {
            @Override
            public void onComplete(Result<RegisteredParcel> result) {
                if (result instanceof Result.Success) {
                    removeParcelResult.postValue(new ParcelResult(new RegisteredParcelView()));
                } else {
                    removeParcelResult.postValue(new ParcelResult(R.string.defaultError));
                }
            }
        });
    }

    //endregion

    //region showParcelsByRegion

    public void showParcelsRegion(String username, String region, int type) {
        parcelRepository.showParcelsRegion(username,region,type, new ParcelRepositoryCallback<List<ParcelInfo>>(){
            @Override
            public void onComplete(Result<List<ParcelInfo>> result) {

                if (result instanceof Result.Success) {
                    List<ParcelInfo> data = ((Result.Success<List<ParcelInfo>>) result).getData();

                    registerParcelResult.postValue(new ParcelResult(new ParcelInfoView( data )));
                } else{
                    registerParcelResult.postValue(new ParcelResult(R.string.noParcels));
                }

            }
        });
    }

    //endregion



    //---------------------------------------------------------------------------------//


    private boolean isParameterValid(String parameter){
        return parameter != null && !parameter.trim().isEmpty();
    }



}

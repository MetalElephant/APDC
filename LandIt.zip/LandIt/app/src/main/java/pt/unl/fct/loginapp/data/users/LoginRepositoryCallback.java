package pt.unl.fct.loginapp.data.users;

import pt.unl.fct.loginapp.data.Result;

/* Adicionado para devolver o resultado ao LoginViewModel */
public interface LoginRepositoryCallback<T> {
    void onComplete(Result<T> result);
}

package pt.unl.fct.loginapp.ui.homepage.ui.forums;

import androidx.annotation.Nullable;


public class ForumResult {
    @Nullable
    private ForumResultView success;
    @Nullable
    private ForumResultListView successF;
    @Nullable
    private ForumResultListMsgView successM;
    @Nullable
    private Integer error;

    public ForumResult(@Nullable Integer error) {this.error = error;}

    public ForumResult(@Nullable ForumResultView success) {
        this.success = success;
    }

    public ForumResult(@Nullable ForumResultListView success) {this.successF = success;}

    public ForumResult(@Nullable ForumResultListMsgView success){this.successM = success;}

    @Nullable
    ForumResultView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }

    @Nullable
    public ForumResultListView getSuccessR() {
        return successF;
    }

    @Nullable
    public ForumResultListMsgView getSuccessM() {
        return successM;
    }
}

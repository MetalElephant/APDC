package pt.unl.fct.loginapp.ui.homepage.ui.forums;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.preference.PreferenceManager;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.forum.model.ForumInfo;
import pt.unl.fct.loginapp.data.forum.model.ForumMessageData;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.databinding.FragmentForumBinding;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelInfoView;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelResult;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModel;
import pt.unl.fct.loginapp.ui.homepage.ui.parcels.ParcelViewModelFactory;
import pt.unl.fct.loginapp.ui.homepage.ui.parcelsInfo.ParcelInfoActivity;
import pt.unl.fct.loginapp.util.AuxMethods;
import pt.unl.fct.loginapp.util.Roles;

public class ForumFragment extends Fragment {

    private FragmentForumBinding binding;
    private ArrayAdapter<String> arrayAdapter;
    private ListView list;
    private LinearLayout loadingLayout;
    private AuxMethods aux = new AuxMethods();
    ArrayList<ForumInfo> elems;
    ArrayList<String> toDisplay;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ForumViewModel forumViewModel =
                new ViewModelProvider(this, new ForumViewModelFactory()).get(ForumViewModel.class);



        binding = FragmentForumBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        String username = aux.loadUsername(getContext());
        String role = aux.loadRole(getContext());

        SearchView searchView = binding.searchForumsView;
        TextView noForumsText = binding.textNoForums;
        list = binding.listOfForums;
        loadingLayout = binding.layoutLoading;
        elems = new ArrayList<>();
        toDisplay = new ArrayList<>();

        //region load forums

        if(Roles.isModOrSU(role)){
            forumViewModel.listAllForums();

        }
        else{
            forumViewModel.listForums(username);
        }

        forumViewModel.getForumResult().observe(getViewLifecycleOwner(), forumResult -> {
            loadingLayout.setVisibility(View.GONE);
            if(forumResult == null)
                return;

            if(forumResult.getError()!= null){
                Snackbar.make(getView(), forumResult.getError(), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }

            if(forumResult.getSuccessR() != null){
                if(elems.isEmpty())
                    loadUserForums(forumResult);


                //set the listView with elements loaded
                if(elems.isEmpty() && toDisplay.isEmpty()){
                    noForumsText.setVisibility(View.VISIBLE);
                }
                else {
                    setListView();
                }
            }

        });

        //endregion


        //region search forums
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                ArrayList<String> filteredForums = new ArrayList<>();

                //todo filter
                for (int i = 0; i< elems.size(); i++){
                    ForumInfo elem = elems.get(i);
                    if(elem.getName().toLowerCase().contains(s.toLowerCase())
                            || elem.getTopic().toLowerCase().contains(s.toLowerCase())) {
                        filteredForums.add(toDisplay.get(i));
                    }

                }
                arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, filteredForums);
                list.setAdapter(arrayAdapter);

                return false;
            }
        });
        //endregion
        return root;
    }

    private void loadUserForums(ForumResult forumResult) {
        ForumResultListView infoView = forumResult.getSuccessR();
        List<ForumInfo> listF = infoView.getForums();

        for (ForumInfo forum: listF) {
            elems.add(forum);
            toDisplay.add(forum.toString());
        }

    }

    private ListView initTable(){
        ArrayAdapter arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, elems);

        list.setAdapter(arrayAdapter);
        list.setClickable(true);

        arrayAdapter.notifyDataSetChanged();

        return list;

    }

    private void setListView() {
        ListView list = initTable();

        list.setOnItemClickListener((adapterView, view, i, l) -> {

            //change activity
            Intent intent = new Intent(getContext(), ForumActivity.class);
            intent.putExtra(getString(R.string.forumName), elems.get(i));
            startActivity(intent);
        });
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
package pt.unl.fct.loginapp.data.rewards;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.util.List;

import pt.unl.fct.loginapp.data.RestAPI;
import pt.unl.fct.loginapp.data.Result;
import pt.unl.fct.loginapp.data.parcel.model.RequestData;
import pt.unl.fct.loginapp.data.rewards.model.RegisteredReward;
import pt.unl.fct.loginapp.data.rewards.model.RemoveObjectData;
import pt.unl.fct.loginapp.data.rewards.model.RewardData;
import pt.unl.fct.loginapp.data.rewards.model.RewardRedeemData;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RewardDataSource {
    private final RestAPI service;
    Gson gson = new GsonBuilder().setLenient().create();
    private static final int DEFAULT_TYPE = 1;

    public RewardDataSource() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://landit-app.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        this.service = retrofit.create(RestAPI.class);
    }

    //ops

    public Result<RegisteredReward> registerReward(String name, String description, String owner, String price) {

        try {
            try{
            // Call the REST services and do the post
            Call<RegisteredReward> registerService = service.doRegisterReward(new RewardData(name,
                    description, owner, price, "0")) ;
            Response<RegisteredReward> response = registerService.execute();

            if( response.isSuccessful() ) {
                RegisteredReward r = response.body();
                return new Result.Success<>(r);
            } else {
                return new Result.Error(new Exception("Server result code: " + response.code() ));
            }
            }catch (IllegalStateException | JsonSyntaxException | java.io.IOException exception) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<RegisteredReward> removeReward(String username, String owner, String rewardName){
        try {
            try {
                // Call the REST services and do the post
                Call<RegisteredReward> removeService = service.removeReward(new RemoveObjectData(username,
                        owner, rewardName));
                Response<RegisteredReward> response = removeService.execute();

                if (response.isSuccessful()) {
                    RegisteredReward r = response.body();
                    return new Result.Success<>(r);
                } else {
                    return new Result.Error(new Exception("Server result code: " + response.code()));
                }
            }catch (IllegalStateException | JsonSyntaxException | java.io.IOException exception) {
            return new Result.Success<>("data");
        }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<RegisteredReward> doRedeem(String username, String owner, String rewardName){
        try {
            try{
            Call<RegisteredReward> removeService = service.doRedeem(new RewardRedeemData(username,
                    owner,rewardName));
            Response<RegisteredReward> response = removeService.execute();

            if( response.isSuccessful() ) {
                RegisteredReward r = response.body();
                return new Result.Success<>(r);
            } else {
                return new Result.Error(new Exception("Server result code: " + response.code() ));
            }
            }catch (IllegalStateException | JsonSyntaxException | java.io.IOException exception) {
                return new Result.Success<>("data");
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<List<RewardData>> listRewards(String username){
        try{
            try{
                Call<List<RewardData>> listService = service.listMerchantRewards(new RequestData(username));
                Response<List<RewardData>> response = listService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<RewardData> allRewards= response.body();
                    return new Result.Success<>(allRewards);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }
    }

    public Result<List<RewardData>> listAllRewards(){
        try{
            try{
                Call<List<RewardData>> listService = service.listAllRewards();
                Response<List<RewardData>> response = listService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<RewardData> allRewards= response.body();
                    return new Result.Success<>(allRewards);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }
    }


    public Result<List<RewardData>> listRedeemable(String username){
        try{
            try{
                Call<List<RewardData>> listService = service.listRedeemable(new RequestData(username));
                Response<List<RewardData>> response = listService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<RewardData> allRewards= response.body();
                    return new Result.Success<>(allRewards);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }
    }


    public Result<List<RewardData>> listRedeemed(String username){
        try{
            try{
                Call<List<RewardData>> listService = service.listRedeemed(new RequestData(username));
                Response<List<RewardData>> response = listService.execute();
                gson.toJson(response);

                if(response.isSuccessful()){
                    List<RewardData> allRewards= response.body();
                    return new Result.Success<>(allRewards);
                }
                else
                    return new Result.Error(new Exception("Server result code: " + response.code() ));

            }catch (IllegalStateException | JsonSyntaxException exception) {
                return new Result.Success<>("data");
            }

        } catch (Exception e) {
            return new Result.Error(new IOException("Error " + e.toString(), e));
        }
    }




}

package pt.unl.fct.loginapp.ui.initial;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.ui.initial.users.LoginActivity;
import pt.unl.fct.loginapp.ui.initial.users.RegisterActivity;

public class InitialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_initial);


        //get button to change activity
        Button goToLogin = findViewById(R.id.button_initial_login);
       goToLogin.setOnClickListener(view -> {
          Intent changeAct = new Intent(getApplicationContext(),LoginActivity.class);
          startActivity(changeAct);
       });

        //get button to change activity
        Button goToRegister = findViewById(R.id.button_initial_register);
        goToRegister.setOnClickListener(view -> {
            Intent changeAct = new Intent(getApplicationContext(), RegisterActivity.class);
            startActivity(changeAct);
        });


    }
}

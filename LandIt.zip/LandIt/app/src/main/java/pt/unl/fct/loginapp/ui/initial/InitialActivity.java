package pt.unl.fct.loginapp.ui.initial;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.Serializable;
import java.util.Arrays;

import pt.unl.fct.loginapp.R;
import pt.unl.fct.loginapp.data.parcel.model.ParcelInfo;
import pt.unl.fct.loginapp.ui.initial.users.LoginActivity;
import pt.unl.fct.loginapp.ui.initial.users.RegisterActivity;
import pt.unl.fct.loginapp.util.AuxMethods;

public class InitialActivity extends AppCompatActivity implements Serializable {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_initial);


        //get button to change activity
        Button goToLogin = findViewById(R.id.button_initial_login);
       goToLogin.setOnClickListener(view -> {
          Intent changeAct = new Intent(getApplicationContext(),LoginActivity.class);
          startActivity(changeAct);
       });

        //get button to change activity
        Button goToRegister = findViewById(R.id.button_initial_register);
        goToRegister.setOnClickListener(view -> {
            Intent changeAct = new Intent(getApplicationContext(), RegisterActivity.class);
            startActivity(changeAct);
        });

    }





}
